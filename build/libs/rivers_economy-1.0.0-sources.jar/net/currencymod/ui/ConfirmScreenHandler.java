package net.currencymod.ui;

import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3917;
import net.minecraft.class_747;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

/**
 * A reusable 3-row (27-slot) confirmation GUI.
 * Shows a centred info item, confirm (lime concrete) and cancel (red concrete) button.
 */
public class ConfirmScreenHandler extends class_1707 {

    private static final int SLOT_INFO    = 13;
    private static final int SLOT_CONFIRM = 11;
    private static final int SLOT_CANCEL  = 15;

    private final Runnable onConfirm;
    private final Runnable onCancel;

    private ConfirmScreenHandler(int syncId, class_1661 playerInv,
                                  class_1277 gui,
                                  Runnable onConfirm, Runnable onCancel) {
        super(class_3917.field_17326, syncId, playerInv, gui, 3);
        this.onConfirm = onConfirm;
        this.onCancel  = onCancel;
    }

    /**
     * Opens a confirmation screen for the given player.
     *
     * @param player     The player
     * @param title      Title shown on the chest
     * @param infoItem   The item displayed in the centre info slot
     * @param infoName   Display name for the info item (may use § colour codes)
     * @param infoLore   Lore lines (may use § colour codes)
     * @param onConfirm  Called when the player clicks Confirm
     * @param onCancel   Called when the player clicks Cancel / Back
     */
    public static void open(class_3222 player,
                            String title,
                            class_1792 infoItem,
                            String infoName,
                            List<String> infoLore,
                            Runnable onConfirm,
                            Runnable onCancel) {
        class_1277 gui = new class_1277(27);
        class_1799 filler = makeFiller();
        for (int i = 0; i < 27; i++) gui.method_5447(i, filler.method_7972());

        gui.method_5447(SLOT_INFO,    makeItem(infoItem, infoName, infoLore));
        gui.method_5447(SLOT_CONFIRM, makeItem(class_1802.field_8839,   "§a§lConfirm", List.of("§7Click to confirm.")));
        gui.method_5447(SLOT_CANCEL,  makeItem(class_1802.field_8197,    "§c§lCancel",  List.of("§7Click to go back.")));

        player.method_17355(new class_747(
            (syncId, inv, p) -> new ConfirmScreenHandler(syncId, inv, gui, onConfirm, onCancel),
            class_2561.method_43470(title)
        ));
    }

    @Override
    public void method_7593(int slotIndex, int button, class_1713 actionType, class_1657 player) {
        if (!(player instanceof class_3222 sp)) return;
        if (slotIndex == SLOT_CONFIRM) { sp.method_7346(); onConfirm.run(); return; }
        if (slotIndex == SLOT_CANCEL)  { sp.method_7346(); onCancel.run();  return; }
        // Block all other interactions
    }

    @Override
    public class_1799 method_7601(class_1657 player, int slot) { return class_1799.field_8037; }

    @Override
    public boolean method_7597(class_1657 player) { return true; }

    // -------------------------------------------------------------------------
    // Shared item-building helpers (package-visible so other handlers can reuse)
    // -------------------------------------------------------------------------

    static class_1799 makeItem(class_1792 item, String name, List<String> lore) {
        class_1799 stack = new class_1799(item);
        stack.method_57379(class_9334.field_49631,
            class_2561.method_43470(name).method_27694(s -> s.method_10978(false)));
        if (!lore.isEmpty()) {
            List<class_2561> loreTexts = lore.stream()
                .map(line -> (class_2561) class_2561.method_43470(line).method_27694(s -> s.method_10978(false)))
                .collect(Collectors.toList());
            stack.method_57379(class_9334.field_49632, new class_9290(loreTexts));
        }
        return stack;
    }

    static class_1799 makeFiller() {
        class_1799 pane = new class_1799(class_1802.field_8871);
        pane.method_57379(class_9334.field_49631, class_2561.method_43470(" ").method_27694(s -> s.method_10978(false)));
        return pane;
    }
}
