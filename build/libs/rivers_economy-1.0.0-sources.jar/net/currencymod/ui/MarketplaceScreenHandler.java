package net.currencymod.ui;

import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3917;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * A simple screen handler for the marketplace that uses a chest-like UI.
 * Players can click on items to purchase them.
 */
public class MarketplaceScreenHandler extends class_1703 {
    private static final Logger LOGGER = LoggerFactory.getLogger("CurrencyMod/MarketplaceScreenHandler");
    private final class_1263 inventory;
    
    /**
     * Create a new marketplace screen handler.
     *
     * @param syncId The synchronization ID
     * @param playerInventory The player's inventory
     * @param inventory The marketplace inventory
     */
    public MarketplaceScreenHandler(int syncId, class_1661 playerInventory, class_1263 inventory) {
        // Use the generic container screen handler type for a chest-like UI
        super(class_3917.field_17326, syncId);
        this.inventory = inventory;
        
        // Add the marketplace slots (3 rows of 9 slots)
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.method_7621(new MarketplaceSlot(inventory, col + row * 9, 8 + col * 18, 18 + row * 18));
            }
        }
        
        // Add the player inventory slots (3 rows of 9 slots)
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.method_7621(new class_1735(playerInventory, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));
            }
        }
        
        // Add the player hotbar slots (1 row of 9 slots)
        for (int col = 0; col < 9; col++) {
            this.method_7621(new class_1735(playerInventory, col, 8 + col * 18, 142));
        }
    }
    
    /**
     * Create a marketplace screen handler with an empty inventory.
     *
     * @param syncId The synchronization ID
     * @param playerInventory The player's inventory
     */
    public MarketplaceScreenHandler(int syncId, class_1661 playerInventory) {
        this(syncId, playerInventory, new class_1277(27));
    }
    
    @Override
    public boolean method_7597(class_1657 player) {
        return this.inventory.method_5443(player);
    }
    
    @Override
    public class_1799 method_7601(class_1657 player, int index) {
        // Prevent shift-clicking in the marketplace
        return class_1799.field_8037;
    }
    
    @Override
    public void method_7595(class_1657 player) {
        super.method_7595(player);
        // No need to drop items as they are virtual representations
    }
    
    /**
     * Override this method to handle button clicks (used to process purchases).
     * 
     * @param player The player
     * @param id The button ID (slot index)
     * @return True if the click was handled, false otherwise
     */
    public boolean method_7604(class_1657 player, int id) {
        // Default implementation does nothing
        return false;
    }
    
    @Override
    public void method_7593(int slotIndex, int button, net.minecraft.class_1713 actionType, class_1657 player) {
        // If the slot is in the marketplace area (first 27 slots)
        if (slotIndex >= 0 && slotIndex < 27) {
            // Use our custom button click handler to process the purchase
            // This will be overridden by the MarketplaceManager
            if (method_7604(player, slotIndex)) {
                return; // Skip normal slot click if button click was handled
            }
        }
        
        // Allow normal interaction with player inventory
        super.method_7593(slotIndex, button, actionType, player);
    }
    
    /**
     * A custom slot for marketplace items that disables interaction.
     * Items can only be "purchased" through the MarketplaceHandler click system.
     */
    public class MarketplaceSlot extends class_1735 {
        public MarketplaceSlot(class_1263 inventory, int index, int x, int y) {
            super(inventory, index, x, y);
        }
        
        @Override
        public boolean method_7674(class_1657 player) {
            return false; // Prevent normal item taking
        }
        
        @Override
        public boolean method_7680(class_1799 stack) {
            return false; // Prevent inserting items
        }
    }
} 