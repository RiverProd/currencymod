package net.currencymod.ui;

import net.currencymod.CurrencyMod;
import net.currencymod.plots.ChunkKey;
import net.currencymod.plots.PlotManager;
import net.currencymod.plots.PlotType;
import net.currencymod.plots.WorldPlot;
import net.minecraft.class_124;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3917;
import net.minecraft.class_747;
import net.minecraft.class_9334;
import net.minecraft.item.*;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Player chest UI — plot ownership dashboard.
 *
 * Layout (27 slots, 3 rows of 9):
 *   Row 0: slot 4 = player plot summary
 *          slot 7 = Buy Multiple Plots toggle
 *          slot 8 = Plot Vision toggle
 *          rest   = filler
 *   Row 1: slots 9-12 = owned-type items (one per PlotType with count > 0); rest filler
 *   Row 2: slot 22 = current chunk info  ← CLICKABLE (buy if available, sell if owned)
 *          slot 25 = multi mode: Select/Deselect  |  single mode + own plot: Sell button
 *          rest    = filler
 *
 * Multi-buy mode behaviour:
 *   - Toggling ON also enables Plot Vision if it is currently off.
 *   - Toggling OFF erases all pending selections.
 *   - Select/Deselect (slot 25) adds/removes the current chunk from the selection (max 16).
 *   - Clicking the Available Plot item (slot 22) opens PlotBuyScreenHandler for all
 *     selected plots when ≥1 are selected; otherwise sends a hint message.
 *   - In single mode, clicking slot 22 while standing in an available plot opens
 *     PlotBuyScreenHandler for just that one plot.
 */
public class PlotInfoScreenHandler extends class_1707 {

    private static final int SLOT_SUMMARY    = 4;
    private static final int SLOT_MULTIBUY   = 7;
    private static final int SLOT_VISION     = 8;
    private static final int FIRST_TYPE_SLOT = 9;   // 9, 10, 11, 12
    private static final int SLOT_CHUNK_INFO = 22;
    private static final int SLOT_ACTION     = 25;

    private final class_1277 gui;
    private final WorldPlot       worldPlot;   // chunk player was in when screen opened; may be null
    private final ChunkKey        currentKey;  // pre-derived for convenience
    private final UUID            playerUuid;

    private PlotInfoScreenHandler(int syncId, class_1661 playerInv, class_1277 gui,
                                    WorldPlot worldPlot, ChunkKey currentKey, UUID playerUuid) {
        super(class_3917.field_17326, syncId, playerInv, gui, 3);
        this.gui        = gui;
        this.worldPlot  = worldPlot;
        this.currentKey = currentKey;
        this.playerUuid = playerUuid;
    }

    /** Opens the dashboard for the given player, deriving chunk context from their position. */
    public static void open(class_3222 player) {
        UUID       playerUuid = player.method_5667();
        PlotManager pm        = PlotManager.getInstance();
        ChunkKey   currentKey = ChunkKey.fromPlayer(player);
        WorldPlot  worldPlot  = pm.getWorldPlot(currentKey);
        double     balance    = CurrencyMod.getEconomyManager().getBalance(playerUuid);

        boolean multiMode     = pm.isMultiBuyMode(playerUuid);
        boolean visionOn      = pm.hasPlotVision(playerUuid);
        int     selCount      = pm.getSelectionCount(playerUuid);
        boolean chunkSelected = multiMode && pm.getSelectedPlots(playerUuid).contains(currentKey);

        Map<PlotType, Integer> plotCounts = pm.getPlayerPlotCounts(playerUuid);
        int totalPlots = plotCounts.values().stream().mapToInt(Integer::intValue).sum();
        int dailyTax   = pm.getPlayerDailyTax(playerUuid);

        class_1277 gui = new class_1277(27);
        class_1799 filler = ConfirmScreenHandler.makeFiller();
        for (int i = 0; i < 27; i++) gui.method_5447(i, filler.method_7972());

        // Slot 4 — player summary
        gui.method_5447(SLOT_SUMMARY, makeSummaryItem(plotCounts, totalPlots, dailyTax));

        // Slot 7 — multi-buy toggle
        gui.method_5447(SLOT_MULTIBUY, makeMultiBuyItem(multiMode, selCount));

        // Slot 8 — plot vision toggle
        gui.method_5447(SLOT_VISION, makeVisionItem(visionOn));

        // Slots 9-12 — owned type items
        int typeSlot = FIRST_TYPE_SLOT;
        for (PlotType type : PlotType.values()) {
            if (typeSlot > 12) break;
            int count = plotCounts.getOrDefault(type, 0);
            if (count > 0) { gui.method_5447(typeSlot++, makeOwnedTypeItem(type, count)); }
        }

        // Slot 22 — current chunk info (clickable)
        gui.method_5447(SLOT_CHUNK_INFO,
                makeChunkInfoItem(worldPlot, playerUuid, player, multiMode, chunkSelected, selCount));

        // Slot 25 — context action
        gui.method_5447(SLOT_ACTION,
                makeActionItem(worldPlot, playerUuid, currentKey, multiMode, chunkSelected, selCount));

        player.method_17355(new class_747(
                (syncId, inv, p) -> new PlotInfoScreenHandler(
                        syncId, inv, gui, worldPlot, currentKey, playerUuid),
                class_2561.method_43470("Your Plots")));
    }

    // =========================================================================
    // Slot click handling
    // =========================================================================

    @Override
    public void method_7593(int slotIndex, int button, class_1713 actionType, class_1657 player) {
        if (!(player instanceof class_3222 sp)) return;

        switch (slotIndex) {
            case SLOT_MULTIBUY   -> handleMultiBuyToggle(sp);
            case SLOT_VISION     -> handleVisionToggle(sp);
            case SLOT_CHUNK_INFO -> handleChunkInfoClick(sp);
            case SLOT_ACTION     -> handleActionClick(sp);
        }
        // All other slots: no-op
    }

    private void handleMultiBuyToggle(class_3222 sp) {
        PlotManager pm = PlotManager.getInstance();
        boolean nowOn = pm.toggleMultiBuy(sp.method_5667());

        // Auto-enable Plot Vision when entering multi-buy mode
        if (nowOn && !pm.hasPlotVision(sp.method_5667())) {
            pm.togglePlotVision(sp.method_5667());
            gui.method_5447(SLOT_VISION, makeVisionItem(true));
            sp.method_43496(class_2561.method_43470("Plot Vision auto-enabled for multi-buy.")
                    .method_27692(class_124.field_1080));
        }

        int selCount = pm.getSelectionCount(sp.method_5667());
        gui.method_5447(SLOT_MULTIBUY, makeMultiBuyItem(nowOn, selCount));
        // Selection has been cleared or started — refresh dependent slots
        refreshSelectionSlots(sp, nowOn, selCount);

        sp.method_43496(nowOn
                ? class_2561.method_43470("Multi-buy mode enabled. Select plots and click the available plot info to purchase.")
                        .method_27692(class_124.field_1075)
                : class_2561.method_43470("Multi-buy mode disabled. Selections cleared.")
                        .method_27692(class_124.field_1080));
    }

    private void handleVisionToggle(class_3222 sp) {
        boolean nowEnabled = PlotManager.getInstance().togglePlotVision(sp.method_5667());
        gui.method_5447(SLOT_VISION, makeVisionItem(nowEnabled));
        sp.method_43496(nowEnabled
                ? class_2561.method_43470("Plot Vision ").method_10852(
                        class_2561.method_43470("enabled").method_27695(class_124.field_1060, class_124.field_1067))
                        .method_10852(class_2561.method_43470(". Available plots nearby will glow.").method_27692(class_124.field_1080))
                : class_2561.method_43470("Plot Vision ").method_10852(
                        class_2561.method_43470("disabled").method_27695(class_124.field_1061, class_124.field_1067))
                        .method_10852(class_2561.method_43470(".").method_27692(class_124.field_1080)));
    }

    private void handleChunkInfoClick(class_3222 sp) {
        PlotManager pm     = PlotManager.getInstance();
        UUID        uuid   = sp.method_5667();
        boolean     multi  = pm.isMultiBuyMode(uuid);

        if (worldPlot != null && !worldPlot.isOwned() && worldPlot.isAvailable()) {
            if (multi) {
                Set<ChunkKey> sel = pm.getSelectedPlots(uuid);
                if (sel.isEmpty()) {
                    sp.method_43496(class_2561.method_43470(
                            "No plots selected. Use the Select button to add plots first.")
                            .method_27692(class_124.field_1061));
                } else {
                    sp.method_7346();
                    PlotBuyScreenHandler.open(sp, new LinkedHashSet<>(sel));
                }
            } else {
                // Single mode — buy just this plot
                sp.method_7346();
                Set<ChunkKey> single = new LinkedHashSet<>();
                single.add(currentKey);
                PlotBuyScreenHandler.open(sp, single);
            }
            return;
        }

        if (worldPlot != null && worldPlot.isOwned() && uuid.equals(worldPlot.getOwnerUuid())) {
            handleSell(sp);
        }
    }

    private void handleActionClick(class_3222 sp) {
        PlotManager pm    = PlotManager.getInstance();
        UUID        uuid  = sp.method_5667();
        boolean     multi = pm.isMultiBuyMode(uuid);

        if (multi) {
            // Select / Deselect the current chunk
            if (worldPlot == null || !worldPlot.isAvailable()) {
                sp.method_43496(class_2561.method_43470("You are not standing in an available plot.")
                        .method_27692(class_124.field_1061));
                return;
            }
            int result = pm.togglePlotSelection(uuid, currentKey);
            if (result == -1) {
                sp.method_43496(class_2561.method_43470("You can only select up to 16 plots at once.")
                        .method_27692(class_124.field_1061));
                return;
            }
            boolean selected  = pm.getSelectedPlots(uuid).contains(currentKey);
            int     selCount  = pm.getSelectionCount(uuid);

            // Refresh chunk info (shows/hides Selected lore) and select button (updates count)
            refreshSelectionSlots(sp, true, selCount);

            sp.method_43496(selected
                    ? class_2561.method_43470("Plot added to selection. §a" + selCount + "/16 §7selected.")
                            .method_27692(class_124.field_1060)
                    : class_2561.method_43470("Plot removed from selection. §e" + selCount + "/16 §7selected.")
                            .method_27692(class_124.field_1054));
        } else {
            // Single mode — slot 25 is the Sell button when the player owns this plot
            handleSell(sp);
        }
    }

    private void handleSell(class_3222 sp) {
        if (worldPlot == null || !worldPlot.isOwned() || !sp.method_5667().equals(worldPlot.getOwnerUuid()))
            return;

        PlotType type    = getOwnedPlotType(worldPlot);
        int      price   = type != null ? type.getPurchasePrice() : 0;
        int      refund  = (int)(price * 0.2);
        String   typeName = type != null ? type.getDisplayName() : "Unknown";

        sp.method_7346();
        ConfirmScreenHandler.open(
                sp,
                "Confirm Plot Sale",
                class_1802.field_8077,
                "§c§lSell " + typeName + " Plot",
                List.of(
                        "§7Sell your §c" + typeName + "§7 plot?",
                        "§7Refund: §6$" + refund + " §7(20% of §6$" + price + "§7)",
                        "",
                        "§8This cannot be undone."
                ),
                () -> PlotManager.getInstance().sellWorldPlot(sp, worldPlot),
                () -> PlotInfoScreenHandler.open(sp));
    }

    /**
     * Refreshes the chunk-info item (slot 22) and action item (slot 25) after a selection change.
     */
    private void refreshSelectionSlots(class_3222 sp, boolean multiMode, int selCount) {
        PlotManager pm        = PlotManager.getInstance();
        boolean     selected  = multiMode && pm.getSelectedPlots(sp.method_5667()).contains(currentKey);
        double      balance   = CurrencyMod.getEconomyManager().getBalance(sp.method_5667());

        gui.method_5447(SLOT_CHUNK_INFO,
                makeChunkInfoItem(worldPlot, sp.method_5667(), sp, multiMode, selected, selCount));
        gui.method_5447(SLOT_ACTION,
                makeActionItem(worldPlot, sp.method_5667(), currentKey, multiMode, selected, selCount));
    }

    private PlotType getOwnedPlotType(WorldPlot wp) {
        if (wp.getPlotId() == null || wp.getOwnerUuid() == null) return null;
        return PlotManager.getInstance().getPlayerPlots(wp.getOwnerUuid()).stream()
                .filter(p -> p.getId().equals(wp.getPlotId()))
                .map(p -> p.getType())
                .findFirst().orElse(null);
    }

    @Override
    public class_1799 method_7601(class_1657 player, int slot) { return class_1799.field_8037; }

    @Override
    public boolean method_7597(class_1657 player) { return true; }

    // =========================================================================
    // Item builders
    // =========================================================================

    private static class_1799 makeMultiBuyItem(boolean enabled, int selCount) {
        class_1799 stack = ConfirmScreenHandler.makeItem(
                class_1802.field_8634,
                enabled ? "§b§lBuy Multiple Plots" : "§7Buy Multiple Plots",
                enabled
                        ? List.of(
                                "§bCurrently: §a§lON",
                                "§7Selected: §b" + selCount + "/16",
                                "§7Stand in available plots and use",
                                "§7the Select button to build your list.",
                                "§7Click the plot info below to purchase.",
                                "",
                                "§7Click to disable (clears selection).")
                        : List.of(
                                "§8Currently: OFF",
                                "§7Enable to select multiple plots",
                                "§7and buy them all with a bulk discount.",
                                "§7Click to enable.")
        );
        if (enabled) {
            stack.method_57379(class_9334.field_49641, true);
        }
        return stack;
    }

    private static class_1799 makeVisionItem(boolean enabled) {
        class_1799 stack = ConfirmScreenHandler.makeItem(
                class_1802.field_8449,
                enabled ? "§d§lPlot Vision" : "§7Plot Vision",
                enabled
                        ? List.of("§dCurrently: §a§lON", "§7Highlights available plots nearby.", "§7Click to disable.")
                        : List.of("§8Currently: OFF", "§7Shows available plots near you", "§7with a particle effect.", "§7Click to enable.")
        );
        if (enabled) stack.method_57379(class_9334.field_49641, true);
        return stack;
    }

    private static class_1799 makeSummaryItem(Map<PlotType, Integer> plotCounts, int total, int tax) {
        List<String> lore = new ArrayList<>();
        if (total == 0) {
            lore.add("§7You don't own any plots yet.");
            lore.add("");
            lore.add("§7Stand in a registered chunk and");
            lore.add("§7click the plot info below to buy.");
        } else {
            lore.add("§7Total owned: §f" + total);
            for (PlotType t : PlotType.values()) {
                int c = plotCounts.getOrDefault(t, 0);
                if (c > 0) lore.add("§7• " + typeColour(t) + t.getDisplayName() + "§7: §f" + c + "x");
            }
            lore.add("");
            lore.add("§7Daily tax: §6$" + tax + "/day");
        }
        return ConfirmScreenHandler.makeItem(class_1802.field_8407, "§e§lYour Plot Summary", lore);
    }

    private static class_1799 makeOwnedTypeItem(PlotType type, int count) {
        return ConfirmScreenHandler.makeItem(
                typeIcon(type),
                typeColour(type) + "§l" + type.getDisplayName() + " Plot",
                List.of(
                        "§7Owned: §f" + count + "x",
                        "§7Daily Tax: §6$" + (count * type.getDailyTax()) + "/day",
                        "§7Price: §f$" + type.getPurchasePrice() + " each"
                ));
    }

    private static class_1799 makeChunkInfoItem(WorldPlot wp, UUID playerUuid,
                                                class_3222 player,
                                                boolean multiMode, boolean chunkSelected,
                                                int selCount) {
        if (wp == null) {
            ChunkKey key = ChunkKey.fromPlayer(player);
            return ConfirmScreenHandler.makeItem(class_1802.field_8251, "§7Current Chunk",
                    List.of("§8Chunk: §7" + key.chunkX + ", " + key.chunkZ,
                            "§8Not a registered plot."));
        }

        ChunkKey loc = wp.getLocation();

        if (!wp.isOwned()) {
            List<String> lore = new ArrayList<>();
            lore.add("§8Chunk: §7" + loc.chunkX + ", " + loc.chunkZ);
            lore.add("§aAvailable for purchase.");
            lore.add("§7Types:");
            for (PlotType t : wp.getEnabledTypes())
                lore.add("  §7• " + typeColour(t) + t.getDisplayName() + " §7($" + t.getPurchasePrice() + ")");

            if (multiMode) {
                lore.add("");
                if (chunkSelected) {
                    lore.add("§a✓ Selected §7(" + selCount + "/16)");
                } else {
                    lore.add("§8Not selected  §7(" + selCount + "/16)");
                }
                if (selCount > 0) {
                    lore.add("§eClick to open buy menu for " + selCount + " selected plot"
                            + (selCount != 1 ? "s" : "") + ".");
                } else {
                    lore.add("§7Click to buy just this plot.");
                }
            } else {
                lore.add("");
                lore.add("§eClick to purchase this plot.");
            }
            return ConfirmScreenHandler.makeItem(class_1802.field_8895, "§a§lAvailable Plot", lore);
        }

        if (playerUuid.equals(wp.getOwnerUuid())) {
            PlotType type = PlotManager.getInstance().getPlayerPlots(playerUuid).stream()
                    .filter(p -> p.getId().equals(wp.getPlotId())).map(p -> p.getType())
                    .findFirst().orElse(null);
            int refund = type != null ? (int)(type.getPurchasePrice() * 0.2) : 0;
            return ConfirmScreenHandler.makeItem(class_1802.field_8204, "§e§lYour Plot",
                    List.of("§8Chunk: §7" + loc.chunkX + ", " + loc.chunkZ,
                            "§7Type: " + typeColour(type) + (type != null ? type.getDisplayName() : "?"),
                            "§7Sell refund: §6$" + refund + " §7(20%)",
                            "",
                            "§eClick to sell this plot."));
        }

        return ConfirmScreenHandler.makeItem(class_1802.field_8077, "§c§lOwned Plot",
                List.of("§8Chunk: §7" + loc.chunkX + ", " + loc.chunkZ,
                        "§7Owner: §c" + resolvePlayerName(wp.getOwnerUuid(), player),
                        "§8Cannot purchase."));
    }

    private static class_1799 makeActionItem(WorldPlot wp, UUID playerUuid, ChunkKey currentKey,
                                             boolean multiMode, boolean chunkSelected, int selCount) {
        if (multiMode) {
            if (wp != null && wp.isAvailable()) {
                if (chunkSelected) {
                    return ConfirmScreenHandler.makeItem(class_1802.field_8686,
                            "§e§lDeselect This Plot",
                            List.of("§7Click to remove from selection.",
                                    "§7Selected: §e" + selCount + "/16"));
                } else {
                    return ConfirmScreenHandler.makeItem(
                            selCount >= 16 ? class_1802.field_8197 : class_1802.field_8637,
                            selCount >= 16 ? "§c§lSelection Full" : "§b§lSelect This Plot",
                            selCount >= 16
                                    ? List.of("§cMax 16 plots per purchase.",
                                              "§7Deselect a plot to free a slot.")
                                    : List.of("§7Click to add to selection.",
                                              "§7Selected: §b" + selCount + "/16"));
                }
            }
            // Not standing in available plot
            return ConfirmScreenHandler.makeItem(class_1802.field_8333,
                    "§7Select Plot",
                    List.of("§8Stand in an available plot to select it.",
                            "§7Selected: §7" + selCount + "/16"));
        }

        // Single mode — sell button when player owns this plot
        if (wp != null && wp.isOwned() && playerUuid.equals(wp.getOwnerUuid())) {
            PlotType type  = PlotManager.getInstance().getPlayerPlots(playerUuid).stream()
                    .filter(p -> p.getId().equals(wp.getPlotId())).map(p -> p.getType())
                    .findFirst().orElse(null);
            int refund = type != null ? (int)(type.getPurchasePrice() * 0.2) : 0;
            return ConfirmScreenHandler.makeItem(class_1802.field_8686, "§e§lSell This Plot",
                    List.of("§7You own this plot.",
                            "§7Refund: §6$" + refund + " §7(20%)"));
        }

        return ConfirmScreenHandler.makeFiller();
    }

    // =========================================================================
    // Helpers
    // =========================================================================

    private static String typeColour(PlotType type) {
        if (type == null) return "§7";
        return switch (type) {
            case PERSONAL   -> "§b";
            case FARM       -> "§a";
            case BUSINESS   -> "§5";
            case INDUSTRIAL -> "§c";
            case COMMUNITY  -> "§e";
        };
    }

    private static class_1792 typeIcon(PlotType type) {
        return switch (type) {
            case PERSONAL   -> class_1802.field_8270;
            case FARM       -> class_1802.field_17528;
            case BUSINESS   -> class_1802.field_8733;
            case INDUSTRIAL -> class_1802.field_8773;
            case COMMUNITY  -> class_1802.field_16539;
        };
    }

    private static String resolvePlayerName(UUID uuid, class_3222 requester) {
        var online = requester.method_5682().method_3760().method_14602(uuid);
        if (online != null) return online.method_5477().getString();
        return requester.method_5682().method_3793()
                .method_14512(uuid)
                .map(p -> p.getName())
                .orElse(uuid.toString().substring(0, 8) + "...");
    }
}
