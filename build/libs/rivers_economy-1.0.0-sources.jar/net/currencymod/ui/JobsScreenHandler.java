package net.currencymod.ui;

import net.currencymod.jobs.*;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3917;
import net.minecraft.class_747;
import net.minecraft.class_9290;
import net.minecraft.class_9334;
import net.currencymod.CurrencyMod;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static net.currencymod.ui.ConfirmScreenHandler.makeItem;
import static net.currencymod.ui.ConfirmScreenHandler.makeFiller;

/**
 * Main Jobs GUI – 6-row chest (54 slots).
 *
 * Layout:
 *   Row 0 [0-8]:   LEVEL(0) ■ ■ STREAK(3) ■ ■ SKIPS(6) ■ BOOSTER(8)
 *   Row 1 [9-17]:  all filler (visual padding)
 *   Row 2 [18-26]: ■ J1(19) J2(20) J3(21) ■ J4(23) J5(24) J6(25) ■
 *   Row 3 [27-35]: ■ J7(28) J8(29) J9(30) ■ J10(32) J11(33) J12(34) ■
 *   Row 4 [36-44]: all filler (visual padding)
 *   Row 5 [45-53]: ■ COMPLETE(46) ■ ABANDON(48) ■ SKIP(50) ■ ■ CLOSE(53)
 */
public class JobsScreenHandler extends class_1707 {

    // Row 0 – info bar
    private static final int SLOT_LEVEL   = 0;
    private static final int SLOT_STREAK  = 3;
    private static final int SLOT_SKIPS   = 6;
    private static final int SLOT_BOOSTER = 8;

    // Job slots (12 max across rows 2 and 3, split with gap in middle)
    private static final int[] JOB_SLOTS = {
        19, 20, 21,   // jobs 1-3
        23, 24, 25,   // jobs 4-6
        28, 29, 30,   // jobs 7-9
        32, 33, 34    // jobs 10-12
    };

    // Row 5 – action buttons
    private static final int SLOT_COMPLETE = 46;
    private static final int SLOT_ABANDON  = 48;
    private static final int SLOT_SKIP     = 50;
    private static final int SLOT_CLOSE    = 53;

    private final class_3222 player;
    private final Job[] renderedJobs = new Job[12];

    private JobsScreenHandler(int syncId, class_1661 playerInv,
                               class_1277 gui, class_3222 player,
                               Job[] renderedJobs) {
        super(class_3917.field_17327, syncId, playerInv, gui, 6);
        this.player = player;
        System.arraycopy(renderedJobs, 0, this.renderedJobs, 0, 12);
    }

    /** Opens (or re-opens) the Jobs GUI for the given player. */
    public static void open(class_3222 player) {
        Job[] renderedJobs = new Job[12];
        class_1277 gui = buildGui(player, renderedJobs);
        player.method_17355(new class_747(
            (syncId, inv, p) -> new JobsScreenHandler(syncId, inv, gui, player, renderedJobs),
            class_2561.method_43470("Jobs")
        ));
    }

    // -------------------------------------------------------------------------
    // GUI builder
    // -------------------------------------------------------------------------

    private static class_1277 buildGui(class_3222 player, Job[] renderedJobs) {
        class_1277 gui = new class_1277(54);
        class_1799 filler = makeFiller();
        for (int i = 0; i < 54; i++) gui.method_5447(i, filler.method_7972());

        JobManager        jm          = JobManager.getInstance();
        PlayerJobLevel    jobLevel    = jm.getPlayerJobLevel(player);
        PlayerJobStreak   jobStreak   = jm.getPlayerJobStreak(player);
        PlayerBoosterData boosterData = jm.getPlayerBoosterData(player);
        PlayerJobSkipData skipData    = jm.getPlayerSkipData(player);

        int[] bonuses       = JobManager.getBonusPercentages(jobLevel, jobStreak, boosterData);
        double totalMult    = 1.0 + bonuses[3] / 100.0;

        // Row 0: info bar
        gui.method_5447(SLOT_LEVEL,   makeLevelItem(jobLevel, bonuses));
        gui.method_5447(SLOT_STREAK,  makeStreakItem(jobStreak));
        gui.method_5447(SLOT_SKIPS,   makeSkipsItem(skipData));
        gui.method_5447(SLOT_BOOSTER, makeBoosterStatusItem(boosterData));

        // Job slots
        List<Job> jobs      = jm.getPlayerJobs(player);
        Job       activeJob = jm.getActiveJob(player);
        int       allowed   = jobLevel.getJobsAllowed();

        for (int i = 0; i < JOB_SLOTS.length; i++) {
            int guiSlot = JOB_SLOTS[i];
            if (i < jobs.size()) {
                Job job      = jobs.get(i);
                renderedJobs[i] = job;
                int adjQty   = JobManager.getAdjustedQuantity(job.getQuantity(), boosterData);
                int adjReward = (int) Math.ceil(job.getReward() * totalMult);
                boolean isActive = job.equals(activeJob);
                int haveCount = isActive ? jm.getItemCount(player, job.getItem()) : 0;
                gui.method_5447(guiSlot, makeJobItem(job, adjQty, adjReward, isActive, haveCount, bonuses));
            } else if (i < allowed) {
                renderedJobs[i] = null;
            } else {
                gui.method_5447(guiSlot, makeLockedSlot(unlockLevelForSlot(i)));
                renderedJobs[i] = null;
            }
        }

        // Row 5: action buttons
        boolean canComplete = activeJob != null &&
            jm.getItemCount(player, activeJob.getItem()) >=
            JobManager.getAdjustedQuantity(activeJob.getQuantity(), boosterData);

        gui.method_5447(SLOT_COMPLETE, makeCompleteButton(activeJob != null, canComplete));
        gui.method_5447(SLOT_ABANDON,  makeAbandonButton(activeJob != null));
        gui.method_5447(SLOT_SKIP,     makeSkipButton(activeJob != null, skipData.getSkipCount()));
        gui.method_5447(SLOT_CLOSE,    makeItem(class_1802.field_8077, "§c§lClose", List.of("§7Close this menu.")));

        return gui;
    }

    // -------------------------------------------------------------------------
    // Click handling
    // -------------------------------------------------------------------------

    @Override
    public void method_7593(int slotIndex, int button, class_1713 actionType, class_1657 player) {
        if (!(player instanceof class_3222 sp)) return;

        if (slotIndex == SLOT_CLOSE)    { sp.method_7346(); return; }
        if (slotIndex == SLOT_BOOSTER)  { sp.method_7346(); BoosterScreenHandler.open(sp); return; }
        if (slotIndex == SLOT_COMPLETE) { handleComplete(sp); return; }
        if (slotIndex == SLOT_ABANDON)  { handleAbandon(sp); return; }
        if (slotIndex == SLOT_SKIP)     { handleSkip(sp); return; }

        for (int i = 0; i < JOB_SLOTS.length; i++) {
            if (slotIndex == JOB_SLOTS[i]) { handleJobClick(sp, i); return; }
        }
        // Block everything else
    }

    private void handleJobClick(class_3222 sp, int jobIndex) {
        Job job = renderedJobs[jobIndex];
        if (job == null) return;

        JobManager jm     = JobManager.getInstance();
        Job        active = jm.getActiveJob(sp);

        if (job.equals(active)) return; // already active, use action buttons
        if (active != null) {
            sp.method_43496(class_2561.method_43470("§cYou already have an active job. Abandon or finish it first."));
            return;
        }
        jm.activateJob(sp, job.getId().toString());
        sp.method_7346();
        open(sp);
    }

    private void handleComplete(class_3222 sp) {
        JobManager jm     = JobManager.getInstance();
        Job        active = jm.getActiveJob(sp);
        if (active == null) { sp.method_43496(class_2561.method_43470("§cNo active job.")); return; }

        PlayerBoosterData bd     = jm.getPlayerBoosterData(sp);
        int adjQty = JobManager.getAdjustedQuantity(active.getQuantity(), bd);
        if (jm.getItemCount(sp, active.getItem()) < adjQty) {
            sp.method_43496(class_2561.method_43470("§cYou don't have enough items yet."));
            return;
        }
        PlayerJobLevel  jl = jm.getPlayerJobLevel(sp);
        PlayerJobStreak js = jm.getPlayerJobStreak(sp);
        int finalReward = (int) Math.ceil(active.getReward() * JobManager.getTotalMultiplier(jl, js, bd));
        String itemName = active.getItem().method_7848().getString();

        if (jm.completeJob(sp)) {
            sp.method_43496(class_2561.method_43470("§a§lJob Completed! §r§7Collected " + adjQty + " " + itemName + " • Earned §a$" + finalReward));
            sp.method_7346();
            open(sp);
        } else {
            sp.method_43496(class_2561.method_43470("§cFailed to complete job."));
        }
    }

    private void handleAbandon(class_3222 sp) {
        JobManager jm     = JobManager.getInstance();
        Job        active = jm.getActiveJob(sp);
        if (active == null) { sp.method_43496(class_2561.method_43470("§cNo active job to abandon.")); return; }

        PlayerJobLevel  jl = jm.getPlayerJobLevel(sp);
        PlayerJobStreak js = jm.getPlayerJobStreak(sp);
        int adjustedReward = (int) Math.ceil(active.getReward() * JobManager.getTotalMultiplier(jl, js));
        int penalty = active.isMegaJob() ? 0 : Math.max(1, (int)(adjustedReward * 0.75));

        List<String> lore = new ArrayList<>();
        lore.add("§7Collect " + active.getQuantity() + " " + active.getItem().method_7848().getString());
        lore.add(active.isMegaJob() ? "§aMEGA job — no penalty!" : "§cPenalty: §f$" + penalty);
        lore.add("");
        lore.add("§eConfirm to abandon and generate a new job.");

        sp.method_7346();
        ConfirmScreenHandler.open(sp, "Abandon Job?",
            active.getItem(),
            "§c§lAbandon: " + active.getItem().method_7848().getString(),
            lore,
            () -> { jm.abandonJob(sp); open(sp); },
            () -> open(sp));
    }

    private void handleSkip(class_3222 sp) {
        JobManager        jm       = JobManager.getInstance();
        Job               active   = jm.getActiveJob(sp);
        PlayerJobSkipData skipData = jm.getPlayerSkipData(sp);

        if (active == null)              { sp.method_43496(class_2561.method_43470("§cNo active job to skip.")); return; }
        if (skipData.getSkipCount() <= 0) { sp.method_43496(class_2561.method_43470("§cNo skips available.")); return; }

        List<String> lore = new ArrayList<>();
        lore.add("§7Skip: Collect " + active.getQuantity() + " " + active.getItem().method_7848().getString());
        lore.add("§7Skips remaining: §f" + skipData.getSkipCount());
        lore.add("");
        lore.add("§eUsing 1 skip. A new job will be generated.");

        sp.method_7346();
        ConfirmScreenHandler.open(sp, "Skip Job?",
            class_1802.field_8192,
            "§e§lSkip Current Job",
            lore,
            () -> { jm.useJobSkip(sp); open(sp); },
            () -> open(sp));
    }

    @Override
    public class_1799 method_7601(class_1657 player, int slot) { return class_1799.field_8037; }

    @Override
    public boolean method_7597(class_1657 player) { return true; }

    // -------------------------------------------------------------------------
    // Item builders
    // -------------------------------------------------------------------------

    private static class_1799 makeLevelItem(PlayerJobLevel jl, int[] bonuses) {
        int level    = jl.getLevel();
        int completed = jl.getCompletedJobs();
        int required  = jl.getRequiredJobsForNextLevel();
        boolean maxed = level >= PlayerJobLevel.MAX_LEVEL;

        List<String> lore = new ArrayList<>();
        lore.add("§7Level: §b§l" + level + "§r §7/ 30");
        lore.add(maxed ? "§a§lMax Level!" : "§7Progress: §f" + completed + " §7/ §f" + required + " jobs");
        lore.add("");
        if (bonuses[0] > 0) lore.add("§7Level bonus:   §a+" + bonuses[0] + "%");
        if (bonuses[1] > 0) lore.add("§7Streak bonus:  §b+" + bonuses[1] + "%");
        if (bonuses[2] > 0) lore.add("§7Booster bonus: §d+" + bonuses[2] + "%");
        if (bonuses[3] > 0) lore.add("§7Total bonus:   §a§l+" + bonuses[3] + "%");
        else                lore.add("§8No active bonuses.");

        return makeStackedItem(class_1802.field_8287, Math.max(1, Math.min(level, 64)),
            "§b§lLevel " + level, lore);
    }

    private static class_1799 makeStreakItem(PlayerJobStreak streak) {
        int days     = streak.getStreakLength();
        int bonusPct = (int)((streak.getStreakBonus() - 1.0) * 100);

        List<String> lore = new ArrayList<>();
        if (days == 0) {
            lore.add("§8No active streak.");
            lore.add("§7Complete a job each Minecraft day");
            lore.add("§7to build your streak.");
        } else {
            lore.add("§7Streak: §d§l" + days + " day" + (days == 1 ? "" : "s"));
            if (bonusPct > 0) lore.add("§7Bonus: §a+" + bonusPct + "%");
        }
        return makeStackedItem(class_1802.field_27063, Math.max(1, Math.min(days, 64)),
            "§d§lStreak", lore);
    }

    private static class_1799 makeSkipsItem(PlayerJobSkipData skipData) {
        int skips = skipData.getSkipCount();
        return makeStackedItem(class_1802.field_8192, Math.max(1, Math.min(skips, 64)),
            "§e§lJob Skips",
            List.of("§7Available: §e§l" + skips,
                    "§7Use the Skip button below",
                    "§7to skip a job without penalty."));
    }

    private static class_1799 makeBoosterStatusItem(PlayerBoosterData bd) {
        Booster active = bd.getActiveBooster();
        if (active != null) {
            BoosterType type = active.getType();
            boolean isPrem = type == BoosterType.PREMIUM;
            List<String> lore = new ArrayList<>();
            lore.add("§7+" + type.getRewardBonus() + "% reward bonus");
            if (type.getQuantityReduction() > 0) lore.add("§7-" + type.getQuantityReduction() + "% items");
            lore.add("§7Remaining: §f" + active.getFormattedRemainingTime());
            lore.add("");
            lore.add("§eClick to manage boosters.");
            return makeItem(class_1802.field_8557,
                (isPrem ? "§6" : "§b") + "§lActive: " + type.getDisplayName(), lore);
        }
        int basic   = bd.getBoosterCount(BoosterType.BASIC);
        int premium = bd.getBoosterCount(BoosterType.PREMIUM);
        return makeItem(class_1802.field_8463, "§6§lBoosters",
            List.of("§7Premium: §f" + premium, "§7Basic: §f" + basic, "", "§eClick to manage boosters."));
    }

    private static class_1799 makeJobItem(Job job, int adjQty, int adjReward,
                                          boolean isActive, int haveCount, int[] bonuses) {
        class_1799 stack = new class_1799(job.getItem());

        String prefix;
        if (job.isMegaJob() && isActive)  prefix = "§6§l[MEGA] §a§l[ACTIVE] ";
        else if (job.isMegaJob())          prefix = "§6§l[MEGA] ";
        else if (isActive)                 prefix = "§a§l[ACTIVE] ";
        else                               prefix = "§b";

        String displayName = prefix + job.getItem().method_7848().getString();

        List<String> lore = new ArrayList<>();
        lore.add("§7Collect: §f" + adjQty + " " + job.getItem().method_7848().getString());
        lore.add("§7Reward:  §a$" + adjReward);
        if (bonuses[3] > 0) lore.add("§7Bonus:   §a+" + bonuses[3] + "%");
        if (isActive) {
            lore.add("");
            lore.add("§7Progress: §f" + haveCount + " §7/ §f" + adjQty
                + " §7(" + (adjQty > 0 ? haveCount * 100 / adjQty : 0) + "%)");
        } else {
            lore.add("");
            lore.add("§eClick to activate.");
        }

        stack.method_57379(class_9334.field_49631,
            class_2561.method_43470(displayName).method_27694(s -> s.method_10978(false)));
        stack.method_57379(class_9334.field_49632, new class_9290(
            lore.stream()
                .map(line -> (class_2561) class_2561.method_43470(line).method_27694(s -> s.method_10978(false)))
                .collect(Collectors.toList())));

        // Enchant glow to highlight active job
        if (isActive) {
            stack.method_57379(class_9334.field_49641, true);
        }

        return stack;
    }

    private static class_1799 makeLockedSlot(int unlockLevel) {
        return makeItem(class_1802.field_8157,
            "§8§lLocked",
            List.of("§7Reach §bLevel " + unlockLevel + "§7 to unlock."));
    }

    private static class_1799 makeCompleteButton(boolean hasActive, boolean canComplete) {
        if (!hasActive)   return makeItem(class_1802.field_8298, "§7Complete Job", List.of("§8No active job."));
        if (canComplete)  return makeItem(class_1802.field_8131, "§a§lComplete Job",
            List.of("§7You have all the required items!", "§eClick to collect your reward."));
        return makeItem(class_1802.field_8273, "§b§lComplete Job",
            List.of("§7Job in progress...", "§7Collect all required items first."));
    }

    private static class_1799 makeAbandonButton(boolean hasActive) {
        if (!hasActive) return makeItem(class_1802.field_8298, "§7Abandon Job", List.of("§8No active job."));
        return makeItem(class_1802.field_8264, "§c§lAbandon Job",
            List.of("§7Give up the current job.", "§cA penalty will be charged.", "§eClick to confirm."));
    }

    private static class_1799 makeSkipButton(boolean hasActive, int skipsLeft) {
        if (!hasActive)    return makeItem(class_1802.field_8298, "§7Skip Job", List.of("§8No active job."));
        if (skipsLeft <= 0) return makeItem(class_1802.field_8298, "§7Skip Job",
            List.of("§8No skips available.", "§7Level up to earn more skips."));
        return makeItem(class_1802.field_8192, "§e§lSkip Job",
            List.of("§7Skips available: §e" + skipsLeft, "§7Skip without penalty.", "§eClick to confirm."));
    }

    private static class_1799 makeStackedItem(net.minecraft.class_1792 item, int count,
                                              String name, List<String> lore) {
        class_1799 stack = new class_1799(item, count);
        stack.method_57379(class_9334.field_49631,
            class_2561.method_43470(name).method_27694(s -> s.method_10978(false)));
        if (!lore.isEmpty()) {
            stack.method_57379(class_9334.field_49632, new class_9290(
                lore.stream()
                    .map(line -> (class_2561) class_2561.method_43470(line).method_27694(s -> s.method_10978(false)))
                    .collect(Collectors.toList())));
        }
        return stack;
    }

    private static int unlockLevelForSlot(int slotIndex) {
        if (slotIndex < 5)  return 0;
        if (slotIndex < 6)  return 5;
        if (slotIndex < 7)  return 10;
        if (slotIndex < 8)  return 15;
        if (slotIndex < 10) return 20;
        if (slotIndex < 11) return 25;
        return 30;
    }
}
