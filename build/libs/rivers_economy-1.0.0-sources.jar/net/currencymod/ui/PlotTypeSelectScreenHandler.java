package net.currencymod.ui;

import net.currencymod.plots.ChunkKey;
import net.currencymod.plots.PlotManager;
import net.currencymod.plots.PlotType;
import net.minecraft.class_124;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3917;
import net.minecraft.class_747;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;

/**
 * Admin chest UI — toggle which PlotTypes are enabled for a registered chunk.
 *
 * Layout (27 slots, 3 rows of 9):
 *   Row 0 (0-8):   all filler
 *   Row 1 (9-17):  slot 9 = filler, slots 10-16 = type toggles (max 7), slot 17 = filler
 *   Row 2 (18-26): all filler except slot 22 = Save button
 *
 * Clicking a type slot toggles its state locally.
 * Clicking Save persists to PlotManager and closes the screen.
 */
public class PlotTypeSelectScreenHandler extends class_1707 {

    private static final int SLOT_SAVE = 22;
    // Type slots: 10, 11, 12, 13, 14, 15, 16  (7 max)
    private static final int FIRST_TYPE_SLOT = 10;
    private static final int MAX_TYPES = 7;

    private final class_1277 gui;
    private final ChunkKey chunkKey;
    private final Set<PlotType> localEnabledTypes;
    private final PlotType[] orderedTypes;
    private final class_3222 admin;

    private PlotTypeSelectScreenHandler(int syncId, class_1661 playerInv, class_1277 gui,
                                         ChunkKey chunkKey, Set<PlotType> currentEnabledTypes,
                                         class_3222 admin) {
        super(class_3917.field_17326, syncId, playerInv, gui, 3);
        this.gui = gui;
        this.chunkKey = chunkKey;
        this.localEnabledTypes = EnumSet.copyOf(
                currentEnabledTypes.isEmpty() ? EnumSet.noneOf(PlotType.class) : currentEnabledTypes);
        this.orderedTypes = PlotType.values();
        this.admin = admin;
    }

    /**
     * Opens the plot-type configuration screen for the admin.
     *
     * @param admin           The admin player
     * @param chunkKey        The chunk being configured
     * @param currentEnabled  The types currently enabled for that chunk
     */
    public static void open(class_3222 admin, ChunkKey chunkKey, Set<PlotType> currentEnabled) {
        class_1277 gui = new class_1277(27);
        class_1799 filler = ConfirmScreenHandler.makeFiller();
        for (int i = 0; i < 27; i++) gui.method_5447(i, filler.method_7972());

        // Populate type slots
        PlotType[] types = PlotType.values();
        for (int i = 0; i < Math.min(types.length, MAX_TYPES); i++) {
            gui.method_5447(FIRST_TYPE_SLOT + i, makeTypeItem(types[i], currentEnabled.contains(types[i])));
        }

        // Save button
        gui.method_5447(SLOT_SAVE, ConfirmScreenHandler.makeItem(
                class_1802.field_8839,
                "§a§lSave",
                List.of("§7Click to save changes.")));

        admin.method_17355(new class_747(
                (syncId, inv, p) -> new PlotTypeSelectScreenHandler(
                        syncId, inv, gui, chunkKey, currentEnabled, admin),
                class_2561.method_43470("Configure Plot Types")));
    }

    @Override
    public void method_7593(int slotIndex, int button, class_1713 actionType, class_1657 player) {
        if (!(player instanceof class_3222 sp)) return;

        if (slotIndex == SLOT_SAVE) {
            sp.method_7346();
            PlotManager.getInstance().updateEnabledTypes(chunkKey, localEnabledTypes);
            sp.method_43496(class_2561.method_43470("Plot types saved for this chunk.").method_27692(class_124.field_1060));
            return;
        }

        // Check if a type slot was clicked
        if (slotIndex >= FIRST_TYPE_SLOT && slotIndex < FIRST_TYPE_SLOT + MAX_TYPES) {
            int typeIndex = slotIndex - FIRST_TYPE_SLOT;
            if (typeIndex < orderedTypes.length) {
                PlotType type = orderedTypes[typeIndex];
                // Toggle
                if (localEnabledTypes.contains(type)) {
                    localEnabledTypes.remove(type);
                } else {
                    localEnabledTypes.add(type);
                }
                // Refresh the slot item immediately
                gui.method_5447(slotIndex, makeTypeItem(type, localEnabledTypes.contains(type)));
            }
        }
        // All other slots: no-op (block interaction)
    }

    @Override
    public class_1799 method_7601(class_1657 player, int slot) { return class_1799.field_8037; }

    @Override
    public boolean method_7597(class_1657 player) { return true; }

    // -------------------------------------------------------------------------
    // Item builders
    // -------------------------------------------------------------------------

    private static class_1799 makeTypeItem(PlotType type, boolean enabled) {
        if (enabled) {
            return ConfirmScreenHandler.makeItem(
                    class_1802.field_8131,
                    "§a§l" + type.getDisplayName(),
                    List.of(
                            "§7Price: §6$" + type.getPurchasePrice(),
                            "§7Daily Tax: §6$" + type.getDailyTax() + "/day",
                            "§a● Enabled",
                            "§7Click to disable."
                    ));
        } else {
            return ConfirmScreenHandler.makeItem(
                    class_1802.field_8298,
                    "§7" + type.getDisplayName(),
                    List.of(
                            "§7Price: §6$" + type.getPurchasePrice(),
                            "§7Daily Tax: §6$" + type.getDailyTax() + "/day",
                            "§8○ Disabled",
                            "§7Click to enable."
                    ));
        }
    }
}
