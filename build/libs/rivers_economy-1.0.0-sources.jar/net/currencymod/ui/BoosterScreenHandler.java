package net.currencymod.ui;

import net.currencymod.jobs.Booster;
import net.currencymod.jobs.BoosterType;
import net.currencymod.jobs.JobManager;
import net.currencymod.jobs.PlayerBoosterData;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3917;
import net.minecraft.class_747;
import net.minecraft.class_9290;
import net.minecraft.class_9334;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static net.currencymod.ui.ConfirmScreenHandler.makeItem;
import static net.currencymod.ui.ConfirmScreenHandler.makeFiller;

/**
 * 3-row booster selection GUI.
 * Slot layout (27 slots):
 *   Row 0 [0-8]:   all filler
 *   Row 1 [9-17]:  filler | BASIC(10) | filler | PREMIUM(13) | filler | ACTIVE_INFO(16) | filler...
 *   Row 2 [18-26]: all filler except BACK(22)
 */
public class BoosterScreenHandler extends class_1707 {

    private static final int SLOT_BASIC   = 10;
    private static final int SLOT_PREMIUM = 13;
    private static final int SLOT_ACTIVE  = 16;
    private static final int SLOT_BACK    = 22;

    private final class_3222 player;

    private BoosterScreenHandler(int syncId, class_1661 playerInv,
                                  class_1277 gui, class_3222 player) {
        super(class_3917.field_17326, syncId, playerInv, gui, 3);
        this.player = player;
    }

    public static void open(class_3222 player) {
        class_1277 gui = buildGui(player);
        player.method_17355(new class_747(
            (syncId, inv, p) -> new BoosterScreenHandler(syncId, inv, gui, player),
            class_2561.method_43470("Boosters")
        ));
    }

    private static class_1277 buildGui(class_3222 player) {
        class_1277 gui = new class_1277(27);
        class_1799 filler = makeFiller();
        for (int i = 0; i < 27; i++) gui.method_5447(i, filler.method_7972());

        PlayerBoosterData bd = JobManager.getInstance().getPlayerBoosterData(player);

        gui.method_5447(SLOT_BASIC,   makeBoosterItem(BoosterType.BASIC,    bd.getBoosterCount(BoosterType.BASIC)));
        gui.method_5447(SLOT_PREMIUM, makeBoosterItem(BoosterType.PREMIUM,  bd.getBoosterCount(BoosterType.PREMIUM)));
        gui.method_5447(SLOT_ACTIVE,  makeActiveInfo(bd));
        gui.method_5447(SLOT_BACK,    makeItem(class_1802.field_19058, "§c§lBack", List.of("§7Return to Jobs.")));

        return gui;
    }

    @Override
    public void method_7593(int slotIndex, int button, class_1713 actionType, class_1657 player) {
        if (!(player instanceof class_3222 sp)) return;

        PlayerBoosterData bd = JobManager.getInstance().getPlayerBoosterData(sp);

        if (slotIndex == SLOT_BASIC) {
            if (bd.getBoosterCount(BoosterType.BASIC) <= 0) return;
            openBoosterConfirm(sp, BoosterType.BASIC, bd.getBoosterCount(BoosterType.BASIC));
            return;
        }
        if (slotIndex == SLOT_PREMIUM) {
            if (bd.getBoosterCount(BoosterType.PREMIUM) <= 0) return;
            openBoosterConfirm(sp, BoosterType.PREMIUM, bd.getBoosterCount(BoosterType.PREMIUM));
            return;
        }
        if (slotIndex == SLOT_BACK) {
            sp.method_7346();
            JobsScreenHandler.open(sp);
            return;
        }
        // Block all other interactions
    }

    private static void openBoosterConfirm(class_3222 player, BoosterType type, int count) {
        PlayerBoosterData bd = JobManager.getInstance().getPlayerBoosterData(player);
        if (bd.hasActiveBooster()) {
            player.method_7346();
            player.method_43496(class_2561.method_43470("§cYou already have an active booster! Wait for it to expire first."));
            JobsScreenHandler.open(player);
            return;
        }

        boolean isPremium = type == BoosterType.PREMIUM;
        String name = (isPremium ? "§6§l" : "§b§l") + type.getDisplayName();
        List<String> lore = new ArrayList<>();
        lore.add("§7+" + type.getRewardBonus() + "% reward bonus");
        if (type.getQuantityReduction() > 0) lore.add("§7-" + type.getQuantityReduction() + "% item requirements");
        lore.add("§7Duration: " + type.getDurationMinutes() + " minutes");
        lore.add("§7Owned: §f" + count);
        lore.add("");
        lore.add("§eClick §7to activate.");

        ConfirmScreenHandler.open(player,
            "Use " + type.getDisplayName() + "?",
            isPremium ? class_1802.field_8367 : class_1802.field_8463,
            name, lore,
            () -> {
                PlayerBoosterData bd2 = JobManager.getInstance().getPlayerBoosterData(player);
                if (bd2.hasActiveBooster()) {
                    player.method_43496(class_2561.method_43470("§cYou already have an active booster!"));
                } else if (!bd2.useBooster(type)) {
                    player.method_43496(class_2561.method_43470("§cYou don't have any " + type.getDisplayName() + "s!"));
                } else {
                    JobManager.getInstance().save();
                    player.method_43496(class_2561.method_43470("§aActivated §r" + type.getDisplayName()
                        + "§a! +" + type.getRewardBonus() + "% rewards for "
                        + type.getDurationMinutes() + " minutes."));
                }
                JobsScreenHandler.open(player);
            },
            () -> BoosterScreenHandler.open(player)
        );
    }

    @Override
    public class_1799 method_7601(class_1657 player, int slot) { return class_1799.field_8037; }

    @Override
    public boolean method_7597(class_1657 player) { return true; }

    // -------------------------------------------------------------------------
    // Item builders
    // -------------------------------------------------------------------------

    private static class_1799 makeBoosterItem(BoosterType type, int count) {
        boolean isPremium = type == BoosterType.PREMIUM;
        class_1799 stack = new class_1799(
            isPremium ? class_1802.field_8367 : class_1802.field_8463,
            Math.max(1, Math.min(count, 64)));

        String name = (isPremium ? "§6§l" : "§b§l") + type.getDisplayName();
        List<String> lore = new ArrayList<>();
        lore.add("§7+" + type.getRewardBonus() + "% reward bonus");
        if (type.getQuantityReduction() > 0) lore.add("§7-" + type.getQuantityReduction() + "% item requirements");
        lore.add("§7Duration: " + type.getDurationMinutes() + " min");
        lore.add("§7Owned: §f" + count);
        lore.add(count > 0 ? "" : "");
        lore.add(count > 0 ? "§eClick to use." : "§8None owned.");

        stack.method_57379(class_9334.field_49631,
            class_2561.method_43470(name).method_27694(s -> s.method_10978(false)));
        stack.method_57379(class_9334.field_49632, new class_9290(
            lore.stream()
                .map(line -> (class_2561) class_2561.method_43470(line).method_27694(s -> s.method_10978(false)))
                .collect(Collectors.toList())));
        return stack;
    }

    private static class_1799 makeActiveInfo(PlayerBoosterData bd) {
        Booster active = bd.getActiveBooster();
        if (active == null) {
            return makeItem(class_1802.field_8298, "§7Active Booster", List.of("§8None active."));
        }
        BoosterType type = active.getType();
        boolean isPremium = type == BoosterType.PREMIUM;
        List<String> lore = new ArrayList<>();
        lore.add("§7+" + type.getRewardBonus() + "% reward bonus");
        if (type.getQuantityReduction() > 0) lore.add("§7-" + type.getQuantityReduction() + "% item requirements");
        lore.add("§7Time remaining: §f" + active.getFormattedRemainingTime());
        return makeItem(class_1802.field_8557,
            (isPremium ? "§6" : "§b") + "§lActive: " + type.getDisplayName(), lore);
    }
}
