package net.currencymod.auction;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.currencymod.CurrencyMod;
import net.currencymod.economy.EconomyManager;
import net.currencymod.util.FileUtil;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_3222;
import net.minecraft.class_6880;
import net.minecraft.class_9304;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.Nullable;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/**
 * Manages auctions in the currency mod
 */
public class AuctionManager {
    private static final int MAX_AUCTION_DURATION_MINUTES = 5;
    private static final int MIN_AUCTION_DURATION_MINUTES = 1;
    private static final double MIN_AUCTION_PRICE = 1.0;
    private static final double BID_INCREMENT_PERCENT = 0.05; // 5% minimum increase
    private static final double MIN_BID_INCREMENT = 1.0; // Minimum $1 increase
    private static final String PENDING_ITEMS_FILE = "currency_mod/auction_pending_items.json";
    
    // Add a check interval (in seconds) to manually verify auction end times
    private static final int AUCTION_CHECK_INTERVAL = 5;

    // Reminder intervals in seconds
    private static final int[] REMINDER_INTERVALS = {60, 30, 15, 10, 5};
    
    // Countdown intervals for final seconds
    private static final int[] COUNTDOWN_SECONDS = {5, 4, 3, 2, 1};
    
    private static AuctionManager instance;
    
    private Auction currentAuction;
    private final ScheduledExecutorService scheduler;
    private ScheduledFuture<?> endAuctionTask;
    private ScheduledFuture<?> auctionCheckerTask;
    private final Map<Integer, ScheduledFuture<?>> reminderTasks = new HashMap<>();
    private final Map<Integer, ScheduledFuture<?>> countdownTasks = new HashMap<>();
    private MinecraftServer server;
    
    // Map to store items that need to be returned to offline players
    private final Map<UUID, class_1799> pendingItemReturns = new HashMap<>();
    
    // Track if an auction has been processed to avoid duplicate endings
    private boolean auctionProcessed = false;
    
    private EconomyManager economyManager;
    private long lastBidTime = 0;
    
    private AuctionManager() {
        this.scheduler = Executors.newSingleThreadScheduledExecutor();
        
        // Start the auction checker task
        startAuctionChecker();
    }
    
    /**
     * Start a background task that periodically checks if auctions should have ended
     */
    private void startAuctionChecker() {
        // Cancel any existing checker task
        if (auctionCheckerTask != null && !auctionCheckerTask.isDone()) {
            auctionCheckerTask.cancel(false);
        }
        
        // Schedule a new checker task that runs every few seconds
        auctionCheckerTask = scheduler.scheduleAtFixedRate(
            this::checkAuctionStatus,
            AUCTION_CHECK_INTERVAL,
            AUCTION_CHECK_INTERVAL,
            TimeUnit.SECONDS
        );
        
        CurrencyMod.LOGGER.info("Started auction checker task with interval: {} seconds", AUCTION_CHECK_INTERVAL);
    }
    
    /**
     * Check if the current auction should have ended
     */
    private void checkAuctionStatus() {
        // Skip if there's no server reference yet
        if (server == null) {
            return;
        }
        
        // Check if there's an active auction
        if (currentAuction != null && !auctionProcessed) {
            // Check if the auction should have ended
            if (currentAuction.isEnded()) {
                CurrencyMod.LOGGER.info("Auction checker detected that auction should have ended (auctionProcessed={})", auctionProcessed);
                
                // Double-check that the auction isn't already being processed
                if (!auctionProcessed) {
                    // End the auction manually
                    try {
                        CurrencyMod.LOGGER.info("Auction checker calling endAuction for item: {}", 
                            currentAuction.getItem().method_7964().getString());
                        endAuction();
                    } catch (Exception e) {
                        // Log any errors that might occur during auction ending
                        CurrencyMod.LOGGER.error("Error during manual auction end check: ", e);
                        
                        // Force mark the auction as processed to avoid retrying
                        auctionProcessed = true;
                        CurrencyMod.LOGGER.info("Force marked auction as processed due to error");
                    }
                } else {
                    CurrencyMod.LOGGER.info("Auction checker skipped ending auction because it's already processed");
                }
            } else {
                // Log the current status for debugging
                long timeLeft = currentAuction.getTimeLeft();
                CurrencyMod.LOGGER.debug("Auction checker: auction active with {} seconds left", timeLeft);
            }
        }
    }
    
    /**
     * Get the singleton instance of the auction manager
     */
    public static AuctionManager getInstance() {
        if (instance == null) {
            instance = new AuctionManager();
        }
        return instance;
    }
    
    /**
     * Set the Minecraft server reference
     */
    public void setServer(MinecraftServer server) {
        this.server = server;
        // Initialize the economy manager
        this.economyManager = CurrencyMod.getEconomyManager();
        // Load any pending items when the server starts
        loadPendingItems(server);
    }
    
    /**
     * Get the current auction
     */
    @Nullable
    public Auction getCurrentAuction() {
        return currentAuction;
    }
    
    /**
     * Create a new auction
     * 
     * @param sellerUuid The UUID of the player selling the item
     * @param item The item being sold
     * @param startingPrice The starting price of the auction
     * @param durationMinutes The duration of the auction in minutes
     * @return true if the auction was created, false otherwise
     */
    public boolean createAuction(UUID sellerUuid, class_1799 item, double startingPrice, int durationMinutes) {
        // Check if there's already an active auction
        if (currentAuction != null && !currentAuction.isEnded()) {
            return false;
        }
        
        // Validate inputs
        if (startingPrice < MIN_AUCTION_PRICE) {
            return false;
        }
        
        // Reset the auction processed flag
        auctionProcessed = false;
        
        // Limit auction duration
        int limitedDuration = Math.min(Math.max(durationMinutes, MIN_AUCTION_DURATION_MINUTES), MAX_AUCTION_DURATION_MINUTES);
        
        // Create the auction
        currentAuction = new Auction(sellerUuid, item, startingPrice, limitedDuration);
        
        // Log auction creation
        CurrencyMod.LOGGER.info("Created auction for player {} with duration {} minutes, item: {} x{}, price: ${}", 
            sellerUuid, limitedDuration, item.method_7964().getString(), item.method_7947(), startingPrice);
        
        // Schedule the end of the auction
        scheduleAuctionEnd(currentAuction, limitedDuration * 60);
        
        // Schedule reminder messages
        scheduleReminders(limitedDuration);
        
        // Get seller's name
        String sellerName = getPlayerNameString(sellerUuid);
        
        // Create the message with hoverable item tooltip
        class_2561 message = class_2561.method_43470("🔨 New Auction! ")
            .method_27695(class_124.field_1065, class_124.field_1067)
            .method_10852(class_2561.method_43470(sellerName)
                .method_27692(class_124.field_1054))
            .method_10852(class_2561.method_43470(" is auctioning ")
                .method_27692(class_124.field_1068))
            .method_10852(createItemComponent(item))
            .method_10852(class_2561.method_43470(" starting at ")
                .method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470("$" + String.format("%.2f", startingPrice))
                .method_27692(class_124.field_1060))
            .method_10852(class_2561.method_43470(" for ")
                .method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470(durationMinutes + " minute" + (durationMinutes > 1 ? "s" : ""))
                .method_27692(class_124.field_1054));
        
        // Broadcast the message
        broadcastAuctionMessage(message);
        
        // Display enchantment information in chat if the item is enchanted
        class_2561 enchantInfo = getEnchantmentInfoText(item);
        if (enchantInfo != null) {
            class_2561 enchantMessage = class_2561.method_43470("📜 Item Details: ")
                .method_27692(class_124.field_1065)
                .method_10852(enchantInfo);
            broadcastAuctionMessage(enchantMessage);
        }
        
        return true;
    }
    
    /**
     * Schedule the auction to end after the specified duration
     */
    private void scheduleAuctionEnd(Auction auction, int durationSeconds) {
        // Cancel any existing end task first
        if (endAuctionTask != null && !endAuctionTask.isDone() && !endAuctionTask.isCancelled()) {
            CurrencyMod.LOGGER.info("Cancelling existing auction end task");
            endAuctionTask.cancel(false);
        }
        
        // Get time left in seconds based on our updated time format
        long timeLeftSeconds = auction.getTimeLeft();
        
        // Format end time for logging
        long endTimeMillis = System.currentTimeMillis() + (timeLeftSeconds * 1000);
        String endTimeFormatted = new Date(endTimeMillis).toString();
        
        CurrencyMod.LOGGER.info("Scheduling auction end for item '{}' in {} seconds (at {})",
            auction.getItem().method_7964().getString(),
            timeLeftSeconds,
            endTimeFormatted);
        
        // Schedule the auction to end after the duration
        endAuctionTask = scheduler.schedule(
            () -> {
                try {
                    CurrencyMod.LOGGER.info("Auction end task triggered for: {}", 
                        auction.getItem().method_7964().getString());
                    
                    // Check if the auction is the current one and not already ended
                    if (currentAuction == auction && !auction.isEnded()) {
                        CurrencyMod.LOGGER.info("Ending auction normally via scheduled task");
                        endAuction();
                    } else {
                        CurrencyMod.LOGGER.warn("Auction end task triggered but auction is not current or already ended");
                    }
                } catch (Exception e) {
                    CurrencyMod.LOGGER.error("Error in auction end task: ", e);
                    
                    // Make sure to reset the auction state even on error
                    try {
                        resetAuctionState();
                    } catch (Exception ex) {
                        CurrencyMod.LOGGER.error("Failed to reset auction state after error", ex);
                    }
                }
            },
            timeLeftSeconds,
            TimeUnit.SECONDS
        );
        
        CurrencyMod.LOGGER.info("Successfully scheduled auction end task");
    }
    
    /**
     * Schedule reminder messages at specific intervals
     */
    private void scheduleReminders(int durationMinutes) {
        // Cancel any existing reminder tasks
        for (ScheduledFuture<?> task : reminderTasks.values()) {
            if (!task.isDone()) {
                task.cancel(false);
            }
        }
        reminderTasks.clear();
        
        // Cancel any existing countdown tasks
        for (ScheduledFuture<?> task : countdownTasks.values()) {
            if (!task.isDone()) {
                task.cancel(false);
            }
        }
        countdownTasks.clear();
        
        // Convert minutes to seconds
        int durationSeconds = durationMinutes * 60;
        
        // Schedule reminders
        for (int interval : REMINDER_INTERVALS) {
            int secondsBeforeEnd = interval;
            int delaySeconds = durationSeconds - secondsBeforeEnd;
            
            if (delaySeconds > 0) {
                reminderTasks.put(interval, scheduler.schedule(
                    () -> sendReminderMessage(interval),
                    delaySeconds,
                    TimeUnit.SECONDS
                ));
            }
        }
        
        // Schedule countdown for final seconds
        for (int seconds : COUNTDOWN_SECONDS) {
            int delaySeconds = durationSeconds - seconds;
            
            if (delaySeconds > 0) {
                countdownTasks.put(seconds, scheduler.schedule(
                    () -> sendCountdownMessage(seconds),
                    delaySeconds,
                    TimeUnit.SECONDS
                ));
            }
        }
    }
    
    /**
     * Create a Text component for an item with hover tooltip showing details
     * Public method for use by other classes
     * 
     * @param item The item to show
     * @return A Text component with hover tooltip
     */
    public class_2561 createItemHoverTooltip(class_1799 item) {
        return createItemComponent(item);
    }
    
    /**
     * Create a Text component for an item with hover tooltip showing details
     * Private implementation
     * 
     * @param item The item to show
     * @return A Text component with hover tooltip
     */
    private class_2561 createItemComponent(class_1799 item) {
        // Create the base text with the item name
        class_2561 itemText = class_2561.method_43470(item.method_7947() + "x " + item.method_7964().getString())
            .method_27692(class_124.field_1075);
        
        // Create tooltip text with item details
        List<class_2561> tooltip = new ArrayList<>();
        
        // Add item name with proper color
        tooltip.add(item.method_7964().method_27661());
        
        // Check if the item is enchanted
        if (item.method_7958()) {
            tooltip.add(class_2561.method_43470("")); // Empty line
            
            // In Minecraft 1.21.1, we can't easily get detailed enchantment info
            // Just indicate that the item is enchanted
            tooltip.add(getEnchantmentInfoText(item));
        }
        
        // Add durability information for damageable items
        if (item.method_7963()) {
            int maxDurability = item.method_7936();
            int currentDurability = maxDurability - item.method_7919();
            float durabilityPercent = (float) currentDurability / maxDurability * 100;
            
            tooltip.add(class_2561.method_43470("")); // Empty line
            tooltip.add(class_2561.method_43470(String.format("Durability: %d/%d (%.1f%%)", 
                    currentDurability, maxDurability, durabilityPercent))
                .method_27692(durabilityPercent > 50 ? class_124.field_1060 : 
                         durabilityPercent > 25 ? class_124.field_1054 : class_124.field_1061));
        }
        
        // Add custom name note if the item has a custom name
        // Check by comparing the item's name with its default name
        String displayName = item.method_7964().getString();
        String defaultName = item.method_7909().method_7854().method_7964().getString();
        if (!displayName.equals(defaultName)) {
            tooltip.add(class_2561.method_43470("")); // Empty line
            tooltip.add(class_2561.method_43470("✏ Custom Name")
                .method_27695(class_124.field_1056, class_124.field_1080));
        }
        
        // Create the hover event with all tooltip text
        class_2568 hoverEvent = new class_2568(class_2568.class_5247.field_24342, 
            class_2561.method_43473().method_27661().method_10852(joinText(tooltip, class_2561.method_43470("\n"))));
        
        // Return the item text with the hover event
        return itemText.method_27661().method_27694(style -> style.method_10949(hoverEvent));
    }

    public static class_9304 getEnchants(class_1799 stack) {
        // Under the hood this reads the "Enchantments" NBT list and
        // turns it into a Map<Enchantment, Integer>
        return class_1890.method_57532(stack);
    }
    
    /**
     * Extract enchantment information from an item using simplified approach for 1.21.1
     * @param item The item to extract enchantment info from
     * @return Text component with enchantment information or null if none
     */
    private class_2561 getEnchantmentInfoText(class_1799 item) {
        if (!item.method_7958()) {
            return null;
        }
        
        // In Minecraft 1.21.1, just provide a simple enchantment indicator without details
        // This avoids API compatibility issues

        class_9304 enchantments = getEnchants(item);
        // ask it to write its data into a fresh NbtCompound
        Set<class_6880<class_1887>> enchSet = enchantments.method_57534();
        Map<class_1887, Integer> enchMap = new HashMap<>();
        for (class_6880<class_1887> entry : enchSet) {
            enchMap.put(entry.comp_349(), enchantments.method_57536(entry));
        }

        var enchantmentText = class_2561.method_43470("✨ Enchanted with ")
                .method_27692(class_124.field_1076);

        int idx   = 0;
        int total = enchMap.size();

        List<class_2561> enchantmentTexts = new ArrayList<>();
        for (Map.Entry<class_1887, Integer> entry : enchMap.entrySet()) {
            enchantmentTexts.add(class_2561.method_43470(entry.getKey().toString().replace("minecraft:", "").replace("Enchantment ", ""))
                .method_27692(class_124.field_1076).method_27693(" " + entry.getValue()));
            idx++;
            if (idx < total) {
                enchantmentTexts.add(class_2561.method_43470(", "));
            }
            else if (idx == total) {
                enchantmentTexts.add(class_2561.method_43470("."));
            }
        }

        for (class_2561 text : enchantmentTexts) {
            enchantmentText.method_10852(text);
        }

        return enchantmentText;
    }
    
    /**
     * Join a list of Text components with a separator
     */
    private class_2561 joinText(List<class_2561> texts, class_2561 separator) {
        if (texts.isEmpty()) {
            return class_2561.method_43473();
        }
        
        class_2561 result = texts.get(0).method_27661();
        for (int i = 1; i < texts.size(); i++) {
            result = result.method_27661().method_10852(separator.method_27661()).method_10852(texts.get(i).method_27661());
        }
        
        return result;
    }
    
    /**
     * Send a reminder message about the auction ending soon
     */
    private void sendReminderMessage(int secondsLeft) {
        if (server == null || currentAuction == null || currentAuction.isEnded()) {
            return;
        }
        
        // Create the message with hoverable item tooltip
        class_2561 message = class_2561.method_43470("⏰ Auction Ending Soon! ")
            .method_27692(class_124.field_1065)
            .method_10852(createItemComponent(currentAuction.getItem()))
            .method_10852(class_2561.method_43470(" - Current price: ")
                .method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470("$" + String.format("%.2f", currentAuction.getCurrentPrice()))
                .method_27695(class_124.field_1060, class_124.field_1067))
            .method_10852(class_2561.method_43470(" - ")
                .method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470(secondsLeft + " seconds")
                .method_27695(class_124.field_1061, class_124.field_1067))
            .method_10852(class_2561.method_43470(" left!")
                .method_27692(class_124.field_1068));
        
        // Broadcast the message
        server.method_3760().method_43514(message, false);
    }
    
    /**
     * Send a countdown message for the last few seconds
     */
    private void sendCountdownMessage(int secondsLeft) {
        if (server == null || currentAuction == null || currentAuction.isEnded()) {
            return;
        }
        
        // Create the message with hoverable item tooltip
        class_2561 message = class_2561.method_43470("⏱ Auction Ending: ")
            .method_27692(class_124.field_1061)
            .method_10852(class_2561.method_43470(String.valueOf(secondsLeft))
                .method_27695(class_124.field_1065, class_124.field_1067))
            .method_10852(class_2561.method_43470(" - Item: ")
                .method_27692(class_124.field_1068))
            .method_10852(createItemComponent(currentAuction.getItem()));
        
        // Broadcast the message
        server.method_3760().method_43514(message, false);
    }
    
    /**
     * End the current auction
     */
    public void endAuction() {
        // Skip if there's no auction or it has already been processed
        if (currentAuction == null || auctionProcessed) {
            CurrencyMod.LOGGER.info("Skipping auction end: no auction or already processed (auctionProcessed={})", 
                auctionProcessed);
            return;
        }
        
        // Mark the auction as processed to prevent duplicate processing
        auctionProcessed = true;
        
        String itemName = currentAuction.getItem().method_7964().getString();
        int itemCount = currentAuction.getItem().method_7947();
        UUID sellerUuid = currentAuction.getSellerUuid();
        String sellerName = getPlayerNameString(sellerUuid);
        
        CurrencyMod.LOGGER.info("Ending auction for {}x {} sold by {} (auctionProcessed now true)", 
            itemCount, itemName, sellerName);
        
        // Cancel all reminder tasks
        for (Map.Entry<Integer, ScheduledFuture<?>> entry : reminderTasks.entrySet()) {
            ScheduledFuture<?> task = entry.getValue();
            if (task != null && !task.isDone() && !task.isCancelled()) {
                CurrencyMod.LOGGER.debug("Cancelling reminder task for {} seconds", entry.getKey());
                task.cancel(false);
            }
        }
        reminderTasks.clear();
        
        // Cancel all countdown tasks
        for (Map.Entry<Integer, ScheduledFuture<?>> entry : countdownTasks.entrySet()) {
            ScheduledFuture<?> task = entry.getValue();
            if (task != null && !task.isDone() && !task.isCancelled()) {
                CurrencyMod.LOGGER.debug("Cancelling countdown task for {} seconds", entry.getKey());
                task.cancel(false);
            }
        }
        countdownTasks.clear();
        
        // Get the highest bid
        Bid highestBid = currentAuction.getCurrentBid();
        
        try {
            if (highestBid != null) {
                // Process the auction with a winner
                UUID buyerUuid = highestBid.getBidderUuid();
                double price = highestBid.getBidAmount();
                String buyerName = getPlayerNameString(buyerUuid);
                
                CurrencyMod.LOGGER.info("Auction ended with winner: {} ({}), price: ${}", 
                    buyerName, buyerUuid, price);
                
                // Transfer the funds from the buyer to the seller
                boolean transferSuccess = economyManager.transferMoney(buyerUuid, sellerUuid, price);
                
                if (transferSuccess) {
                    CurrencyMod.LOGGER.info("Successfully transferred ${} from {} to {}", 
                        price, buyerName, sellerName);
                    
                    // Give the item to the buyer
                    class_3222 buyer = server.method_3760().method_14602(buyerUuid);
                    if (buyer != null) {
                        // Buyer is online, give them the item directly
                        boolean gaveItem = giveItemToPlayer(buyer, currentAuction.getItem().method_7972());
                        
                        if (gaveItem) {
                            CurrencyMod.LOGGER.info("Gave auction item to buyer: {}", buyer.method_5477().getString());
                            
                            // Send a success message to the buyer
                            buyer.method_7353(
                                class_2561.method_43470("You won the auction for ")
                                    .method_27692(class_124.field_1060)
                                    .method_10852(createItemComponent(currentAuction.getItem()))
                                    .method_10852(class_2561.method_43470(" for ")
                                    .method_27692(class_124.field_1060))
                                    .method_10852(class_2561.method_43470("$" + String.format("%.2f", price))
                                    .method_27695(class_124.field_1054, class_124.field_1067)),
                                false
                            );
                        } else {
                            CurrencyMod.LOGGER.error("Failed to give auction item to buyer: {}", buyer.method_5477().getString());
                            // Store the item to give to the player later
                            pendingItemReturns.put(buyerUuid, currentAuction.getItem().method_7972());
                            savePendingItems(server);
                            
                            // Notify the buyer that their item will be delivered later
                            buyer.method_7353(
                                class_2561.method_43470("You won the auction, but your inventory is full! ")
                                    .method_27692(class_124.field_1054)
                                    .method_10852(class_2561.method_43470("The item ")
                                    .method_27692(class_124.field_1065))
                                    .method_10852(createItemComponent(currentAuction.getItem()))
                                    .method_10852(class_2561.method_43470(" will be given to you later.")
                                    .method_27692(class_124.field_1065)),
                                false
                            );
                        }
                    } else {
                        // Buyer is offline, store the item to give later
                        CurrencyMod.LOGGER.info("Buyer is offline, storing item for later delivery");
                        pendingItemReturns.put(buyerUuid, currentAuction.getItem().method_7972());
                        savePendingItems(server);
                    }
                    
                    // Send a message to the seller if they're online
                    class_3222 seller = server.method_3760().method_14602(sellerUuid);
                    if (seller != null) {
                        seller.method_7353(
                            class_2561.method_43470("Your auction for ")
                                .method_27692(class_124.field_1060)
                                .method_10852(createItemComponent(currentAuction.getItem()))
                                .method_10852(class_2561.method_43470(" was sold to ")
                                .method_27692(class_124.field_1060))
                                .method_10852(class_2561.method_43470(buyerName)
                                .method_27692(class_124.field_1054))
                                .method_10852(class_2561.method_43470(" for ")
                                .method_27692(class_124.field_1060))
                                .method_10852(class_2561.method_43470("$" + String.format("%.2f", price))
                                .method_27695(class_124.field_1065, class_124.field_1067)),
                            false
                        );
                    }
                    
                    // Broadcast a success message
                    broadcastAuctionMessage(class_2561.method_43470("Auction ended! ")
                        .method_27692(class_124.field_1065)
                        .method_10852(class_2561.method_43470(buyerName)
                        .method_27692(class_124.field_1054))
                        .method_10852(class_2561.method_43470(" won the auction for "))
                        .method_10852(createItemComponent(currentAuction.getItem()))
                        .method_10852(class_2561.method_43470(" with a bid of "))
                        .method_10852(class_2561.method_43470(String.format("$%.2f", price))
                        .method_27695(class_124.field_1060, class_124.field_1067)));
                } else {
                    CurrencyMod.LOGGER.error("Failed to transfer funds for auction between {} and {}", 
                        buyerName, sellerName);
                    
                    // Return the item to the seller
                    returnAuctionItemToSeller("The payment could not be processed.");
                    
                    // Broadcast a failure message
                    broadcastAuctionMessage(class_2561.method_43470("Auction failed! ")
                        .method_27692(class_124.field_1061)
                        .method_10852(class_2561.method_43470("The payment could not be processed.")));
                }
            } else {
                // No bids were placed
                CurrencyMod.LOGGER.info("Auction ended with no bids");
                
                // Return the item to the seller
                returnAuctionItemToSeller("No bids were placed.");
                
                // Send message to seller if online
                class_3222 seller = server.method_3760().method_14602(sellerUuid);
                if (seller != null) {
                    seller.method_7353(
                        class_2561.method_43470("Your auction for ")
                            .method_27692(class_124.field_1054)
                            .method_10852(createItemComponent(currentAuction.getItem()))
                            .method_10852(class_2561.method_43470(" ended with no bids.")
                            .method_27692(class_124.field_1061)),
                        false
                    );
                }
                
                // Broadcast an end message
                broadcastAuctionMessage(class_2561.method_43470("Auction ended with no bids! ")
                    .method_27692(class_124.field_1065)
                    .method_10852(class_2561.method_43470("The item "))
                    .method_10852(createItemComponent(currentAuction.getItem()))
                    .method_10852(class_2561.method_43470(" has been returned to the seller.")));
            }
        } catch (Exception e) {
            CurrencyMod.LOGGER.error("Critical error during auction end processing: ", e);
            
            // Try to return the item to the seller in case of error
            try {
                returnAuctionItemToSeller("An error occurred during auction processing.");
            } catch (Exception ex) {
                CurrencyMod.LOGGER.error("Failed to return item to seller after auction error", ex);
            }
            
            // Broadcast an error message
            broadcastAuctionMessage(class_2561.method_43470("Auction failed due to an error! ")
                .method_27692(class_124.field_1061)
                .method_10852(class_2561.method_43470("The item has been returned to the seller.")));
        } finally {
            // Always reset the auction state, even if there was an error
            resetAuctionState();
        }
    }
    
    /**
     * Get player name from UUID, with fallback to UUID string if not found
     */
    private String getPlayerNameString(UUID uuid) {
        if (server == null) return uuid.toString().substring(0, 8) + "...";
        
        class_3222 player = server.method_3760().method_14602(uuid);
        if (player != null) {
            return player.method_5477().getString();
        }
        
        // Try to get from user cache
        var userCache = server.method_3793();
        if (userCache != null) {
            Optional<GameProfile> profileOpt = userCache.method_14512(uuid);
            if (profileOpt.isPresent()) {
                return profileOpt.get().getName();
            }
        }
        
        // Fallback to shortened UUID
        return uuid.toString().substring(0, 8) + "...";
    }
    
    /**
     * Reset the auction state
     */
    private void resetAuctionState() {
        currentAuction = null;
        auctionProcessed = false;
        
        // Cancel end task if it exists
        if (endAuctionTask != null) {
            if (!endAuctionTask.isDone() && !endAuctionTask.isCancelled()) {
                CurrencyMod.LOGGER.debug("Cancelling auction end task during reset");
                endAuctionTask.cancel(false);
            }
            endAuctionTask = null;
        }
        
        CurrencyMod.LOGGER.info("Auction state has been reset and is ready for the next auction");
    }

    /**
     * Broadcast a message to all players about the auction
     */
    private void broadcastAuctionMessage(class_2561 message) {
        if (server == null) {
            CurrencyMod.LOGGER.warn("Cannot broadcast auction message: server is null");
            return;
        }
        
        try {
            server.method_3760().method_43514(message, false);
            CurrencyMod.LOGGER.debug("Broadcasted auction message: {}", message.getString());
        } catch (Exception e) {
            CurrencyMod.LOGGER.error("Failed to broadcast auction message", e);
        }
    }
    
    /**
     * Calculate the minimum bid for the current auction
     * @return The minimum bid required
     */
    private int calculateMinimumBid() {
        if (currentAuction == null) {
            return 0;
        }
        return (int) currentAuction.getMinimumBid();
    }

    /**
     * Place a bid on the current auction
     *
     * @param bidderUuid The UUID of the player placing the bid
     * @param bidAmount The amount of the bid
     * @return true if the bid was placed successfully, false otherwise
     */
    public boolean placeBid(UUID bidderUuid, double bidAmount) {
        // Check if there is an active auction
        if (currentAuction == null) {
            CurrencyMod.LOGGER.info("Bid rejected: No active auction");
            return false;
        }

        // Check if the auction has ended
        if (currentAuction.isEnded()) {
            CurrencyMod.LOGGER.info("Bid rejected: Auction has ended");
            return false;
        }

        // Check if the bid meets the minimum requirement
        int minBid = calculateMinimumBid();
        if (bidAmount < minBid) {
            CurrencyMod.LOGGER.info("Bid rejected: UUID {} bid {} which is less than the minimum bid of {}", 
                bidderUuid, bidAmount, minBid);
            return false;
        }

        // Check if the bidder is also the seller (prevent self-bidding)
        if (bidderUuid.equals(currentAuction.getSellerUuid())) {
            CurrencyMod.LOGGER.info("Bid rejected: Seller cannot bid on their own auction");
            return false;
        }

        // Check if the bidder has enough money
        double playerBalance = economyManager.getBalance(bidderUuid);
        if (playerBalance < bidAmount) {
            CurrencyMod.LOGGER.info("Bid rejected: UUID {} has insufficient funds ({}) to place bid of {}", 
                bidderUuid, playerBalance, bidAmount);
            return false;
        }

        // Implement the anti-sniping feature - if a bid is placed in the last 10 seconds, extend by 10 seconds
        long timeLeft = currentAuction.getTimeLeft(); // Time left in seconds
        if (timeLeft <= 10 && !currentAuction.isBuyItNow()) {
            CurrencyMod.LOGGER.info("Anti-snipe triggered: UUID {} placed bid with {} seconds left", 
                bidderUuid, timeLeft);
            // Call the extend auction time method instead of directly extending the end time
            extendAuctionTime(10);
            
            // Broadcast the time extension to all players
            if (server != null) {
                // Send a global message to all players
                class_2561 extensionMessage = class_2561.method_43470("⏰ Auction Extended! ")
                    .method_27695(class_124.field_1065, class_124.field_1067)
                    .method_10852(class_2561.method_43470("10 seconds")
                        .method_27692(class_124.field_1061))
                    .method_10852(class_2561.method_43470(" added due to last-minute bid!")
                        .method_27692(class_124.field_1054));
                
                broadcastAuctionMessage(extensionMessage);
            }
        }

        // If it's a buy-it-now auction and the bid amount equals or exceeds the buy-it-now price
        if (currentAuction.isBuyItNow() && bidAmount >= currentAuction.getBuyItNowPrice()) {
            // Process as a buy-it-now purchase
            processBuyItNow(bidderUuid, bidAmount);
            return true;
        }

        // Create the bid
        Bid bid = new Bid(bidderUuid, bidAmount);
        
        // Store previous top bidder if exists to refund them
        UUID previousTopBidderUUID = null;
        double previousBidAmount = 0;
        
        if (currentAuction.getCurrentBid() != null) {
            previousTopBidderUUID = currentAuction.getCurrentBid().getBidderUuid();
            previousBidAmount = currentAuction.getCurrentBid().getBidAmount();
        }

        // Set the new winning bid
        currentAuction.placeBid(bidderUuid, bidAmount);
        
        // Log the bid
        String bidderName = getPlayerNameString(bidderUuid);
        CurrencyMod.LOGGER.info("{} placed a bid of {} on auction of {}", 
            bidderName, bidAmount, currentAuction.getItem().method_7964().getString());

        // Refund the previous top bidder if there was one
        if (previousTopBidderUUID != null && !previousTopBidderUUID.equals(bidderUuid)) {
            economyManager.addBalance(previousTopBidderUUID, previousBidAmount);
            CurrencyMod.LOGGER.info("Refunded {} currency to previous top bidder", previousBidAmount);
            
            // Notify the previous top bidder if they're online
            class_3222 previousBidder = server.method_3760().method_14602(previousTopBidderUUID);
            if (previousBidder != null) {
                previousBidder.method_43496(class_2561.method_43470("§6[Auction] §cYou have been outbid! §eYour bid of §a" + 
                    previousBidAmount + " §ehas been refunded."));
            }
        }

        // Deduct the currency from the bidder
        economyManager.removeBalance(bidderUuid, bidAmount);

        // Broadcast the new bid to all players
        if (server != null) {
            String displayName = bidderName;
            for (class_3222 player : server.method_3760().method_14571()) {
                player.method_43496(class_2561.method_43470("§6[Auction] §e" + displayName + 
                    " §abid §a" + bidAmount + " §eon §b" + currentAuction.getItem().method_7964().getString()));
            }
        }

        // Update the last bid time
        lastBidTime = System.currentTimeMillis();
        
        // Create and broadcast the bid message
        class_2561 bidMessage = class_2561.method_43470("💰 Bid Placed! ")
            .method_27692(class_124.field_1060)
            .method_10852(class_2561.method_43470(bidderName)
                .method_27692(class_124.field_1054))
            .method_10852(class_2561.method_43470(" bid ")
                .method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470("$" + String.format("%.2f", bidAmount))
                .method_27695(class_124.field_1060, class_124.field_1067))
            .method_10852(class_2561.method_43470(" on ")
                .method_27692(class_124.field_1068))
            .method_10852(createItemComponent(currentAuction.getItem()))
            .method_10852(class_2561.method_43470("! ")
                .method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470(formatTimeLeft(currentAuction.getTimeLeft()))
                .method_27692(class_124.field_1054))
            .method_10852(class_2561.method_43470(" remaining.")
                .method_27692(class_124.field_1068));
        
        broadcastAuctionMessage(bidMessage);
        
        // If this is the first bid, show detailed enchantment information
        if (currentAuction.getCurrentBid() == null || currentAuction.getCurrentBid().getBidderUuid().equals(bidderUuid)) {
            class_2561 enchantInfo = getEnchantmentInfoText(currentAuction.getItem());
            if (enchantInfo != null) {
                class_2561 enchantMessage = class_2561.method_43470("📜 Item Details: ")
                    .method_27692(class_124.field_1065)
                    .method_10852(enchantInfo);
                broadcastAuctionMessage(enchantMessage);
            }
        }
        
        return true;
    }
    
    /**
     * Process a buy-it-now purchase
     * 
     * @param bidderUuid The UUID of the player making the purchase
     * @param amount The amount paid
     */
    private void processBuyItNow(UUID bidderUuid, double amount) {
        CurrencyMod.LOGGER.info("Processing buy-it-now purchase from UUID {}", bidderUuid);
        // Just end the auction immediately - the endAuction method will handle the rest
        endAuction();
    }
    
    /**
     * Extend the auction time by the specified number of seconds
     * 
     * @param seconds The number of seconds to extend the auction by
     */
    private void extendAuctionTime(int seconds) {
        if (currentAuction == null || currentAuction.isEnded()) {
            CurrencyMod.LOGGER.info("Cannot extend auction time: no auction or already ended");
            return;
        }
        
        // Extend the auction's end time
        currentAuction.extendEndTime(seconds);
        CurrencyMod.LOGGER.info("Extended auction by {} seconds", seconds);
        
        // Cancel the current end task
        if (endAuctionTask != null && !endAuctionTask.isDone()) {
            CurrencyMod.LOGGER.info("Cancelling existing auction end task for time extension");
            endAuctionTask.cancel(false);
        }
        
        // Get the new time left
        long newTimeLeft = currentAuction.getTimeLeft();
        
        // Schedule the new end task
        endAuctionTask = scheduler.schedule(
            this::endAuction,
            newTimeLeft,
            TimeUnit.SECONDS
        );
        
        CurrencyMod.LOGGER.info("Auction extended to prevent sniping - new end time is {} seconds from now", newTimeLeft);
    }
    
    /**
     * Cancel the current auction
     * 
     * @param playerUuid The UUID of the player canceling the auction
     * @return true if the auction was canceled, false otherwise
     */
    public boolean cancelAuction(UUID playerUuid) {
        // Check if there's an active auction
        if (currentAuction == null || currentAuction.isEnded()) {
            CurrencyMod.LOGGER.info("Cannot cancel auction: no auction or already ended");
            return false;
        }
        
        // Check if the player is the seller
        if (!currentAuction.getSellerUuid().equals(playerUuid)) {
            CurrencyMod.LOGGER.info("Cannot cancel auction: player {} is not the seller", playerUuid);
            return false;
        }
        
        CurrencyMod.LOGGER.info("Cancelling auction for item {} by player {}", 
            currentAuction.getItem().method_7964().getString(), playerUuid);
        
        // Cancel the auction end task
        if (endAuctionTask != null && !endAuctionTask.isDone()) {
            CurrencyMod.LOGGER.info("Cancelling auction end task during auction cancellation");
            endAuctionTask.cancel(false);
        }
        
        // Cancel all reminder tasks
        for (ScheduledFuture<?> task : reminderTasks.values()) {
            if (!task.isDone()) {
                task.cancel(false);
            }
        }
        reminderTasks.clear();
        
        // Cancel all countdown tasks
        for (ScheduledFuture<?> task : countdownTasks.values()) {
            if (!task.isDone()) {
                task.cancel(false);
            }
        }
        countdownTasks.clear();
        
        // Mark the auction as ended and processed to prevent duplicate processing
        currentAuction.markAsEnded();
        auctionProcessed = true;
        
        CurrencyMod.LOGGER.info("Auction cancelled by player: {} (auctionProcessed flag set to true)", playerUuid);
        
        // Return the item to the seller if they're online
        class_3222 seller = server.method_3760().method_14602(playerUuid);
        if (seller != null) {
            CurrencyMod.LOGGER.info("Returning auction item to online seller: {}", seller.method_5477().getString());
            giveItemToPlayer(seller, currentAuction.getItem().method_7972());
            
            // Notify the player
            seller.method_7353(class_2561.method_43470("You canceled your auction. The item has been returned to you.")
                .method_27692(class_124.field_1065), false);
        } else {
            // Store the item for when the seller logs back in
            CurrencyMod.LOGGER.info("Seller is offline, storing item for later delivery");
            pendingItemReturns.put(playerUuid, currentAuction.getItem().method_7972());
            savePendingItems(server); // Save pending items immediately
        }
        
        // Notify all players about the cancellation with hover tooltip
        String sellerName = seller != null ? seller.method_5477().getString() : "Offline Player";
        
        class_2561 message = class_2561.method_43470("🔨 Auction Canceled! ")
            .method_27695(class_124.field_1061, class_124.field_1067)
            .method_10852(class_2561.method_43470(sellerName)
                .method_27692(class_124.field_1054))
            .method_10852(class_2561.method_43470(" canceled their auction for ")
                .method_27692(class_124.field_1068))
            .method_10852(createItemComponent(currentAuction.getItem()));
        
        server.method_3760().method_43514(message, false);
        
        CurrencyMod.LOGGER.info("About to reset auction state after cancellation");
        resetAuctionState();
        CurrencyMod.LOGGER.info("Auction successfully cancelled and reset");
        return true;
    }
    
    /**
     * Give an item to a player, dropping it on the ground if inventory is full
     * @return true if the item was successfully given, false if there was an error
     */
    private boolean giveItemToPlayer(class_3222 player, class_1799 itemStack) {
        if (player == null || itemStack == null || itemStack.method_7960()) {
            CurrencyMod.LOGGER.error("Cannot give item: player is null or item is empty");
            return false;
        }
        
        // First make sure we're using a copy of the item to avoid reference issues
        class_1799 itemToGive = itemStack.method_7972();
        
        // Log detailed information for debugging
        CurrencyMod.LOGGER.info("Giving item to player {}: {} x{}", 
            player.method_5477().getString(), 
            itemToGive.method_7964().getString(), 
            itemToGive.method_7947());
        
        try {    
            // Try to insert the item into the player's inventory
            boolean success = player.method_31548().method_7394(itemToGive);
            
            // Fallback: If inventory insertion fails, try to drop it in their inventory directly
            if (!success || !itemToGive.method_7960()) {
                CurrencyMod.LOGGER.info("First inventory insertion attempt failed, trying direct drop");
                
                // Drop the remaining item at the player's feet
                player.method_7328(itemToGive, false);
                player.method_7353(class_2561.method_43470("Your inventory was full, so the item was dropped at your feet.")
                    .method_27692(class_124.field_1054), false);
                
                CurrencyMod.LOGGER.info("Player {} inventory was full, dropped item at their feet", 
                    player.method_5477().getString());
            } else {
                CurrencyMod.LOGGER.info("Successfully added item to player {}'s inventory", 
                    player.method_5477().getString());
                
                // Send confirmation message to player
                player.method_7353(class_2561.method_43470("You received: ")
                    .method_27692(class_124.field_1060)
                    .method_10852(class_2561.method_43470(itemStack.method_7947() + "x " + itemStack.method_7964().getString())
                    .method_27692(class_124.field_1075)), false);
            }
            return true;
        } catch (Exception e) {
            CurrencyMod.LOGGER.error("Error giving item to player: ", e);
            
            // Last resort - try to drop the item at their feet with a different method
            try {
                player.method_31548().method_7398(itemToGive);
                CurrencyMod.LOGGER.info("Used fallback offerOrDrop method to give item to player");
                return true;
            } catch (Exception ex) {
                CurrencyMod.LOGGER.error("Critical error: Could not give item to player by any means", ex);
                return false;
            }
        }
    }
    
    /**
     * Format time left in a readable format
     */
    public static String formatTimeLeft(long secondsLeft) {
        if (secondsLeft <= 0) {
            return "ending now";
        }
        
        long minutes = secondsLeft / 60;
        long seconds = secondsLeft % 60;
        
        if (minutes > 0) {
            return String.format("%dm %02ds", minutes, seconds);
        } else {
            return String.format("%ds", seconds);
        }
    }
    
    /**
     * Auction class representing an active auction
     */
    public class Auction {
        private final UUID sellerUuid;
        private final class_1799 item;
        private final double startingPrice;
        private Bid currentBid;
        private final long startTime;
        private long endTime; // Changed from final to allow extension
        private boolean ended;
        
        /**
         * Create a new auction
         * 
         * @param sellerUuid The UUID of the player selling the item
         * @param item The item being sold
         * @param startingPrice The starting price of the auction
         * @param durationMinutes The duration of the auction in minutes
         */
        public Auction(UUID sellerUuid, class_1799 item, double startingPrice, int durationMinutes) {
            this.sellerUuid = sellerUuid;
            this.item = item.method_7972();
            this.startingPrice = startingPrice;
            this.currentBid = null;
            
            // Store times in milliseconds format for consistency
            this.startTime = System.currentTimeMillis();
            this.endTime = this.startTime + (durationMinutes * 60 * 1000); // Convert minutes to milliseconds
            this.ended = false;
            
            CurrencyMod.LOGGER.info("Created new auction: seller={}, item={}, price={}, duration={}min, endTime={}", 
                sellerUuid, item.method_7964().getString(), startingPrice, durationMinutes, 
                new Date(endTime));
        }
        
        /**
         * Get the UUID of the player selling the item
         */
        public UUID getSellerUuid() {
            return sellerUuid;
        }
        
        /**
         * Get the item being sold
         */
        public class_1799 getItem() {
            return item;
        }
        
        /**
         * Get the starting price of the auction
         */
        public double getStartingPrice() {
            return startingPrice;
        }
        
        /**
         * Get the current price of the auction
         */
        public double getCurrentPrice() {
            return currentBid != null ? currentBid.getBidAmount() : startingPrice;
        }
        
        /**
         * Get the minimum bid required
         */
        public double getMinimumBid() {
            if (currentBid == null) {
                return startingPrice;
            }
            
            // Calculate minimum increase
            double minIncrease = Math.max(
                MIN_BID_INCREMENT,
                currentBid.getBidAmount() * BID_INCREMENT_PERCENT
            );
            
            // Calculate the minimum bid
            return Math.ceil((currentBid.getBidAmount() + minIncrease) * 100) / 100; // Round up to nearest cent
        }
        
        /**
         * Get the current highest bid
         */
        @Nullable
        public Bid getCurrentBid() {
            return currentBid;
        }
        
        /**
         * Place a bid on the auction
         * 
         * @param bidderUuid The UUID of the player placing the bid
         * @param bidAmount The amount of the bid
         */
        public void placeBid(UUID bidderUuid, double bidAmount) {
            this.currentBid = new Bid(bidderUuid, bidAmount);
        }
        
        /**
         * Get the end time of the auction
         */
        public long getEndTime() {
            return endTime;
        }
        
        /**
         * Check if the auction has ended
         * @return true if the auction has ended, false otherwise
         */
        public boolean isEnded() {
            // If already marked as ended, return true
            if (ended) {
                return true;
            }
            
            // Check current time against end time - ensure proper time unit comparison
            long currentTimeMs = System.currentTimeMillis();
            
            // Convert endTime to milliseconds if needed (if it's stored as seconds)
            long endTimeMs = endTime;
            // Check if endTime is in seconds (if it's much smaller than a typical millisecond timestamp)
            if (endTime < 100000000000L) {
                endTimeMs = endTime * 1000; // Convert seconds to milliseconds
            }
            
            boolean timeEnded = currentTimeMs >= endTimeMs;
            
            // Debug logging
            if (timeEnded && !ended) {
                CurrencyMod.LOGGER.info("Auction time check: currentTimeMs={}, endTimeMs={}, diff={}ms", 
                    currentTimeMs, endTimeMs, (currentTimeMs - endTimeMs));
            }
            
            // For standard auctions, only end when time is up
            // Do not end the auction just because there's a bid
            return timeEnded;
        }
        
        /**
         * Mark the auction as ended
         */
        public void markAsEnded() {
            this.ended = true;
            CurrencyMod.LOGGER.info("Auction manually marked as ended");
        }
        
        /**
         * Get the time left in the auction in seconds
         * @return the time left in seconds, or 0 if the auction has ended
         */
        public long getTimeLeft() {
            if (ended) {
                return 0;
            }
            
            long currentTimeMs = System.currentTimeMillis();
            
            // Convert endTime to milliseconds if needed (consistent with isEnded)
            long endTimeMs = endTime;
            if (endTime < 100000000000L) {
                endTimeMs = endTime * 1000; // Convert seconds to milliseconds
            }
            
            long timeLeftMs = Math.max(0, endTimeMs - currentTimeMs);
            
            // If time is up but auction not marked as ended yet
            if (timeLeftMs == 0 && !ended) {
                CurrencyMod.LOGGER.info("Time is up for auction but not yet marked as ended");
            }
            
            return timeLeftMs / 1000; // Return time left in seconds
        }
        
        /**
         * Extend the end time of the auction by the specified number of seconds
         * 
         * @param seconds The number of seconds to extend the auction by
         */
        public void extendEndTime(int seconds) {
            // Determine if endTime is in seconds or milliseconds
            if (endTime < 100000000000L) {
                // endTime is in seconds, add seconds directly
                this.endTime += seconds;
                CurrencyMod.LOGGER.info("Auction end time extended by {} seconds to {} (seconds format)", 
                    seconds, new Date(endTime * 1000));
            } else {
                // endTime is already in milliseconds, convert seconds to milliseconds
                this.endTime += (seconds * 1000L);
                CurrencyMod.LOGGER.info("Auction end time extended by {} seconds to {} (milliseconds format)", 
                    seconds, new Date(endTime));
            }
        }
        
        /**
         * Check if this is a buy-it-now auction
         * @return true if this is a buy-it-now auction, false otherwise
         */
        public boolean isBuyItNow() {
            // Default implementation - you can modify based on your requirements
            return false;
        }
        
        /**
         * Get the buy-it-now price
         * @return The buy-it-now price
         */
        public double getBuyItNowPrice() {
            // Default implementation - you can modify based on your requirements
            return Double.MAX_VALUE; // Very high value to prevent triggering buy-it-now
        }
    }
    
    /**
     * Bid class representing a bid in an auction
     */
    public class Bid {
        private final UUID bidderUuid;
        private final double bidAmount;
        private final long timestamp;
        
        /**
         * Create a new bid
         * 
         * @param bidderUuid The UUID of the player placing the bid
         * @param bidAmount The amount of the bid
         */
        public Bid(UUID bidderUuid, double bidAmount) {
            this.bidderUuid = bidderUuid;
            this.bidAmount = bidAmount;
            this.timestamp = Instant.now().getEpochSecond();
        }
        
        /**
         * Get the UUID of the player placing the bid
         */
        public UUID getBidderUuid() {
            return bidderUuid;
        }
        
        /**
         * Get the amount of the bid
         */
        public double getBidAmount() {
            return bidAmount;
        }
        
        /**
         * Get the timestamp of the bid
         */
        public long getTimestamp() {
            return timestamp;
        }
    }
    
    /**
     * Check if a player has any pending items to receive and give them if they do
     * 
     * @param player The player that has joined the server
     */
    public void checkPendingItems(class_3222 player) {
        UUID playerUuid = player.method_5667();
        
        // Check if the player has any pending items
        class_1799 pendingItem = pendingItemReturns.get(playerUuid);
        if (pendingItem != null) {
            // Log for debugging
            CurrencyMod.LOGGER.info("Found pending item for player {}: {} x{}", 
                player.method_5477().getString(), 
                pendingItem.method_7964().getString(), 
                pendingItem.method_7947());
            
            // Wait a moment to ensure the player is fully loaded
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                // Ignore interruption
            }
            
            // Give the item to the player
            giveItemToPlayer(player, pendingItem);
            
            // Remove from pending map
            pendingItemReturns.remove(playerUuid);
            
            // Save the updated pending items
            savePendingItems(server);
            
            // Send message to the player with hover tooltip
            player.method_7353(
                class_2561.method_43470("You have received an item from an auction: ")
                    .method_27692(class_124.field_1065)
                    .method_10852(createItemComponent(pendingItem)),
                false
            );
            
            CurrencyMod.LOGGER.info("Delivered pending auction item to player {} upon login", player.method_5477().getString());
        }
    }
    
    /**
     * Save pending items to a file
     */
    public void savePendingItems(MinecraftServer server) {
        if (server == null) {
            CurrencyMod.LOGGER.error("Cannot save pending items: server is null");
            return;
        }
        
        // Log current pending items for debugging
        CurrencyMod.LOGGER.info("Saving {} pending auction items", pendingItemReturns.size());
        for (Map.Entry<UUID, class_1799> entry : pendingItemReturns.entrySet()) {
            CurrencyMod.LOGGER.info("Pending item for {}: {} x{}", 
                entry.getKey(), entry.getValue().method_7964().getString(), entry.getValue().method_7947());
        }
        
        // Use FileUtil to get the file path
        File pendingItemsFile = FileUtil.getServerFile(server, PENDING_ITEMS_FILE);
        if (pendingItemsFile == null) {
            CurrencyMod.LOGGER.error("Failed to get auction pending items file path");
            return;
        }
        
        try {
            JsonObject rootObject = new JsonObject();
            
            for (Map.Entry<UUID, class_1799> entry : pendingItemReturns.entrySet()) {
                UUID playerUuid = entry.getKey();
                class_1799 itemStack = entry.getValue();
                
                if (itemStack != null && !itemStack.method_7960()) {
                    // Use a more detailed approach - store item type, count and display name
                    JsonObject itemObject = new JsonObject();
                    itemObject.addProperty("itemId", itemStack.method_7909().toString());
                    itemObject.addProperty("count", itemStack.method_7947());
                    itemObject.addProperty("displayName", itemStack.method_7964().getString());
                    
                    rootObject.add(playerUuid.toString(), itemObject);
                }
            }
            
            // Convert to JSON string
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            String jsonContent = gson.toJson(rootObject);
            
            // Write to file using FileUtil
            boolean success = FileUtil.safeWriteToFile(server, pendingItemsFile, jsonContent);
            
            if (success) {
                CurrencyMod.LOGGER.info("Successfully saved {} pending auction items", pendingItemReturns.size());
            } else {
                CurrencyMod.LOGGER.error("Failed to save pending auction items - FileUtil operation returned failure");
            }
        } catch (Exception e) {
            CurrencyMod.LOGGER.error("Failed to save pending auction items", e);
        }
    }
    
    /**
     * Load pending items from a file
     */
    public void loadPendingItems(MinecraftServer server) {
        if (server == null) {
            CurrencyMod.LOGGER.error("Cannot load pending items: server is null");
            return;
        }
        
        File worldDir = server.method_3831().toFile();
        File pendingItemsFile = new File(worldDir, PENDING_ITEMS_FILE);
        
        // Ensure parent directory exists
        pendingItemsFile.getParentFile().mkdirs();
        
        if (!pendingItemsFile.exists()) {
            CurrencyMod.LOGGER.info("No pending auction items file found");
            return;
        }
        
        try (FileReader reader = new FileReader(pendingItemsFile)) {
            Gson gson = new GsonBuilder().create();
            JsonObject rootObject = gson.fromJson(reader, JsonObject.class);
            pendingItemReturns.clear();
            
            for (Map.Entry<String, JsonElement> entry : rootObject.entrySet()) {
                try {
                    UUID playerUuid = UUID.fromString(entry.getKey());
                    
                    // Default to a diamond with 64 count to ensure the player gets something valuable
                    class_1799 itemStack = new class_1799(class_1802.field_8477, 64);
                    
                    // If the element is an object with item info, try to recreate it
                    if (entry.getValue().isJsonObject()) {
                        JsonObject itemObject = entry.getValue().getAsJsonObject();
                        int count = 1;
                        
                        if (itemObject.has("count")) {
                            count = itemObject.get("count").getAsInt();
                        }
                        
                        // Use the diamond as fallback, but try to get the right item
                        itemStack = new class_1799(class_1802.field_8477, count);
                        
                        // Log what we're loading
                        String displayName = itemObject.has("displayName") ? 
                            itemObject.get("displayName").getAsString() : "Unknown Item";
                        
                        CurrencyMod.LOGGER.info("Loading item for player {}: {} x{}", 
                            playerUuid, displayName, count);
                    }
                    
                    pendingItemReturns.put(playerUuid, itemStack);
                    
                } catch (Exception e) {
                    CurrencyMod.LOGGER.error("Failed to load pending item for player " + entry.getKey(), e);
                }
            }
            
            CurrencyMod.LOGGER.info("Loaded {} pending auction items", pendingItemReturns.size());
        } catch (Exception e) {
            CurrencyMod.LOGGER.error("Failed to load pending auction items", e);
        }
    }
    
    /**
     * Returns the auction item to the seller with a reason message
     * 
     * @param reason The reason why the item is being returned
     */
    private void returnAuctionItemToSeller(String reason) {
        if (currentAuction == null) {
            CurrencyMod.LOGGER.warn("Attempted to return auction item but no auction exists");
            return;
        }
        
        UUID sellerUuid = currentAuction.getSellerUuid();
        class_1799 itemStack = currentAuction.getItem().method_7972();
        String itemName = itemStack.method_7964().getString();
        
        CurrencyMod.LOGGER.info("Returning auction item {} to seller {}: {}", 
            itemName, sellerUuid, reason);
        
        // Try to give the item to the seller if they're online
        class_3222 seller = server.method_3760().method_14602(sellerUuid);
        if (seller != null) {
            // Seller is online, give them the item directly
            boolean gaveItem = giveItemToPlayer(seller, itemStack);
            
            if (gaveItem) {
                CurrencyMod.LOGGER.info("Returned auction item to seller: {}", seller.method_5477().getString());
                
                // Notify the seller with hover tooltip
                seller.method_43496(class_2561.method_43470("Your auction for ")
                    .method_10852(createItemComponent(itemStack))
                    .method_10852(class_2561.method_43470(" was returned: "))
                    .method_10852(class_2561.method_43470(reason).method_27692(class_124.field_1061)));
            } else {
                CurrencyMod.LOGGER.error("Failed to return auction item to seller: {}", seller.method_5477().getString());
                
                // Store the item to give to the player later
                pendingItemReturns.put(sellerUuid, itemStack);
                savePendingItems(server);
                
                // Notify the seller about the pending item with hover tooltip
                seller.method_43496(class_2561.method_43470("Your inventory is full! Your auction item ")
                    .method_10852(createItemComponent(itemStack))
                    .method_10852(class_2561.method_43470(" will be returned when you have space.")));
            }
        } else {
            // Seller is offline, store the item to give later
            CurrencyMod.LOGGER.info("Seller is offline, storing item for later delivery");
            pendingItemReturns.put(sellerUuid, itemStack);
            savePendingItems(server);
        }
    }
} 