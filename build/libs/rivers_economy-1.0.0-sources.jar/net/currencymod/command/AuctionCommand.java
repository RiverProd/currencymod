package net.currencymod.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.currencymod.CurrencyMod;
import net.currencymod.auction.AuctionManager;
import net.currencymod.economy.EconomyManager;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_3222;
import net.minecraft.class_7157;
import net.minecraft.server.MinecraftServer;

import java.util.List;
import java.util.UUID;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class AuctionCommand {

    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("HH:mm:ss");

    // Auction limits
    private static final int MIN_DURATION = 1; // 1 minute
    private static final int MAX_DURATION = 5; // 5 minutes
    private static final double MIN_PRICE = 1.0; // Minimum starting price

    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 commandRegistryAccess, class_2170.class_5364 registrationEnvironment) {
        dispatcher.register(
            class_2170.method_9247("auction")
                .then(class_2170.method_9247("create")
                    .then(class_2170.method_9244("startingPrice", DoubleArgumentType.doubleArg(MIN_PRICE))
                        .then(class_2170.method_9244("durationMinutes", IntegerArgumentType.integer(MIN_DURATION, MAX_DURATION))
                            .executes(context -> createAuction(
                                context,
                                DoubleArgumentType.getDouble(context, "startingPrice"),
                                IntegerArgumentType.getInteger(context, "durationMinutes")
                            ))
                        )
                    )
                )
                .then(class_2170.method_9247("view")
                    .executes(AuctionCommand::viewCurrentAuction)
                )
                .then(class_2170.method_9247("cancel")
                    .executes(AuctionCommand::cancelAuction)
                )
                .executes(context -> showHelp(context.getSource()))
        );
    }

    /**
     * Show help information for the auction command
     */
    private static int showHelp(class_2168 source) {
        source.method_9226(() -> class_2561.method_43470("=== Auction Commands ===")
            .method_27692(class_124.field_1065), false);
        
        source.method_9226(() -> class_2561.method_43470("/auction create <startingPrice> <durationMinutes>")
            .method_27692(class_124.field_1054)
            .method_10852(class_2561.method_43470(" - Create an auction with the item in your hand")
                .method_27692(class_124.field_1068)), false);
        
        source.method_9226(() -> class_2561.method_43470("/auction view")
            .method_27692(class_124.field_1054)
            .method_10852(class_2561.method_43470(" - View the current auction")
                .method_27692(class_124.field_1068)), false);
        
        source.method_9226(() -> class_2561.method_43470("/auction cancel")
            .method_27692(class_124.field_1054)
            .method_10852(class_2561.method_43470(" - Cancel your auction")
                .method_27692(class_124.field_1068)), false);
        
        source.method_9226(() -> class_2561.method_43470("/bid <amount>")
            .method_27692(class_124.field_1054)
            .method_10852(class_2561.method_43470(" - Place a bid on the current auction")
                .method_27692(class_124.field_1068)), false);
        
        return 1;
    }

    /**
     * Create an auction with the item in hand
     */
    private static int createAuction(CommandContext<class_2168> context, double startingPrice, int durationMinutes) {
        class_2168 source = context.getSource();
        
        try {
            class_3222 player = source.method_44023();
            
            // Get the item in the player's main hand
            class_1799 itemInHand = player.method_5998(class_1268.field_5808);
            
            // Check if the player is holding an item
            if (itemInHand.method_7960()) {
                source.method_9213(class_2561.method_43470("You must hold an item in your main hand to create an auction.")
                    .method_27692(class_124.field_1061));
                return 0;
            }
            
            // Make a copy of the item to auction
            class_1799 auctionItem = itemInHand.method_7972();
            
            // Create the auction
            AuctionManager auctionManager = AuctionManager.getInstance();
            boolean success = auctionManager.createAuction(player.method_5667(), auctionItem, startingPrice, durationMinutes);
            
            if (!success) {
                source.method_9213(class_2561.method_43470("Could not create auction. There may already be an active auction.")
                    .method_27692(class_124.field_1061));
                return 0;
            }
            
            // Remove the item from the player's hand
            player.method_6122(class_1268.field_5808, class_1799.field_8037);
            
            // Notify the seller
            source.method_9226(() -> class_2561.method_43470("You created an auction for ")
                .method_27692(class_124.field_1060)
                .method_10852(class_2561.method_43470(auctionItem.method_7947() + "x " + auctionItem.method_7964().getString())
                    .method_27692(class_124.field_1075))
                .method_10852(class_2561.method_43470(" starting at ")
                    .method_27692(class_124.field_1060))
                .method_10852(class_2561.method_43470("$" + String.format("%.2f", startingPrice))
                    .method_27692(class_124.field_1065))
                .method_10852(class_2561.method_43470(" for ")
                    .method_27692(class_124.field_1060))
                .method_10852(class_2561.method_43470(durationMinutes + " minute" + (durationMinutes == 1 ? "" : "s"))
                    .method_27692(class_124.field_1054)), false);
            
            return 1;
        } catch (Exception e) {
            source.method_9213(class_2561.method_43470("This command can only be executed by a player."));
            return 0;
        }
    }
    
    /**
     * View the current auction
     */
    private static int viewCurrentAuction(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        AuctionManager auctionManager = AuctionManager.getInstance();
        AuctionManager.Auction auction = auctionManager.getCurrentAuction();
        
        if (auction == null || auction.isEnded()) {
            source.method_9226(() -> class_2561.method_43470("There is no active auction.")
                .method_27692(class_124.field_1054), false);
            return 0;
        }
        
        // Get seller name
        String sellerName = getPlayerName(source, auction.getSellerUuid());
        
        // Format time left
        long timeLeftSeconds = auction.getTimeLeft();
        String timeLeftFormatted = AuctionManager.formatTimeLeft(timeLeftSeconds);
        
        // Format auction details
        class_1799 item = auction.getItem();
        
        final class_2561 auctionInfo = class_2561.method_43470("🔨 Current Auction ")
            .method_27692(class_124.field_1065)
            .method_10852(class_2561.method_43470("\n")
                .method_27692(class_124.field_1070))
            .method_10852(class_2561.method_43470("Item: ")
                .method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470(item.method_7947() + "x " + item.method_7964().getString())
                .method_27692(class_124.field_1075))
            .method_10852(class_2561.method_43470("\nSeller: ")
                .method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470(sellerName)
                .method_27692(class_124.field_1054))
            .method_10852(class_2561.method_43470("\nCurrent Price: ")
                .method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470("$" + String.format("%.2f", auction.getCurrentPrice()))
                .method_27695(class_124.field_1060, class_124.field_1067));
        
        // Add highest bidder if there is one
        AuctionManager.Bid currentBid = auction.getCurrentBid();
        final class_2561 finalAuctionInfo;
        if (currentBid != null) {
            String bidderName = getPlayerName(source, currentBid.getBidderUuid());
            finalAuctionInfo = auctionInfo.method_27661()
                .method_10852(class_2561.method_43470("\nHighest Bidder: ")
                    .method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470(bidderName)
                    .method_27692(class_124.field_1076))
                .method_10852(class_2561.method_43470("\nMinimum Bid: ")
                    .method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470("$" + String.format("%.2f", auction.getMinimumBid()))
                    .method_27695(class_124.field_1065, class_124.field_1067))
                .method_10852(class_2561.method_43470("\nTime Left: ")
                    .method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470(timeLeftFormatted)
                    .method_27692(class_124.field_1061));
        } else {
            finalAuctionInfo = auctionInfo.method_27661()
                .method_10852(class_2561.method_43470("\nMinimum Bid: ")
                    .method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470("$" + String.format("%.2f", auction.getMinimumBid()))
                    .method_27695(class_124.field_1065, class_124.field_1067))
                .method_10852(class_2561.method_43470("\nTime Left: ")
                    .method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470(timeLeftFormatted)
                    .method_27692(class_124.field_1061));
        }
        
        source.method_9226(() -> finalAuctionInfo, false);
        
        // Show suggested bids to players who aren't the seller
        try {
            class_3222 player = source.method_44023();
            if (!player.method_5667().equals(auction.getSellerUuid())) {
                showSuggestedBids(player, auction);
            }
        } catch (Exception e) {
            // Not a player, ignore
        }
        
        return 1;
    }
    
    /**
     * Cancel the current auction
     */
    private static int cancelAuction(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        try {
            class_3222 player = source.method_44023();
            AuctionManager auctionManager = AuctionManager.getInstance();
            
            boolean success = auctionManager.cancelAuction(player.method_5667());
            
            if (!success) {
                AuctionManager.Auction auction = auctionManager.getCurrentAuction();
                if (auction == null || auction.isEnded()) {
                    source.method_9213(class_2561.method_43470("There is no active auction to cancel.")
                        .method_27692(class_124.field_1061));
                } else if (!auction.getSellerUuid().equals(player.method_5667())) {
                    source.method_9213(class_2561.method_43470("You cannot cancel someone else's auction.")
                        .method_27692(class_124.field_1061));
                } else {
                    source.method_9213(class_2561.method_43470("The auction could not be canceled.")
                        .method_27692(class_124.field_1061));
                }
                return 0;
            }
            
            return 1;
        } catch (Exception e) {
            source.method_9213(class_2561.method_43470("This command can only be executed by a player."));
            return 0;
        }
    }
    
    /**
     * Show suggested bid amounts to a player
     */
    private static void showSuggestedBids(class_3222 player, AuctionManager.Auction auction) {
        double currentPrice = auction.getCurrentPrice();
        double minBid = auction.getMinimumBid();
        
        // Generate some suggested bids
        double[] suggestions = new double[3];
        suggestions[0] = minBid; // Minimum bid
        suggestions[1] = Math.ceil((minBid * 1.5) * 100) / 100; // 50% more than minimum
        suggestions[2] = Math.ceil((minBid * 2.0) * 100) / 100; // Double the minimum
        
        // Create clickable bid options
        class_2561 message = class_2561.method_43470("📊 Quick Bid Options: ")
            .method_27692(class_124.field_1054);
        
        for (int i = 0; i < suggestions.length; i++) {
            if (i > 0) {
                message = message.method_27661().method_10852(class_2561.method_43470(" | ").method_27692(class_124.field_1080));
            }
            
            double amount = suggestions[i];
            message = message.method_27661().method_10852(
                class_2561.method_43470("$" + String.format("%.2f", amount))
                    .method_27692(class_124.field_1060)
                    .method_27694(style -> style
                        .method_10958(new class_2558(class_2558.class_2559.field_11750, "/bid " + amount))
                        .method_10949(new class_2568(class_2568.class_5247.field_24342, 
                            class_2561.method_43470("Click to bid $" + String.format("%.2f", amount))
                                .method_27692(class_124.field_1065))))
            );
        }
        
        // Add a custom bid option
        message = message.method_27661()
            .method_10852(class_2561.method_43470(" | ").method_27692(class_124.field_1080))
            .method_10852(
                class_2561.method_43470("Custom Bid")
                    .method_27692(class_124.field_1075)
                    .method_27694(style -> style
                        .method_10958(new class_2558(class_2558.class_2559.field_11745, "/bid "))
                        .method_10949(new class_2568(class_2568.class_5247.field_24342, 
                            class_2561.method_43470("Enter a custom bid amount")
                                .method_27692(class_124.field_1065))))
            );
        
        player.method_7353(message, false);
    }
    
    /**
     * Broadcast a message about a new auction
     */
    private static void broadcastNewAuction(class_2168 source, class_3222 seller, class_1799 item, double startingPrice, int durationMinutes) {
        String sellerName = seller.method_5477().getString();
        
        // Calculate end time
        LocalDateTime endTime = LocalDateTime.now().plusMinutes(durationMinutes);
        String formattedEndTime = endTime.format(TIME_FORMATTER);
        
        // Get the auction manager
        AuctionManager auctionManager = AuctionManager.getInstance();
        
        // Create the message with hover tooltip for the item
        class_2561 itemComponent = auctionManager.createItemHoverTooltip(item);
        
        class_2561 message = class_2561.method_43470("🔨 New Auction! ")
            .method_27692(class_124.field_1065)
            .method_10852(class_2561.method_43470(sellerName)
                .method_27692(class_124.field_1054))
            .method_10852(class_2561.method_43470(" is auctioning "))
            .method_10852(itemComponent)
            .method_10852(class_2561.method_43470("\nStarting bid: ")
                .method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470("$" + String.format("%.2f", startingPrice))
                .method_27695(class_124.field_1060, class_124.field_1067))
            .method_10852(class_2561.method_43470(" • Ends in: ")
                .method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470(durationMinutes + " minutes")
                .method_27692(class_124.field_1061))
            .method_10852(class_2561.method_43470(" (" + formattedEndTime + ")")
                .method_27692(class_124.field_1080))
            .method_10852(class_2561.method_43470("\nType ")
                .method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470("/bid <amount>")
                .method_27695(class_124.field_1054, class_124.field_1056))
            .method_10852(class_2561.method_43470(" to place a bid!")
                .method_27692(class_124.field_1068));
        
        // Broadcast to all players
        MinecraftServer server = source.method_9211();
        server.method_3760().method_43514(message, false);
        
        // Log the auction creation
        CurrencyMod.LOGGER.info("{} created an auction for {}x {} at ${} for {} minutes", 
            sellerName, item.method_7947(), item.method_7964().getString(), startingPrice, durationMinutes);
    }
    
    /**
     * Get a player's name from their UUID
     */
    private static String getPlayerName(class_2168 source, UUID uuid) {
        // Try to get from the player manager
        class_3222 player = source.method_9211().method_3760().method_14602(uuid);
        if (player != null) {
            return player.method_5477().getString();
        }
        
        // Try to get from the user cache
        if (source.method_9211().method_3793() != null) {
            var playerOpt = source.method_9211().method_3793().method_14512(uuid);
            if (playerOpt.isPresent()) {
                return playerOpt.get().getName();
            }
        }
        
        // Return a shortened UUID if we can't find the name
        return shortenUuid(uuid);
    }
    
    /**
     * Shorten a UUID for display
     */
    private static String shortenUuid(UUID uuid) {
        String uuidStr = uuid.toString();
        return uuidStr.substring(0, 8);
    }
} 
