package net.currencymod.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import net.currencymod.CurrencyMod;
import net.currencymod.economy.EconomyManager;
import net.currencymod.services.Service;
import net.currencymod.services.ServiceManager;
import net.currencymod.services.ServiceSubscription;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_5250;
import net.minecraft.class_7157;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

/**
 * Command handler for service management.
 */
public class ServiceCommand {
    
    /**
     * Suggestion provider for update fields.
     */
    private static final SuggestionProvider<class_2168> UPDATE_FIELD_SUGGESTIONS = 
        (context, builder) -> {
            builder.suggest("Price");
            builder.suggest("ContractDays");
            return builder.buildFuture();
        };
    
    /**
     * Register the service command.
     */
    public static void register(CommandDispatcher<class_2168> dispatcher, 
                               class_7157 registryAccess, 
                               class_2170.class_5364 environment) {
        dispatcher.register(
            method_9247("service")
                .executes(ServiceCommand::showHelp)
                .then(method_9247("create")
                    .then(method_9244("tag", StringArgumentType.word())
                        .then(method_9244("dailyPrice", IntegerArgumentType.integer(1))
                            .then(method_9244("contractDays", IntegerArgumentType.integer(0))
                                .executes(ServiceCommand::createService)
                            )
                        )
                    )
                )
                .then(method_9247("delete")
                    .then(method_9244("tag", StringArgumentType.word())
                        .executes(ServiceCommand::deleteService)
                        .then(method_9247("confirm")
                            .executes(context -> confirmDeleteService(context, StringArgumentType.getString(context, "tag")))
                        )
                    )
                )
                .then(method_9247("view")
                    .then(method_9244("tag", StringArgumentType.word())
                        .executes(context -> viewService(context, StringArgumentType.getString(context, "tag")))
                    )
                )
                .then(method_9247("update")
                    .then(method_9244("tag", StringArgumentType.word())
                        .then(method_9244("field", StringArgumentType.word())
                            .suggests(UPDATE_FIELD_SUGGESTIONS)
                            .then(method_9244("value", IntegerArgumentType.integer(1))
                                .executes(ServiceCommand::updateService)
                            )
                        )
                    )
                )
                .then(method_9247("subscribe")
                    .then(method_9244("tag", StringArgumentType.word())
                        .executes(context -> subscribeToService(context, StringArgumentType.getString(context, "tag")))
                        .then(method_9247("confirm")
                            .executes(context -> confirmSubscribe(context, StringArgumentType.getString(context, "tag")))
                        )
                    )
                )
                .then(method_9247("unsubscribe")
                    .then(method_9244("tag", StringArgumentType.word())
                        .executes(context -> unsubscribeFromService(context, StringArgumentType.getString(context, "tag")))
                        .then(method_9247("confirm")
                            .executes(context -> confirmUnsubscribe(context, StringArgumentType.getString(context, "tag")))
                        )
                    )
                )
                .then(method_9247("subscriptions")
                    .executes(ServiceCommand::listSubscriptions)
                )
        );
    }
    
    /**
     * Show help message.
     */
    private static int showHelp(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        class_5250 help = class_2561.method_43470("=== Service Commands ===\n")
            .method_27695(class_124.field_1065, class_124.field_1067);
        
        help.method_10852(class_2561.method_43470("Provider Commands:\n").method_27692(class_124.field_1068));
        help.method_10852(class_2561.method_43470("  /service create <Tag> <DailyPrice> <ContractDays>\n").method_27692(class_124.field_1068));
        help.method_10852(class_2561.method_43470("  /service delete <Tag>\n").method_27692(class_124.field_1068));
        help.method_10852(class_2561.method_43470("  /service view <Tag>\n").method_27692(class_124.field_1068));
        help.method_10852(class_2561.method_43470("  /service update <Tag> <Price|ContractDays> <Value>\n").method_27692(class_124.field_1068));
        
        help.method_10852(class_2561.method_43470("\nSubscriber Commands:\n").method_27692(class_124.field_1068));
        help.method_10852(class_2561.method_43470("  /service subscribe <Tag>\n").method_27692(class_124.field_1068));
        help.method_10852(class_2561.method_43470("  /service unsubscribe <Tag>\n").method_27692(class_124.field_1068));
        help.method_10852(class_2561.method_43470("  /service subscriptions\n").method_27692(class_124.field_1068));
        
        source.method_9226(() -> help, false);
        return 1;
    }
    
    /**
     * Create a service.
     */
    private static int createService(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be executed by a player"));
            return 0;
        }
        
        String tag = StringArgumentType.getString(context, "tag");
        int dailyPrice = IntegerArgumentType.getInteger(context, "dailyPrice");
        int contractDays = IntegerArgumentType.getInteger(context, "contractDays");
        
        if (tag.length() > 3) {
            source.method_9213(class_2561.method_43470("Service tag must be 3 letters or less"));
            return 0;
        }
        
        ServiceManager manager = ServiceManager.getInstance();
        boolean success = manager.createService(player, tag, dailyPrice, contractDays);
        
        if (success) {
            class_5250 message = class_2561.method_43470("Service ")
                .method_27692(class_124.field_1068)
                .method_10852(class_2561.method_43470(tag.toUpperCase()).method_27695(class_124.field_1054, class_124.field_1067))
                .method_10852(class_2561.method_43470(" created successfully!\n").method_27692(class_124.field_1068));
            message.method_10852(class_2561.method_43470("  Daily Price: ").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470("$" + dailyPrice).method_27692(class_124.field_1065));
            message.method_10852(class_2561.method_43470("\n  Contract Days: ").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470(contractDays == 0 ? "None" : String.valueOf(contractDays))
                    .method_27692(class_124.field_1075));
            
            source.method_9226(() -> message, false);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Failed to create service. Tag may already exist."));
            return 0;
        }
    }
    
    /**
     * Delete a service (with confirmation).
     */
    private static int deleteService(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be executed by a player"));
            return 0;
        }
        
        String tag = StringArgumentType.getString(context, "tag");
        ServiceManager manager = ServiceManager.getInstance();
        Service service = manager.getService(tag);
        
        if (service == null) {
            source.method_9213(class_2561.method_43470("Service not found"));
            return 0;
        }
        
        if (!service.getProviderUuid().equals(player.method_5667())) {
            source.method_9213(class_2561.method_43470("You can only delete your own services"));
            return 0;
        }
        
        List<UUID> subscribers = manager.getServiceSubscribers(tag);
        int subscriberCount = subscribers.size();
        
        class_5250 message = class_2561.method_43470("⚠️ Warning: ").method_27695(class_124.field_1061, class_124.field_1067)
            .method_10852(class_2561.method_43470("Deleting service ").method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470(tag.toUpperCase()).method_27695(class_124.field_1054, class_124.field_1067))
            .method_10852(class_2561.method_43470(" will unsubscribe ").method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470(String.valueOf(subscriberCount)).method_27692(class_124.field_1061))
            .method_10852(class_2561.method_43470(" subscriber(s).\n").method_27692(class_124.field_1068));
        message.method_10852(class_2561.method_43470("Type ").method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470("/service delete " + tag + " confirm").method_27692(class_124.field_1061))
            .method_10852(class_2561.method_43470(" to confirm.").method_27692(class_124.field_1068));
        
        source.method_9226(() -> message, false);
        return 1;
    }
    
    /**
     * Confirm and delete a service.
     */
    private static int confirmDeleteService(CommandContext<class_2168> context, String tag) {
        class_2168 source = context.getSource();
        
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be executed by a player"));
            return 0;
        }
        
        ServiceManager manager = ServiceManager.getInstance();
        boolean success = manager.deleteService(player, tag);
        
        if (success) {
            source.method_9226(() -> class_2561.method_43470("Service ")
                .method_27692(class_124.field_1068)
                .method_10852(class_2561.method_43470(tag.toUpperCase()).method_27695(class_124.field_1054, class_124.field_1067))
                .method_10852(class_2561.method_43470(" deleted successfully.").method_27692(class_124.field_1068)), false);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Failed to delete service. You may not own this service."));
            return 0;
        }
    }
    
    /**
     * View a service.
     */
    private static int viewService(CommandContext<class_2168> context, String tag) {
        class_2168 source = context.getSource();
        
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be executed by a player"));
            return 0;
        }
        
        ServiceManager manager = ServiceManager.getInstance();
        Service service = manager.getService(tag);
        
        if (service == null) {
            source.method_9213(class_2561.method_43470("Service not found"));
            return 0;
        }
        
        if (!service.getProviderUuid().equals(player.method_5667())) {
            source.method_9213(class_2561.method_43470("You can only view your own services"));
            return 0;
        }
        
        List<UUID> subscribers = manager.getServiceSubscribers(tag);
        
        class_5250 message = class_2561.method_43470("=== Service ").method_27695(class_124.field_1065, class_124.field_1067)
            .method_10852(class_2561.method_43470(tag.toUpperCase()).method_27695(class_124.field_1054, class_124.field_1067))
            .method_10852(class_2561.method_43470(" ===\n").method_27695(class_124.field_1065, class_124.field_1067));
        
        message.method_10852(class_2561.method_43470("Daily Price: ").method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470("$" + service.getDailyPrice()).method_27692(class_124.field_1065));
        message.method_10852(class_2561.method_43470("\nContract Days: ").method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470(service.getContractDays() == 0 ? "None" : String.valueOf(service.getContractDays()))
                .method_27692(class_124.field_1075));
        message.method_10852(class_2561.method_43470("\nTotal Revenue: ").method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470("$" + String.format("%.2f", service.getTotalRevenue())).method_27692(class_124.field_1065));
        message.method_10852(class_2561.method_43470("\nSubscribers: ").method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470(String.valueOf(subscribers.size())).method_27692(class_124.field_1054));
        
        if (!subscribers.isEmpty()) {
            message.method_10852(class_2561.method_43470("\n\nSubscriber List:").method_27692(class_124.field_1068));
            for (UUID subscriberUuid : subscribers) {
                ServiceSubscription subscription = manager.getSubscription(subscriberUuid, tag);
                if (subscription != null) {
                    // Use stored username, or try to get current username if online
                    String playerName = subscription.getSubscriberName();
                    class_3222 onlinePlayer = source.method_9211().method_3760().method_14602(subscriberUuid);
                    if (onlinePlayer != null) {
                        // Update stored name if player is online (in case they changed their name)
                        playerName = onlinePlayer.method_5477().getString();
                    }
                    
                    message.method_10852(class_2561.method_43470("\n  • ").method_27692(class_124.field_1068))
                        .method_10852(class_2561.method_43470(playerName).method_27692(class_124.field_1075))
                        .method_10852(class_2561.method_43470(" - Days Paid: ").method_27692(class_124.field_1068))
                        .method_10852(class_2561.method_43470(String.valueOf(subscription.getDaysPaid())).method_27692(class_124.field_1075));
                    
                    if (subscription.getContractDays() > 0) {
                        int remaining = subscription.getRemainingContractDays();
                        message.method_10852(class_2561.method_43470(" (Contract: ").method_27692(class_124.field_1080))
                            .method_10852(class_2561.method_43470(String.valueOf(remaining)).method_27692(class_124.field_1054))
                            .method_10852(class_2561.method_43470(" days remaining)").method_27692(class_124.field_1080));
                    }
                }
            }
        }
        
        source.method_9226(() -> message, false);
        return 1;
    }
    
    /**
     * Update a service.
     */
    private static int updateService(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be executed by a player"));
            return 0;
        }
        
        String tag = StringArgumentType.getString(context, "tag");
        String field = StringArgumentType.getString(context, "field");
        int value = IntegerArgumentType.getInteger(context, "value");
        
        if (!field.equalsIgnoreCase("Price") && !field.equalsIgnoreCase("ContractDays")) {
            source.method_9213(class_2561.method_43470("Field must be 'Price' or 'ContractDays'"));
            return 0;
        }
        
        ServiceManager manager = ServiceManager.getInstance();
        boolean success = manager.updateService(player, tag, field, value);
        
        if (success) {
            class_5250 message = class_2561.method_43470("Service ")
                .method_27692(class_124.field_1068)
                .method_10852(class_2561.method_43470(tag.toUpperCase()).method_27695(class_124.field_1054, class_124.field_1067))
                .method_10852(class_2561.method_43470(" updated successfully!\n").method_27692(class_124.field_1068));
            message.method_10852(class_2561.method_43470("  ").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470(field).method_27692(class_124.field_1075))
                .method_10852(class_2561.method_43470(" set to: ").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470(String.valueOf(value)).method_27692(class_124.field_1065));

            if (field.equalsIgnoreCase("Price")) {
                message.method_10852(class_2561.method_43470("\n  Note: ").method_27692(class_124.field_1068))
                    .method_10852(class_2561.method_43470("This price now applies to all current and future subscribers.")
                        .method_27692(class_124.field_1054));
            } else {
                message.method_10852(class_2561.method_43470("\n  Note: ").method_27692(class_124.field_1068))
                    .method_10852(class_2561.method_43470("This contract change only affects new subscribers.")
                        .method_27692(class_124.field_1054));
            }
            
            source.method_9226(() -> message, false);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Failed to update service. You may not own this service."));
            return 0;
        }
    }
    
    /**
     * Subscribe to a service (with confirmation).
     */
    private static int subscribeToService(CommandContext<class_2168> context, String tag) {
        class_2168 source = context.getSource();
        
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be executed by a player"));
            return 0;
        }
        
        ServiceManager manager = ServiceManager.getInstance();
        Service service = manager.getService(tag);
        
        if (service == null) {
            source.method_9213(class_2561.method_43470("Service not found"));
            return 0;
        }
        
        if (manager.hasSubscription(player.method_5667(), tag)) {
            source.method_9213(class_2561.method_43470("You are already subscribed to this service"));
            return 0;
        }
        
        EconomyManager economyManager = CurrencyMod.getEconomyManager();
        double balance = economyManager.getBalance(player.method_5667());
        
        int dailyPrice = service.getDailyPrice();
        int contractDays = service.getContractDays();
        
        class_5250 message = class_2561.method_43470("Subscribe to service ").method_27692(class_124.field_1068)
            .method_10852(class_2561.method_43470(tag.toUpperCase()).method_27695(class_124.field_1054, class_124.field_1067))
            .method_10852(class_2561.method_43470("?\n").method_27692(class_124.field_1068));
        
        if (contractDays == 0) {
            int upfrontCost = dailyPrice * 10;
            message.method_10852(class_2561.method_43470("  You will pay ").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470("$" + upfrontCost).method_27692(class_124.field_1065))
                .method_10852(class_2561.method_43470(" upfront for the first 10 days.\n").method_27692(class_124.field_1068));
            message.method_10852(class_2561.method_43470("  After 10 days, you will be charged ").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470("$" + dailyPrice).method_27692(class_124.field_1065))
                .method_10852(class_2561.method_43470(" per day you are online.\n").method_27692(class_124.field_1068));
            
            if (balance < upfrontCost) {
                message.method_10852(class_2561.method_43470("\n  ⚠️ Insufficient funds! ").method_27692(class_124.field_1061))
                    .method_10852(class_2561.method_43470("You need ").method_27692(class_124.field_1061))
                    .method_10852(class_2561.method_43470("$" + upfrontCost).method_27695(class_124.field_1061, class_124.field_1067))
                    .method_10852(class_2561.method_43470(" but only have ").method_27692(class_124.field_1061))
                    .method_10852(class_2561.method_43470("$" + String.format("%.2f", balance)).method_27695(class_124.field_1061, class_124.field_1067));
            }
        } else {
            message.method_10852(class_2561.method_43470("  Daily Price: ").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470("$" + dailyPrice).method_27692(class_124.field_1065))
                .method_10852(class_2561.method_43470(" per day you are online.\n").method_27692(class_124.field_1068));
            message.method_10852(class_2561.method_43470("  Contract: Minimum ").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470(String.valueOf(contractDays)).method_27692(class_124.field_1075))
                .method_10852(class_2561.method_43470(" days. Breaking early will result in a pro-rated charge.\n").method_27692(class_124.field_1068));
            message.method_10852(class_2561.method_43470("  Example: If you've paid for 10/").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470(String.valueOf(contractDays)).method_27692(class_124.field_1075))
                .method_10852(class_2561.method_43470(" days, you'll pay the remaining ").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470(String.valueOf(contractDays - 10)).method_27692(class_124.field_1054))
                .method_10852(class_2561.method_43470(" days worth.\n").method_27692(class_124.field_1068));
            
            if (balance < dailyPrice) {
                message.method_10852(class_2561.method_43470("\n  ⚠️ Insufficient funds! ").method_27692(class_124.field_1061))
                    .method_10852(class_2561.method_43470("You need ").method_27692(class_124.field_1061))
                    .method_10852(class_2561.method_43470("$" + dailyPrice).method_27695(class_124.field_1061, class_124.field_1067))
                    .method_10852(class_2561.method_43470(" but only have ").method_27692(class_124.field_1061))
                    .method_10852(class_2561.method_43470("$" + String.format("%.2f", balance)).method_27695(class_124.field_1061, class_124.field_1067));
            }
        }
        
        message.method_10852(class_2561.method_43470("\nType ").method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470("/service subscribe " + tag + " confirm").method_27692(class_124.field_1060))
            .method_10852(class_2561.method_43470(" to confirm.").method_27692(class_124.field_1068));
        
        source.method_9226(() -> message, false);
        return 1;
    }
    
    /**
     * Confirm subscription.
     */
    private static int confirmSubscribe(CommandContext<class_2168> context, String tag) {
        class_2168 source = context.getSource();
        
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be executed by a player"));
            return 0;
        }
        
        ServiceManager manager = ServiceManager.getInstance();
        boolean success = manager.subscribeToService(player, tag);
        
        if (success) {
            Service service = manager.getService(tag);
            int contractDays = service != null ? service.getContractDays() : 0;
            
            class_5250 message = class_2561.method_43470("✓ Subscribed to service ").method_27692(class_124.field_1060)
                .method_10852(class_2561.method_43470(tag.toUpperCase()).method_27695(class_124.field_1054, class_124.field_1067))
                .method_10852(class_2561.method_43470("!\n").method_27692(class_124.field_1060));
            
            if (contractDays == 0) {
                message.method_10852(class_2561.method_43470("  You've been charged for the first 10 days upfront.\n").method_27692(class_124.field_1080))
                    .method_10852(class_2561.method_43470("  You will continue to be charged daily after day 10.").method_27692(class_124.field_1080));
            } else {
                message.method_10852(class_2561.method_43470("  You've been charged for the first day.\n").method_27692(class_124.field_1080))
                    .method_10852(class_2561.method_43470("  Contract: ").method_27692(class_124.field_1080))
                    .method_10852(class_2561.method_43470(String.valueOf(contractDays)).method_27692(class_124.field_1075))
                    .method_10852(class_2561.method_43470(" days minimum.").method_27692(class_124.field_1080));
            }
            
            source.method_9226(() -> message, false);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Failed to subscribe. You may already be subscribed or have insufficient funds."));
            return 0;
        }
    }
    
    /**
     * Unsubscribe from a service (with confirmation).
     */
    private static int unsubscribeFromService(CommandContext<class_2168> context, String tag) {
        class_2168 source = context.getSource();
        
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be executed by a player"));
            return 0;
        }
        
        ServiceManager manager = ServiceManager.getInstance();
        ServiceSubscription subscription = manager.getSubscription(player.method_5667(), tag);
        
        if (subscription == null) {
            source.method_9213(class_2561.method_43470("You are not subscribed to this service"));
            return 0;
        }
        
        class_5250 message = class_2561.method_43470("Unsubscribe from service ").method_27692(class_124.field_1068)
            .method_10852(class_2561.method_43470(tag.toUpperCase()).method_27695(class_124.field_1054, class_124.field_1067))
            .method_10852(class_2561.method_43470("?\n").method_27692(class_124.field_1068));
        
        if (!subscription.isContractFulfilled()) {
            int remainingDays = subscription.getRemainingContractDays();
            int proRatedCharge = remainingDays * subscription.getDailyPrice();
            
            message.method_10852(class_2561.method_43470("  ⚠️ Contract not fulfilled! ").method_27692(class_124.field_1061))
                .method_10852(class_2561.method_43470("You've paid for ").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470(String.valueOf(subscription.getDaysPaid())).method_27692(class_124.field_1075))
                .method_10852(class_2561.method_43470("/").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470(String.valueOf(subscription.getContractDays())).method_27692(class_124.field_1075))
                .method_10852(class_2561.method_43470(" days.\n").method_27692(class_124.field_1068));
            message.method_10852(class_2561.method_43470("  You will be charged ").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470("$" + proRatedCharge).method_27695(class_124.field_1061, class_124.field_1067))
                .method_10852(class_2561.method_43470(" for the remaining ").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470(String.valueOf(remainingDays)).method_27692(class_124.field_1054))
                .method_10852(class_2561.method_43470(" days.\n").method_27692(class_124.field_1068));
            
            EconomyManager economyManager = CurrencyMod.getEconomyManager();
            double balance = economyManager.getBalance(player.method_5667());
            
            if (balance < proRatedCharge) {
                message.method_10852(class_2561.method_43470("\n  ⚠️ Insufficient funds! ").method_27692(class_124.field_1061))
                    .method_10852(class_2561.method_43470("You need ").method_27692(class_124.field_1061))
                    .method_10852(class_2561.method_43470("$" + proRatedCharge).method_27695(class_124.field_1061, class_124.field_1067))
                    .method_10852(class_2561.method_43470(" but only have ").method_27692(class_124.field_1061))
                    .method_10852(class_2561.method_43470("$" + String.format("%.2f", balance)).method_27695(class_124.field_1061, class_124.field_1067));
            }
        } else {
            message.method_10852(class_2561.method_43470("  You will be unsubscribed from this service.").method_27692(class_124.field_1068));
        }
        
        message.method_10852(class_2561.method_43470("\nType ").method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470("/service unsubscribe " + tag + " confirm").method_27692(class_124.field_1061))
            .method_10852(class_2561.method_43470(" to confirm.").method_27692(class_124.field_1068));
        
        source.method_9226(() -> message, false);
        return 1;
    }
    
    /**
     * Confirm unsubscribe.
     */
    private static int confirmUnsubscribe(CommandContext<class_2168> context, String tag) {
        class_2168 source = context.getSource();
        
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be executed by a player"));
            return 0;
        }
        
        ServiceManager manager = ServiceManager.getInstance();
        boolean success = manager.unsubscribeFromService(player, tag);
        
        if (success) {
            source.method_9226(() -> class_2561.method_43470("✓ Unsubscribed from service ")
                .method_27692(class_124.field_1060)
                .method_10852(class_2561.method_43470(tag.toUpperCase()).method_27695(class_124.field_1054, class_124.field_1067))
                .method_10852(class_2561.method_43470(".").method_27692(class_124.field_1060)), false);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Failed to unsubscribe. You may not have enough funds to break the contract."));
            return 0;
        }
    }
    
    /**
     * List all subscriptions for the player.
     */
    private static int listSubscriptions(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be executed by a player"));
            return 0;
        }
        
        ServiceManager manager = ServiceManager.getInstance();
        List<ServiceSubscription> subscriptions = manager.getPlayerSubscriptions(player.method_5667());
        
        if (subscriptions.isEmpty()) {
            source.method_9226(() -> class_2561.method_43470("You are not subscribed to any services.").method_27692(class_124.field_1068), false);
            return 1;
        }
        
        class_5250 message = class_2561.method_43470("=== Your Subscriptions ===\n")
            .method_27695(class_124.field_1065, class_124.field_1067);
        
        for (ServiceSubscription subscription : subscriptions) {
            Service service = manager.getService(subscription.getServiceTag());
            if (service == null) {
                continue; // Service was deleted
            }
            
            message.method_10852(class_2561.method_43470("\n• ").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470(subscription.getServiceTag()).method_27695(class_124.field_1054, class_124.field_1067))
                .method_10852(class_2561.method_43470(" - ").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470("$" + subscription.getDailyPrice()).method_27692(class_124.field_1065))
                .method_10852(class_2561.method_43470("/day").method_27692(class_124.field_1068));
            
            if (subscription.getContractDays() > 0) {
                int remaining = subscription.getRemainingContractDays();
                message.method_10852(class_2561.method_43470(" (Contract: ").method_27692(class_124.field_1068))
                    .method_10852(class_2561.method_43470(String.valueOf(subscription.getDaysPaid())).method_27692(class_124.field_1075))
                    .method_10852(class_2561.method_43470("/").method_27692(class_124.field_1068))
                    .method_10852(class_2561.method_43470(String.valueOf(subscription.getContractDays())).method_27692(class_124.field_1075))
                    .method_10852(class_2561.method_43470(" days, ").method_27692(class_124.field_1068))
                    .method_10852(class_2561.method_43470(String.valueOf(remaining)).method_27692(class_124.field_1054))
                    .method_10852(class_2561.method_43470(" remaining)").method_27692(class_124.field_1068));
            } else {
                int prepaidRemaining = subscription.getDaysPaid();
                if (prepaidRemaining > 0) {
                    message.method_10852(class_2561.method_43470(" (").method_27692(class_124.field_1068))
                        .method_10852(class_2561.method_43470(String.valueOf(prepaidRemaining)).method_27692(class_124.field_1075))
                        .method_10852(class_2561.method_43470(" prepaid days remaining)").method_27692(class_124.field_1068));
                }
            }
        }
        
        source.method_9226(() -> message, false);
        return 1;
    }
}

