package net.currencymod.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.currencymod.CurrencyMod;
import net.currencymod.economy.OfflinePaymentManager;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2191;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_7157;
import com.mojang.authlib.GameProfile;
import java.util.Collection;
import java.util.UUID;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public class PayCommand {
    
    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 registryAccess, class_2170.class_5364 environment) {
        dispatcher.register(
            method_9247("pay")
                .then(method_9244("player", class_2191.method_9329()) // Use GameProfile to allow targeting offline players
                    .then(method_9244("amount", DoubleArgumentType.doubleArg(0.01))
                        .executes(PayCommand::execute)
                    )
                )
        );
    }
    
    private static int execute(CommandContext<class_2168> context) throws CommandSyntaxException {
        class_2168 source = context.getSource();
        
        // Check if the command was run by a player
        if (!(source.method_9228() instanceof class_3222 sender)) {
            source.method_9213(class_2561.method_43470("This command can only be executed by a player"));
            return 0;
        }
        
        // Get the target player profile and amount arguments
        Collection<GameProfile> profiles = class_2191.method_9330(context, "player");
        if (profiles.isEmpty()) {
            source.method_9213(class_2561.method_43470("Player not found"));
            return 0;
        }
        
        // Get the first profile (command should only target one player)
        GameProfile receiverProfile = profiles.iterator().next();
        UUID receiverUuid = receiverProfile.getId();
        String receiverName = receiverProfile.getName();
        double amount = DoubleArgumentType.getDouble(context, "amount");
        
        // Don't allow players to pay themselves
        if (sender.method_5667().equals(receiverUuid)) {
            source.method_9213(class_2561.method_43470("You can't pay yourself"));
            return 0;
        }
        
        // Format the amount to two decimal places for display
        String formattedAmount = String.format("%.2f", amount);
        
        // Try to transfer the money
        boolean success = CurrencyMod.getEconomyManager().transferMoney(
            sender.method_5667(), 
            receiverUuid, 
            amount
        );
        
        if (success) {
            // Notify the sender about the successful transaction
            source.method_9226(() -> class_2561.method_43470("💰 You sent ")
                .method_10852(class_2561.method_43470("$" + formattedAmount)
                    .method_27695(class_124.field_1060, class_124.field_1067))
                .method_10852(class_2561.method_43470(" to ")
                    .method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470(receiverName)
                    .method_27692(class_124.field_1054)), false);
            
            // Check if the receiver is online
            class_3222 onlineReceiver = source.method_9211().method_3760().method_14602(receiverUuid);
            if (onlineReceiver != null) {
                // Receiver is online, notify them immediately
                onlineReceiver.method_43496(class_2561.method_43470("💰 Received ")
                    .method_27692(class_124.field_1065)
                    .method_10852(class_2561.method_43470("$" + formattedAmount)
                        .method_27695(class_124.field_1060, class_124.field_1067))
                    .method_10852(class_2561.method_43470(" from ")
                        .method_27692(class_124.field_1068))
                    .method_10852(class_2561.method_43470(sender.method_5477().getString())
                        .method_27692(class_124.field_1054)));
            } else {
                // Receiver is offline, record the payment for later notification
                OfflinePaymentManager.getInstance().recordOfflinePayment(
                    receiverUuid,
                    sender.method_5477().getString(),
                    amount
                );
                
                // Inform the sender that the receiver is offline
                source.method_9226(() -> class_2561.method_43470("Note: ")
                    .method_27692(class_124.field_1054)
                    .method_10852(class_2561.method_43470(receiverName)
                        .method_27692(class_124.field_1075))
                    .method_10852(class_2561.method_43470(" is offline but will be notified when they log in.")
                        .method_27692(class_124.field_1054)), false);
            }
            return 1;
        } else {
            // Notify the sender that the transaction failed
            source.method_9213(class_2561.method_43470("Payment failed. Make sure you have enough money."));
            return 0;
        }
    }
} 