package net.currencymod.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.currencymod.data.DataManager;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_7157;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

/**
 * Command for managing mod data, backups, and saves
 */
public class DataCommand {

    /**
     * Register the data command
     */
    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 registryAccess, class_2170.class_5364 environment) {
        dispatcher.register(
            method_9247("currencydata")
                .requires(source -> source.method_9259(3)) // Require admin permission level
                .executes(DataCommand::showHelp)
                .then(method_9247("save")
                    .executes(DataCommand::forceSave)
                )
                .then(method_9247("status")
                    .executes(DataCommand::showStatus)
                )
                .then(method_9247("backup")
                    .executes(DataCommand::createBackup)
                )
                .then(method_9247("backups")
                    .executes(DataCommand::listBackups)
                )
                .then(method_9247("restore")
                    .then(method_9244("backup", StringArgumentType.greedyString())
                        .executes(context -> restoreBackup(context, StringArgumentType.getString(context, "backup")))
                    )
                )
        );
    }
    
    /**
     * Display help for the data command
     */
    private static int showHelp(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        class_2561 header = class_2561.method_43470("💾 ").method_27692(class_124.field_1065)
            .method_10852(class_2561.method_43470("Currency Mod Data Management").method_27695(class_124.field_1065, class_124.field_1067));
            
        source.method_9226(() -> header, false);
        source.method_9226(() -> class_2561.method_43470("Available commands:").method_27692(class_124.field_1068), false);
        source.method_9226(() -> class_2561.method_43470("/currencydata save").method_27692(class_124.field_1054)
            .method_10852(class_2561.method_43470(" - Force an immediate save of all data").method_27692(class_124.field_1080)), false);
        source.method_9226(() -> class_2561.method_43470("/currencydata status").method_27692(class_124.field_1054)
            .method_10852(class_2561.method_43470(" - Show current data system status").method_27692(class_124.field_1080)), false);
        source.method_9226(() -> class_2561.method_43470("/currencydata backup").method_27692(class_124.field_1054)
            .method_10852(class_2561.method_43470(" - Create a new backup").method_27692(class_124.field_1080)), false);
        source.method_9226(() -> class_2561.method_43470("/currencydata backups").method_27692(class_124.field_1054)
            .method_10852(class_2561.method_43470(" - List available backups").method_27692(class_124.field_1080)), false);
        source.method_9226(() -> class_2561.method_43470("/currencydata restore <backup>").method_27692(class_124.field_1054)
            .method_10852(class_2561.method_43470(" - Restore from a backup").method_27692(class_124.field_1080)), false);
            
        return 1;
    }
    
    /**
     * Force an immediate save of all data
     */
    private static int forceSave(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        source.method_9226(() -> class_2561.method_43470("Forcing data save...").method_27692(class_124.field_1054), true);
        
        try {
            DataManager.getInstance().forceSave("command");
            source.method_9226(() -> class_2561.method_43470("All data saved successfully.").method_27692(class_124.field_1060), true);
            return 1;
        } catch (Exception e) {
            source.method_9213(class_2561.method_43470("Failed to save data: " + e.getMessage()));
            return 0;
        }
    }
    
    /**
     * Show the current data system status
     */
    private static int showStatus(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        String status = DataManager.getInstance().getStatus();
        String[] lines = status.split("\n");
        
        source.method_9226(() -> class_2561.method_43470("📊 Data System Status:").method_27695(class_124.field_1075, class_124.field_1067), true);
        
        for (String line : lines) {
            if (line.contains("Data Manager Status")) continue; // Skip header line
            source.method_9226(() -> class_2561.method_43470(line).method_27692(class_124.field_1068), false);
        }
        
        int sinceLastSave = DataManager.getInstance().getSecondsSinceLastSave();
        if (sinceLastSave >= 0) {
            class_2561 timeText = formatTimeAgo(sinceLastSave);
            source.method_9226(() -> class_2561.method_43470("Last save was ").method_27692(class_124.field_1068)
                .method_10852(timeText), false);
        }
        
        // Add info about next auto-save
        source.method_9226(() -> class_2561.method_43470("Auto-saves occur every 5 minutes").method_27692(class_124.field_1080), false);
        
        return 1;
    }
    
    /**
     * Create a new backup
     */
    private static int createBackup(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        source.method_9226(() -> class_2561.method_43470("Creating backup...").method_27692(class_124.field_1054), true);
        
        try {
            DataManager.getInstance().createBackup();
            source.method_9226(() -> class_2561.method_43470("Backup created successfully.").method_27692(class_124.field_1060), true);
            return 1;
        } catch (Exception e) {
            source.method_9213(class_2561.method_43470("Failed to create backup: " + e.getMessage()));
            return 0;
        }
    }
    
    /**
     * List available backups
     */
    private static int listBackups(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        String[] backups = DataManager.getInstance().getAvailableBackups();
        
        if (backups.length == 0) {
            source.method_9226(() -> class_2561.method_43470("No backups available.").method_27692(class_124.field_1054), false);
            return 0;
        }
        
        source.method_9226(() -> class_2561.method_43470("📁 Available backups:").method_27695(class_124.field_1075, class_124.field_1067), true);
        
        for (String backup : backups) {
            String timestamp = backup.substring(7); // Remove "backup_" prefix
            timestamp = timestamp.replace('_', ' ');
            
            final String finalTimestamp = timestamp;
            source.method_9226(() -> class_2561.method_43470(" • ").method_27692(class_124.field_1080)
                .method_10852(class_2561.method_43470(finalTimestamp).method_27692(class_124.field_1054))
                .method_10852(class_2561.method_43470(" - "))
                .method_10852(class_2561.method_43470("/currencydata restore ").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470(finalTimestamp).method_27692(class_124.field_1060)), false);
        }
        
        return 1;
    }
    
    /**
     * Restore from a backup
     */
    private static int restoreBackup(CommandContext<class_2168> context, String backupName) {
        class_2168 source = context.getSource();
        
        // Confirm with the user
        source.method_9226(() -> class_2561.method_43470("⚠ WARNING: This will overwrite all current data! ⚠")
            .method_27695(class_124.field_1061, class_124.field_1067), true);
        source.method_9226(() -> class_2561.method_43470("Restoring from backup: ").method_27692(class_124.field_1054)
            .method_10852(class_2561.method_43470(backupName).method_27692(class_124.field_1060)), true);
        source.method_9226(() -> class_2561.method_43470("A backup of the current data will be created first.").method_27692(class_124.field_1080), false);
        
        try {
            boolean success = DataManager.getInstance().restoreFromBackup(backupName);
            
            if (success) {
                source.method_9226(() -> class_2561.method_43470("✅ Backup restored successfully.").method_27695(class_124.field_1060, class_124.field_1067), true);
                return 1;
            } else {
                source.method_9213(class_2561.method_43470("❌ Failed to restore backup. See console for details."));
                return 0;
            }
        } catch (Exception e) {
            source.method_9213(class_2561.method_43470("Error restoring backup: " + e.getMessage()));
            return 0;
        }
    }
    
    /**
     * Format a time ago in a human-readable format
     */
    private static class_2561 formatTimeAgo(int seconds) {
        if (seconds < 60) {
            return class_2561.method_43470(seconds + " seconds ago").method_27692(getTimeColor(seconds));
        } else if (seconds < 3600) {
            int minutes = seconds / 60;
            return class_2561.method_43470(minutes + " minute" + (minutes > 1 ? "s" : "") + " ago").method_27692(getTimeColor(seconds));
        } else {
            int hours = seconds / 3600;
            int minutes = (seconds % 3600) / 60;
            return class_2561.method_43470(hours + " hour" + (hours > 1 ? "s" : "") + 
                (minutes > 0 ? " " + minutes + " minute" + (minutes > 1 ? "s" : "") : "") + " ago")
                .method_27692(getTimeColor(seconds));
        }
    }
    
    /**
     * Get a color based on how long ago something happened
     */
    private static class_124 getTimeColor(int seconds) {
        if (seconds < 60) {
            return class_124.field_1060; // Last minute
        } else if (seconds < 300) { // 5 minutes
            return class_124.field_1054;
        } else if (seconds < 1800) { // 30 minutes
            return class_124.field_1065;
        } else {
            return class_124.field_1061;
        }
    }
} 