package net.currencymod.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import net.currencymod.jobs.MarketplaceHandler;
import net.currencymod.jobs.MarketplaceManager;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2262;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_7157;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

/**
 * Command for accessing the marketplace where players can buy items from completed jobs.
 */
public class MarketCommand {
    
    /**
     * Register the market command.
     * 
     * @param dispatcher The command dispatcher
     * @param registryAccess The registry access
     * @param environment The registration environment
     */
    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 registryAccess, class_2170.class_5364 environment) {
        dispatcher.register(
            method_9247("market")
                .executes(MarketCommand::execute)
                .then(method_9247("setchest")
                    .requires(source -> source.method_9259(2)) // Operator only
                    .executes(MarketCommand::setChestAtPlayer)
                    .then(method_9244("pos", class_2262.method_9698())
                        .executes(MarketCommand::setChestAtPos)
                    )
                )
        );
    }
    
    /**
     * Execute the market command.
     * 
     * @param context The command context
     * @return The command result
     */
    private static int execute(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        // Check if the command was run by a player
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be executed by a player"));
            return 0;
        }
        
        // Open the marketplace GUI using our enhanced implementation
        MarketplaceManager.getInstance().openMarketplace(player);
        
        // Return success
        return 1;
    }
    
    /**
     * Set the marketplace chest at the player's position.
     * 
     * @param context The command context
     * @return The command result
     */
    private static int setChestAtPlayer(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        // Check if the command was run by a player
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be executed by a player"));
            return 0;
        }
        
        // Use the block the player is standing on
        class_2338 pos = player.method_24515().method_10074();
        
        // Set the marketplace chest position
        MarketplaceHandler.setMarketplaceChestPos(pos);
        
        // Send feedback
        source.method_9226(() -> class_2561.method_43470("Set marketplace chest position to ")
            .method_10852(class_2561.method_43470(pos.method_10263() + ", " + pos.method_10264() + ", " + pos.method_10260()).method_27692(class_124.field_1060)), true);
        
        return 1;
    }
    
    /**
     * Set the marketplace chest at a specific position.
     * 
     * @param context The command context
     * @return The command result
     */
    private static int setChestAtPos(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        // Get the position from the command
        class_2338 pos = class_2262.method_48299(context, "pos");
        
        // Set the marketplace chest position
        MarketplaceHandler.setMarketplaceChestPos(pos);
        
        // Send feedback
        source.method_9226(() -> class_2561.method_43470("Set marketplace chest position to ")
            .method_10852(class_2561.method_43470(pos.method_10263() + ", " + pos.method_10264() + ", " + pos.method_10260()).method_27692(class_124.field_1060)), true);
        
        return 1;
    }
} 