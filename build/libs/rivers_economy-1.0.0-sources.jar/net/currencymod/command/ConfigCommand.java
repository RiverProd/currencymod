package net.currencymod.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import net.currencymod.config.ModConfig;
import net.currencymod.plots.PlotType;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import net.minecraft.class_7157;
import net.minecraft.server.MinecraftServer;
import java.io.File;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.nio.file.Path;

import static net.minecraft.class_2170.method_9247;

/**
 * Command for managing and viewing the mod configuration
 */
public class ConfigCommand {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(ConfigCommand.class);
    
    /**
     * Register the config command
     */
    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 registryAccess, class_2170.class_5364 environment) {
        dispatcher.register(
            method_9247("currencyconfig")
                .requires(source -> source.method_9259(2)) // Require permission level 2 (admin/op)
                .executes(ConfigCommand::showConfig)
                .then(method_9247("reload")
                    .executes(ConfigCommand::reloadConfig)
                )
                .then(method_9247("save")
                    .executes(ConfigCommand::saveConfig)
                )
                .then(method_9247("debug")
                    .executes(ConfigCommand::debugConfig)
                )
        );
    }
    
    /**
     * Display the current configuration values
     */
    private static int showConfig(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        class_2561 header = class_2561.method_43470("⚙️ ").method_27692(class_124.field_1065)
            .method_10852(class_2561.method_43470("CurrencyMod Configuration").method_27695(class_124.field_1065, class_124.field_1067));
        
        // Show plot configuration
        class_2561 plotsHeader = class_2561.method_43470("\n\nPlot Prices and Taxes:").method_27695(class_124.field_1054, class_124.field_1067);
        
        StringBuilder plotInfo = new StringBuilder();
        for (PlotType type : PlotType.values()) {
            plotInfo.append("\n• ")
                .append(type.name())
                .append(": ")
                .append(type.getDisplayName())
                .append(" - $")
                .append(type.getPurchasePrice())
                .append(" (Tax: $")
                .append(type.getDailyTax())
                .append("/day)");
        }
        
        // Show job multipliers
        ModConfig config = ModConfig.getInstance();
        class_2561 jobMultipliersHeader = class_2561.method_43470("\n\nJob Multipliers:").method_27695(class_124.field_1054, class_124.field_1067);
        class_2561 jobMultipliersInfo = class_2561.method_43470("\n• Job Quantity Multiplier: ")
            .method_10852(class_2561.method_43470(String.valueOf(config.getJobQuantityMultiplier())).method_27692(class_124.field_1075))
            .method_10852(class_2561.method_43470("\n• Job Payout Multiplier: ")
            .method_10852(class_2561.method_43470(String.valueOf(config.getJobPayoutMultiplier())).method_27692(class_124.field_1075)))
            .method_27692(class_124.field_1068);
        
        class_2561 reloadHelp = class_2561.method_43470("\n\nUse ")
            .method_10852(class_2561.method_43470("/currencyconfig reload").method_27692(class_124.field_1060))
            .method_10852(class_2561.method_43470(" to reload the configuration from file"))
            .method_27692(class_124.field_1068);
        
        class_2561 configPath = class_2561.method_43470("\nConfiguration is stored in ")
            .method_10852(class_2561.method_43470("currency_mod/config/config.json").method_27692(class_124.field_1075))
            .method_27692(class_124.field_1068);
        
        source.method_9226(() -> header
            .method_27661()
            .method_10852(plotsHeader)
            .method_10852(class_2561.method_43470(plotInfo.toString()).method_27692(class_124.field_1068))
            .method_10852(jobMultipliersHeader)
            .method_10852(jobMultipliersInfo)
            .method_10852(reloadHelp)
            .method_10852(configPath), false);
        
        return 1;
    }
    
    /**
     * Reload the configuration from disk
     */
    private static int reloadConfig(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        // Reload the configuration
        ModConfig.getInstance().load(source.method_9211());
        
        source.method_9226(() -> class_2561.method_43470("⚙️ Configuration reloaded from disk!").method_27692(class_124.field_1060), true);
        
        // Show the current configuration after reload
        return showConfig(context);
    }

    /**
     * Force-save the configuration
     */
    private static int saveConfig(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        // Save the configuration
        try {
            LOGGER.info("Manual save initiated via command");
            ModConfig.getInstance().save(source.method_9211());
            source.method_9226(() -> class_2561.method_43470("⚙️ Configuration saved to disk!").method_27692(class_124.field_1060), true);
        } catch (Exception e) {
            LOGGER.error("Error saving config: {}", e.getMessage(), e);
            source.method_9213(class_2561.method_43470("Error saving config: " + e.getMessage()).method_27692(class_124.field_1061));
        }
        
        return 1;
    }

    /**
     * Show debug information about the configuration
     */
    private static int debugConfig(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        MinecraftServer server = source.method_9211();
        
        // Show the paths
        Path runDir = server.method_3831();
        Path configDirPath = runDir.resolve(ModConfig.getConfigDir());
        Path configFilePath = configDirPath.resolve(ModConfig.getConfigFile());
        
        File configDir = configDirPath.toFile();
        File configFile = configFilePath.toFile();
        
        class_2561 header = class_2561.method_43470("⚙️ ").method_27692(class_124.field_1065)
            .method_10852(class_2561.method_43470("CurrencyMod Configuration Debug Info").method_27695(class_124.field_1065, class_124.field_1067));
        
        class_2561 paths = class_2561.method_43470("\n\nPaths:").method_27695(class_124.field_1054, class_124.field_1067)
            .method_10852(class_2561.method_43470("\nServer Run Directory: ").method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470(runDir.toString()).method_27692(class_124.field_1075))
            .method_10852(class_2561.method_43470("\nConfig Directory: ").method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470(configDir.getAbsolutePath()).method_27692(class_124.field_1075))
            .method_10852(class_2561.method_43470("\nConfig File: ").method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470(configFile.getAbsolutePath()).method_27692(class_124.field_1075));
        
        class_2561 existence = class_2561.method_43470("\n\nFile Status:").method_27695(class_124.field_1054, class_124.field_1067)
            .method_10852(class_2561.method_43470("\nConfig Directory Exists: ").method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470(String.valueOf(configDir.exists())).method_27692(configDir.exists() ? class_124.field_1060 : class_124.field_1061))
            .method_10852(class_2561.method_43470("\nConfig File Exists: ").method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470(String.valueOf(configFile.exists())).method_27692(configFile.exists() ? class_124.field_1060 : class_124.field_1061));
        
        class_5250 rwPerms = class_2561.method_43470("\n\nPermissions:").method_27695(class_124.field_1054, class_124.field_1067);
        
        if (configDir.exists()) {
            rwPerms.method_10852(class_2561.method_43470("\nDirectory Readable: ").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470(String.valueOf(configDir.canRead())).method_27692(configDir.canRead() ? class_124.field_1060 : class_124.field_1061))
                .method_10852(class_2561.method_43470("\nDirectory Writable: ").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470(String.valueOf(configDir.canWrite())).method_27692(configDir.canWrite() ? class_124.field_1060 : class_124.field_1061));
        } else {
            rwPerms.method_10852(class_2561.method_43470("\nParent Directory Readable: ").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470(String.valueOf(configDir.getParentFile().canRead())).method_27692(configDir.getParentFile().canRead() ? class_124.field_1060 : class_124.field_1061))
                .method_10852(class_2561.method_43470("\nParent Directory Writable: ").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470(String.valueOf(configDir.getParentFile().canWrite())).method_27692(configDir.getParentFile().canWrite() ? class_124.field_1060 : class_124.field_1061));
        }
        
        if (configFile.exists()) {
            rwPerms.method_10852(class_2561.method_43470("\nConfig File Readable: ").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470(String.valueOf(configFile.canRead())).method_27692(configFile.canRead() ? class_124.field_1060 : class_124.field_1061))
                .method_10852(class_2561.method_43470("\nConfig File Writable: ").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470(String.valueOf(configFile.canWrite())).method_27692(configFile.canWrite() ? class_124.field_1060 : class_124.field_1061));
        }
        
        source.method_9226(() -> header
            .method_27661()
            .method_10852(paths)
            .method_10852(existence)
            .method_10852(rwPerms), false);
        
        return 1;
    }
} 