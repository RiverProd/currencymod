package net.currencymod.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.authlib.GameProfile;
import net.currencymod.CurrencyMod;
import net.currencymod.jobs.BoosterType;
import net.currencymod.jobs.JobManager;
import net.currencymod.jobs.PlayerBoosterData;
import net.currencymod.jobs.PlayerJobLevel;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2191;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_7157;
import java.util.*;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

/**
 * Admin commands for managing player boosters
 */
public class AdminBoosterCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 registryAccess, class_2170.class_5364 environment) {
        // Register /currencymod boosters apply command
        dispatcher.register(
            method_9247("currencymod")
                .requires(source -> source.method_9259(2)) // Require OP level 2
                .then(method_9247("boosters")
                    .then(method_9247("apply")
                        .executes(AdminBoosterCommand::applyBoosters)
                    )
                )
        );
        
        // Register /adminboostergive command
        dispatcher.register(
            method_9247("adminboostergive")
                .requires(source -> source.method_9259(2)) // Require OP level 2
                .then(method_9244("player", class_2191.method_9329())
                    .then(method_9244("boostertype", StringArgumentType.word())
                        .suggests((context, builder) -> {
                            builder.suggest("premium");
                            builder.suggest("basic");
                            return builder.buildFuture();
                        })
                        .executes(context -> giveBooster(
                            context,
                            class_2191.method_9330(context, "player"),
                            StringArgumentType.getString(context, "boostertype")
                        ))
                    )
                )
        );
        
        // Register /adminboosterremove command
        dispatcher.register(
            method_9247("adminboosterremove")
                .requires(source -> source.method_9259(2)) // Require OP level 2
                .then(method_9244("player", class_2191.method_9329())
                    .then(method_9244("boostertype", StringArgumentType.word())
                        .suggests((context, builder) -> {
                            builder.suggest("premium");
                            builder.suggest("basic");
                            return builder.buildFuture();
                        })
                        .executes(context -> removeBooster(
                            context,
                            class_2191.method_9330(context, "player"),
                            StringArgumentType.getString(context, "boostertype")
                        ))
                    )
                )
        );
    }
    
    /**
     * Apply boosters to all players based on their job level
     */
    private static int applyBoosters(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        JobManager jobManager = JobManager.getInstance();
        
        source.method_9226(() -> class_2561.method_43470("Starting application of level-based boosters to all players...")
            .method_27692(class_124.field_1054), true);
            
        Map<UUID, PlayerJobLevel> allPlayerLevels = jobManager.getAllPlayerJobLevels();
        
        if (allPlayerLevels.isEmpty()) {
            source.method_9226(() -> class_2561.method_43470("No players found with job levels.")
                .method_27692(class_124.field_1061), true);
            return 0;
        }
        
        int totalPlayers = 0;
        int basicBoosters = 0;
        int premiumBoosters = 0;
        Map<String, List<String>> playerBoosterReport = new HashMap<>();
        
        // Process each player
        for (Map.Entry<UUID, PlayerJobLevel> entry : allPlayerLevels.entrySet()) {
            UUID playerUuid = entry.getKey();
            PlayerJobLevel jobLevel = entry.getValue();
            int level = jobLevel.getLevel();
            
            if (level <= 0) continue; // Skip players with no levels
            
            totalPlayers++;
            PlayerBoosterData boosterData = jobManager.getPlayerBoosterData(playerUuid);
            String playerName = getPlayerName(source, playerUuid);
            List<String> boosters = new ArrayList<>();
            
            // Award boosters based on level:
            // - Premium boosters for levels 5, 10, 15, 20, 25, 30
            // - Basic boosters for all other levels
            
            // Premium boosters for milestone levels
            if (level >= 5) {
                boosterData.addBooster(BoosterType.PREMIUM);
                premiumBoosters++;
                boosters.add("Premium (Level 5)");
            }
            
            if (level >= 10) {
                boosterData.addBooster(BoosterType.PREMIUM);
                premiumBoosters++;
                boosters.add("Premium (Level 10)");
            }
            
            if (level >= 15) {
                boosterData.addBooster(BoosterType.PREMIUM);
                premiumBoosters++;
                boosters.add("Premium (Level 15)");
            }
            
            if (level >= 20) {
                boosterData.addBooster(BoosterType.PREMIUM);
                premiumBoosters++;
                boosters.add("Premium (Level 20)");
            }
            
            if (level >= 25) {
                boosterData.addBooster(BoosterType.PREMIUM);
                premiumBoosters++;
                boosters.add("Premium (Level 25)");
            }
            
            if (level >= 30) {
                boosterData.addBooster(BoosterType.PREMIUM);
                premiumBoosters++;
                boosters.add("Premium (Level 30)");
            }
            
            // Basic boosters for all other levels (excluding milestone levels)
            int basicCount = level;
            
            // Subtract milestone levels where they got premium boosters instead
            if (level >= 5) basicCount--;
            if (level >= 10) basicCount--;
            if (level >= 15) basicCount--;
            if (level >= 20) basicCount--;
            if (level >= 25) basicCount--;
            if (level >= 30) basicCount--;
            
            for (int i = 0; i < basicCount; i++) {
                boosterData.addBooster(BoosterType.BASIC);
                basicBoosters++;
                boosters.add("Basic");
            }
            
            // Store report data
            playerBoosterReport.put(playerName + " (Level " + level + ")", boosters);
        }
        
        // Save data
        jobManager.save();
        
        // Send summary to admin
        source.method_9226(() -> class_2561.method_43470("Booster application complete!")
            .method_27695(class_124.field_1060, class_124.field_1067), true);
            
        final int finalBasicBoosters = basicBoosters;
        final int finalPremiumBoosters = premiumBoosters;
        final int finalTotalPlayers = totalPlayers;
            
        source.method_9226(() -> class_2561.method_43470("Summary: ")
            .method_27692(class_124.field_1065)
            .method_10852(class_2561.method_43470("Applied ").method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470(finalBasicBoosters + " Basic").method_27692(class_124.field_1075))
            .method_10852(class_2561.method_43470(" and ").method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470(finalPremiumBoosters + " Premium").method_27692(class_124.field_1065))
            .method_10852(class_2561.method_43470(" boosters to ").method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470(finalTotalPlayers + " players").method_27692(class_124.field_1060)), true);
            
        // Send detailed report
        source.method_9226(() -> class_2561.method_43470("Detailed Report:").method_27695(class_124.field_1065, class_124.field_1067), true);
        
        List<String> playerNames = new ArrayList<>(playerBoosterReport.keySet());
        Collections.sort(playerNames);
        
        for (String playerName : playerNames) {
            List<String> boosters = playerBoosterReport.get(playerName);
            
            int playerBasic = (int) boosters.stream().filter(b -> b.equals("Basic")).count();
            int playerPremium = (int) boosters.stream().filter(b -> !b.equals("Basic")).count();
            
            source.method_9226(() -> class_2561.method_43470("• ")
                .method_27692(class_124.field_1080)
                .method_10852(class_2561.method_43470(playerName).method_27692(class_124.field_1054))
                .method_10852(class_2561.method_43470(": ").method_27692(class_124.field_1080))
                .method_10852(class_2561.method_43470(playerBasic + " Basic").method_27692(class_124.field_1075))
                .method_10852(class_2561.method_43470(", ").method_27692(class_124.field_1080))
                .method_10852(class_2561.method_43470(playerPremium + " Premium").method_27692(class_124.field_1065)), true);
        }
        
        return 1;
    }
    
    /**
     * Give a booster to a player
     */
    private static int giveBooster(CommandContext<class_2168> context, Collection<GameProfile> profiles, String boosterTypeStr) {
        class_2168 source = context.getSource();
        
        // Validate booster type
        BoosterType type;
        try {
            type = parseBoosterType(boosterTypeStr);
        } catch (IllegalArgumentException e) {
            source.method_9213(class_2561.method_43470("Invalid booster type: " + boosterTypeStr)
                .method_27692(class_124.field_1061));
            return 0;
        }
        
        // Check if we have at least one profile
        if (profiles.isEmpty()) {
            source.method_9213(class_2561.method_43470("Player not found")
                .method_27692(class_124.field_1061));
            return 0;
        }
        
        JobManager jobManager = JobManager.getInstance();
        int successCount = 0;
        
        for (GameProfile profile : profiles) {
            UUID playerUuid = profile.getId();
            String playerName = profile.getName();
            
            // Get or create player booster data
            PlayerBoosterData boosterData = jobManager.getPlayerBoosterData(playerUuid);
            
            // Add the booster
            boosterData.addBooster(type);
            successCount++;
            
            // Send feedback
            source.method_9226(() -> class_2561.method_43470("Gave ")
                .method_27692(class_124.field_1060)
                .method_10852(class_2561.method_43470(type.getDisplayName())
                    .method_27692(type == BoosterType.PREMIUM ? class_124.field_1065 : class_124.field_1075)
                    .method_27692(class_124.field_1067))
                .method_10852(class_2561.method_43470(" to ")
                    .method_27692(class_124.field_1060))
                .method_10852(class_2561.method_43470(playerName)
                    .method_27692(class_124.field_1054)), true);
            
            // Notify player if online
            class_3222 player = source.method_9211().method_3760().method_14602(playerUuid);
            if (player != null) {
                player.method_43496(class_2561.method_43470("💫 ")
                    .method_27692(class_124.field_1065)
                    .method_10852(class_2561.method_43470("An admin gave you a ")
                        .method_27692(class_124.field_1054))
                    .method_10852(class_2561.method_43470(type.getDisplayName())
                        .method_27692(type == BoosterType.PREMIUM ? class_124.field_1065 : class_124.field_1075)
                        .method_27692(class_124.field_1067))
                    .method_10852(class_2561.method_43470("!")
                        .method_27692(class_124.field_1054)));
            }
        }
        
        // Save changes
        jobManager.save();
        
        // Final feedback for multiple players
        if (successCount > 1) {
            final int finalSuccessCount = successCount;
            source.method_9226(() -> class_2561.method_43470("Successfully gave ")
                .method_27692(class_124.field_1060)
                .method_10852(class_2561.method_43470(type.getDisplayName())
                    .method_27692(type == BoosterType.PREMIUM ? class_124.field_1065 : class_124.field_1075))
                .method_10852(class_2561.method_43470(" to ")
                    .method_27692(class_124.field_1060))
                .method_10852(class_2561.method_43470(finalSuccessCount + " players")
                    .method_27692(class_124.field_1054)), true);
        }
        
        return successCount;
    }
    
    /**
     * Remove a booster from a player
     */
    private static int removeBooster(CommandContext<class_2168> context, Collection<GameProfile> profiles, String boosterTypeStr) {
        class_2168 source = context.getSource();
        
        // Validate booster type
        BoosterType type;
        try {
            type = parseBoosterType(boosterTypeStr);
        } catch (IllegalArgumentException e) {
            source.method_9213(class_2561.method_43470("Invalid booster type: " + boosterTypeStr)
                .method_27692(class_124.field_1061));
            return 0;
        }
        
        // Check if we have at least one profile
        if (profiles.isEmpty()) {
            source.method_9213(class_2561.method_43470("Player not found")
                .method_27692(class_124.field_1061));
            return 0;
        }
        
        JobManager jobManager = JobManager.getInstance();
        int successCount = 0;
        
        for (GameProfile profile : profiles) {
            UUID playerUuid = profile.getId();
            String playerName = profile.getName();
            
            // Get player booster data
            PlayerBoosterData boosterData = jobManager.getPlayerBoosterData(playerUuid);
            
            // Check if player has the booster
            int boosterCount = boosterData.getBoosterCount(type);
            if (boosterCount <= 0) {
                source.method_9226(() -> class_2561.method_43470(playerName)
                    .method_27692(class_124.field_1054)
                    .method_10852(class_2561.method_43470(" doesn't have any ")
                        .method_27692(class_124.field_1061))
                    .method_10852(class_2561.method_43470(type.getDisplayName())
                        .method_27692(type == BoosterType.PREMIUM ? class_124.field_1065 : class_124.field_1075))
                    .method_10852(class_2561.method_43470(" boosters.")
                        .method_27692(class_124.field_1061)), false);
                continue;
            }
            
            // Remove one booster of the specified type
            // We do this by manipulating the count directly in the EnumMap
            Map<BoosterType, Integer> ownedBoosters = boosterData.getOwnedBoosters();
            ownedBoosters.put(type, boosterCount - 1);
            successCount++;
            
            // Send feedback
            source.method_9226(() -> class_2561.method_43470("Removed one ")
                .method_27692(class_124.field_1060)
                .method_10852(class_2561.method_43470(type.getDisplayName())
                    .method_27692(type == BoosterType.PREMIUM ? class_124.field_1065 : class_124.field_1075)
                    .method_27692(class_124.field_1067))
                .method_10852(class_2561.method_43470(" from ")
                    .method_27692(class_124.field_1060))
                .method_10852(class_2561.method_43470(playerName)
                    .method_27692(class_124.field_1054))
                .method_10852(class_2561.method_43470(" (")
                    .method_27692(class_124.field_1080))
                .method_10852(class_2561.method_43470((boosterCount - 1) + " remaining")
                    .method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470(")")
                    .method_27692(class_124.field_1080)), true);
            
            // Notify player if online
            class_3222 player = source.method_9211().method_3760().method_14602(playerUuid);
            if (player != null) {
                player.method_43496(class_2561.method_43470("💫 ")
                    .method_27692(class_124.field_1061)
                    .method_10852(class_2561.method_43470("An admin removed one ")
                        .method_27692(class_124.field_1054))
                    .method_10852(class_2561.method_43470(type.getDisplayName())
                        .method_27692(type == BoosterType.PREMIUM ? class_124.field_1065 : class_124.field_1075)
                        .method_27692(class_124.field_1067))
                    .method_10852(class_2561.method_43470(" from your inventory.")
                        .method_27692(class_124.field_1054)));
            }
        }
        
        // Save changes if there were any successful removals
        if (successCount > 0) {
            jobManager.save();
        }
        
        // Final feedback for multiple players
        if (successCount > 1) {
            final int finalSuccessCount = successCount;
            source.method_9226(() -> class_2561.method_43470("Successfully removed ")
                .method_27692(class_124.field_1060)
                .method_10852(class_2561.method_43470(type.getDisplayName())
                    .method_27692(type == BoosterType.PREMIUM ? class_124.field_1065 : class_124.field_1075))
                .method_10852(class_2561.method_43470(" from ")
                    .method_27692(class_124.field_1060))
                .method_10852(class_2561.method_43470(finalSuccessCount + " players")
                    .method_27692(class_124.field_1054)), true);
        }
        
        return successCount;
    }
    
    /**
     * Parse a booster type from a string
     */
    private static BoosterType parseBoosterType(String typeStr) {
        if (typeStr.equalsIgnoreCase("premium")) {
            return BoosterType.PREMIUM;
        } else if (typeStr.equalsIgnoreCase("basic")) {
            return BoosterType.BASIC;
        } else {
            throw new IllegalArgumentException("Unknown booster type: " + typeStr);
        }
    }
    
    /**
     * Get a player's name from their UUID
     */
    private static String getPlayerName(class_2168 source, UUID uuid) {
        // Try to get from online players
        class_3222 player = source.method_9211().method_3760().method_14602(uuid);
        if (player != null) {
            return player.method_5477().getString();
        }
        
        // Try to get from user cache
        if (source.method_9211().method_3793() != null) {
            Optional<GameProfile> profile = source.method_9211().method_3793().method_14512(uuid);
            if (profile.isPresent()) {
                return profile.get().getName();
            }
        }
        
        // Fall back to UUID
        return uuid.toString().substring(0, 8);
    }
} 