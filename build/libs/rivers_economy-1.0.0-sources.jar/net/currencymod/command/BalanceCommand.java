package net.currencymod.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.currencymod.CurrencyMod;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_7157;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public class BalanceCommand {
    
    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 registryAccess, class_2170.class_5364 environment) {
        dispatcher.register(
            method_9247("bal")
                .executes(BalanceCommand::executeOwn)
                .then(method_9244("player", class_2186.method_9305())
                    .executes(BalanceCommand::executeOther)
                )
        );

        dispatcher.register(
            method_9247("balance")
                .executes(BalanceCommand::executeOwn)
                .then(method_9244("player", class_2186.method_9305())
                    .executes(BalanceCommand::executeOther)
                )
        );
    }
    
    /**
     * Execute the balance command for the player who ran it
     */
    private static int executeOwn(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        // Check if the command was run by a player
        if (source.method_9228() instanceof class_3222 player) {
            double balance = CurrencyMod.getEconomyManager().getBalance(player.method_5667());
            
            // Format the balance to show only 2 decimal places if there are decimals
            String formattedBalance = formatBalance(balance);
            
            // Send the balance message to the player
            source.method_9226(() -> class_2561.method_43470("Your balance: $" + formattedBalance).method_27692(class_124.field_1065), false);
            return 1;
        } else {
            // The command was not run by a player
            source.method_9213(class_2561.method_43470("This command can only be executed by a player"));
            return 0;
        }
    }
    
    /**
     * Execute the balance command to check another player's balance
     */
    private static int executeOther(CommandContext<class_2168> context) throws CommandSyntaxException {
        class_2168 source = context.getSource();
        class_3222 targetPlayer = class_2186.method_9315(context, "player");
        
        // Only players or the server console can check other players' balances
        if (source.method_9228() instanceof class_3222 || source.method_9259(2)) {
            double balance = CurrencyMod.getEconomyManager().getBalance(targetPlayer.method_5667());
            String formattedBalance = formatBalance(balance);
            
            // Send the balance message
            source.method_9226(() -> class_2561.method_43470(targetPlayer.method_5477().getString() + "'s balance: $" + formattedBalance)
                .method_27692(class_124.field_1065), false);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("You don't have permission to check other players' balances"));
            return 0;
        }
    }
    
    /**
     * Format a balance to show only 2 decimal places if there are decimals
     */
    private static String formatBalance(double balance) {
        return balance == Math.floor(balance) 
            ? String.format("%.0f", balance) 
            : String.format("%.2f", balance);
    }
} 