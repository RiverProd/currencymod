package net.currencymod.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.currencymod.plots.PlotManager;
import net.currencymod.plots.PlotType;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_7157;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

/**
 * Command for buying plots
 */
public class BuyPlotCommand {
    
    /**
     * Register the buyplot command
     */
    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 registryAccess, class_2170.class_5364 environment) {
        dispatcher.register(
            method_9247("buyplot")
                .executes(BuyPlotCommand::showHelp)
                .then(method_9244("type", StringArgumentType.word())
                    .executes(context -> buyPlot(context, StringArgumentType.getString(context, "type")))
                )
        );
    }
    
    /**
     * Display help for the buyplot command
     */
    private static int showHelp(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        class_2561 header = class_2561.method_43470("🏞️ ").method_27692(class_124.field_1060)
            .method_10852(class_2561.method_43470("Plot Purchase Guide").method_27695(class_124.field_1060, class_124.field_1067));
            
        class_2561 typesHeader = class_2561.method_43470("\nAvailable plot types:").method_27692(class_124.field_1068);
        
        StringBuilder typesInfo = new StringBuilder();
        for (PlotType type : PlotType.values()) {
            typesInfo.append("\n• ")
                .append(type.getDisplayName())
                .append(" - $")
                .append(type.getPurchasePrice())
                .append(" (Tax: $")
                .append(type.getDailyTax())
                .append("/day)");
        }
        
        class_2561 usage = class_2561.method_43470("\n\nUsage:").method_27692(class_124.field_1068)
            .method_10852(class_2561.method_43470("\n/buyplot <type>").method_27692(class_124.field_1054))
            .method_10852(class_2561.method_43470(" - Purchase a plot of the specified type"));
            
        source.method_9226(() -> header
            .method_27661()
            .method_10852(typesHeader)
            .method_10852(class_2561.method_43470(typesInfo.toString()).method_27692(class_124.field_1065))
            .method_10852(usage), false);
            
        return 1;
    }
    
    /**
     * Buy a plot of the specified type
     */
    private static int buyPlot(CommandContext<class_2168> context, String typeName) throws CommandSyntaxException {
        class_2168 source = context.getSource();
        
        // Check if the command was run by a player
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be executed by a player"));
            return 0;
        }
        
        // Parse the plot type
        PlotType plotType = PlotType.fromString(typeName);
        if (plotType == null) {
            source.method_9213(class_2561.method_43470("Unknown plot type: ").method_10852(class_2561.method_43470(typeName).method_27692(class_124.field_1061)));
            source.method_9226(() -> class_2561.method_43470("Available types: ")
                .method_10852(class_2561.method_43470(String.join(", ", 
                    PlotType.PERSONAL.getDisplayName(), 
                    PlotType.FARM.getDisplayName(), 
                    PlotType.BUSINESS.getDisplayName(),
                    PlotType.INDUSTRIAL.getDisplayName()
                )).method_27692(class_124.field_1054)), false);
            return 0;
        }
        
        // Try to buy the plot
        boolean success = PlotManager.getInstance().buyPlot(player, plotType);
        
        return success ? 1 : 0;
    }
} 