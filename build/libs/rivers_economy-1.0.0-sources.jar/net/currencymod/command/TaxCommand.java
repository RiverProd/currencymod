package net.currencymod.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import net.currencymod.plots.PlotManager;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_7157;

import static net.minecraft.class_2170.method_9247;

/**
 * Command for administrators to trigger plot tax collection
 */
public class TaxCommand {

    /**
     * Register the tax command
     */
    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 registryAccess, class_2170.class_5364 environment) {
        dispatcher.register(
            method_9247("tax")
                .requires(source -> source.method_9259(2)) // Require permission level 2 (admin/op)
                .executes(TaxCommand::executeTax)
        );
    }
    
    /**
     * Execute the tax command - collect taxes from all online players
     */
    private static int executeTax(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        // Trigger tax collection in the PlotManager
        int playersCount = PlotManager.getInstance().collectManualTax(source.method_9211());
        
        // Send feedback to the admin based on how many players were taxed
        if (playersCount > 0) {
            source.method_9226(() -> class_2561.method_43470("💰 Tax collection complete! ")
                .method_10852(class_2561.method_43470("Collected taxes from " + playersCount + " player(s).")
                .method_27692(class_124.field_1060)), true);
        } else {
            source.method_9226(() -> class_2561.method_43470("💰 No players with plots were found online to tax."), true);
        }
        
        return playersCount;
    }
} 