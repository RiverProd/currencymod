package net.currencymod.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.currencymod.config.GuiPreferenceManager;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_7157;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public class CurrencyGuiCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher,
                                class_7157 registryAccess,
                                class_2170.class_5364 environment) {
        dispatcher.register(
            method_9247("currencygui")
                .executes(ctx -> showStatus(ctx.getSource()))
                .then(method_9247("on").executes(ctx -> setGui(ctx.getSource(), true)))
                .then(method_9247("off").executes(ctx -> setGui(ctx.getSource(), false)))
        );
    }

    private static int showStatus(class_2168 source) {
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be run by a player."));
            return 0;
        }
        boolean enabled = GuiPreferenceManager.getInstance().isGuiEnabled(player.method_5667());
        source.method_9226(() -> class_2561.method_43470("Jobs GUI is currently ")
            .method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43470(enabled ? "ON" : "OFF")
                .method_27692(enabled ? class_124.field_1060 : class_124.field_1061))
            .method_10852(class_2561.method_43470(". Use ").method_27692(class_124.field_1080))
            .method_10852(class_2561.method_43470("/currencygui on").method_27692(class_124.field_1054))
            .method_10852(class_2561.method_43470(" or ").method_27692(class_124.field_1080))
            .method_10852(class_2561.method_43470("/currencygui off").method_27692(class_124.field_1054))
            .method_10852(class_2561.method_43470(" to change.").method_27692(class_124.field_1080)), false);
        return 1;
    }

    private static int setGui(class_2168 source, boolean enable) {
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be run by a player."));
            return 0;
        }
        GuiPreferenceManager.getInstance().setGuiEnabled(player.method_5667(), enable);
        source.method_9226(() -> class_2561.method_43470("Jobs GUI ")
            .method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43470(enable ? "enabled" : "disabled")
                .method_27692(enable ? class_124.field_1060 : class_124.field_1061))
            .method_10852(class_2561.method_43470(enable
                ? ". Use /jobs to open the interface."
                : ". Use /jobs list to use the text-based system.")
                .method_27692(class_124.field_1080)), false);
        return 1;
    }
}
