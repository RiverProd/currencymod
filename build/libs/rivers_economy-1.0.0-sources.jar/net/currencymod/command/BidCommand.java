package net.currencymod.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.currencymod.CurrencyMod;
import net.currencymod.auction.AuctionManager;
import net.currencymod.economy.EconomyManager;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_3222;
import net.minecraft.class_7157;
import com.mojang.authlib.GameProfile;

import java.util.UUID;
import java.util.Optional;

/**
 * Command for bidding on auctions
 */
public class BidCommand {
    // Standard bid increments for suggested bids
    private static final double[] BID_INCREMENTS = {0.0, 5.0, 10.0, 25.0, 50.0, 100.0, 250.0, 500.0, 1000.0};
    
    // Quick bid fixed increments
    private static final double[] FIXED_INCREMENTS = {1.0, 10.0, 100.0};
    
    // Quick bid percentage increments
    private static final double[] PERCENTAGE_INCREMENTS = {0.01, 0.1, 1.0}; // 1%, 10%, 100%
    
    /**
     * Register the bid command
     */
    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 registryAccess, class_2170.class_5364 environment) {
        dispatcher.register(
            class_2170.method_9247("bid")
                .then(class_2170.method_9244("amount", DoubleArgumentType.doubleArg(0.01))
                    .executes(context -> placeBid(
                        context,
                        DoubleArgumentType.getDouble(context, "amount")
                    ))
                )
                .executes(BidCommand::showActiveBid)
        );
    }
    
    /**
     * Place a bid on the current auction
     */
    private static int placeBid(CommandContext<class_2168> context, double bidAmount) {
        class_2168 source = context.getSource();
        
        try {
            class_3222 player = source.method_44023();
            AuctionManager auctionManager = AuctionManager.getInstance();
            
            // Check if there's an active auction
            AuctionManager.Auction auction = auctionManager.getCurrentAuction();
            if (auction == null || auction.isEnded()) {
                source.method_9213(class_2561.method_43470("There is no active auction to bid on.")
                    .method_27692(class_124.field_1061));
                return 0;
            }
            
            // Check if the player is the seller
            if (auction.getSellerUuid().equals(player.method_5667())) {
                source.method_9213(class_2561.method_43470("You cannot bid on your own auction.")
                    .method_27692(class_124.field_1061));
                return 0;
            }
            
            // Check if the player has enough money
            EconomyManager economyManager = CurrencyMod.getEconomyManager();
            double playerBalance = economyManager.getBalance(player.method_5667());
            if (playerBalance < bidAmount) {
                source.method_9213(class_2561.method_43470("You don't have enough money to place this bid. Your balance: ")
                    .method_27692(class_124.field_1061)
                    .method_10852(class_2561.method_43470("$" + String.format("%.2f", playerBalance))
                        .method_27692(class_124.field_1065)));
                return 0;
            }
            
            // Check if the bid is high enough
            double minimumBid = auction.getMinimumBid();
            if (bidAmount < minimumBid) {
                source.method_9213(class_2561.method_43470("Your bid is too low. Minimum bid: ")
                    .method_27692(class_124.field_1061)
                    .method_10852(class_2561.method_43470("$" + String.format("%.2f", minimumBid))
                        .method_27692(class_124.field_1065)));
                return 0;
            }
            
            // Place the bid
            boolean success = auctionManager.placeBid(player.method_5667(), bidAmount);
            if (!success) {
                source.method_9213(class_2561.method_43470("Failed to place bid. The auction may have ended.")
                    .method_27692(class_124.field_1061));
                return 0;
            }
            
            // Notify the player about their bid
            source.method_9226(() -> class_2561.method_43470("✓ ")
                .method_27695(class_124.field_1060, class_124.field_1067)
                .method_10852(class_2561.method_43470("You placed a bid of ")
                    .method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470("$" + String.format("%.2f", bidAmount))
                    .method_27692(class_124.field_1060))
                .method_10852(class_2561.method_43470(" on ")
                    .method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470(auction.getItem().method_7947() + "x " + auction.getItem().method_7964().getString())
                    .method_27692(class_124.field_1075)), false);
            
            // Broadcast the bid to all players
            broadcastBid(source, player.method_5477().getString(), auction, bidAmount);
            
            return 1;
        } catch (Exception e) {
            source.method_9213(class_2561.method_43470("This command can only be executed by a player."));
            return 0;
        }
    }
    
    /**
     * Show information about the active auction
     */
    private static int showActiveBid(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        AuctionManager auctionManager = AuctionManager.getInstance();
        AuctionManager.Auction auction = auctionManager.getCurrentAuction();
        
        if (auction == null || auction.isEnded()) {
            source.method_9226(() -> class_2561.method_43470("There is no active auction right now.")
                .method_27692(class_124.field_1061), false);
            return 0;
        }
        
        // Get auction details
        UUID sellerUuid = auction.getSellerUuid();
        String sellerName = getPlayerName(source, sellerUuid);
        class_1799 item = auction.getItem();
        double currentBid = auction.getCurrentPrice();
        double minimumBid = auction.getMinimumBid();
        long timeLeft = auction.getTimeLeft();
        
        // Create the auction info text with hoverable item
        class_2561 itemComponent = auctionManager.createItemHoverTooltip(item);
        
        // Format current bid information
        class_2561 bidInfo;
        if (auction.getCurrentBid() != null) {
            UUID bidderUuid = auction.getCurrentBid().getBidderUuid();
            String bidderName = getPlayerName(source, bidderUuid);
            bidInfo = class_2561.method_43470("Current bid: ")
                .method_27692(class_124.field_1068)
                .method_10852(class_2561.method_43470("$" + String.format("%.2f", currentBid))
                    .method_27692(class_124.field_1060))
                .method_10852(class_2561.method_43470(" by ")
                    .method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470(bidderName)
                    .method_27692(class_124.field_1054));
        } else {
            bidInfo = class_2561.method_43470("Starting bid: ")
                .method_27692(class_124.field_1068)
                .method_10852(class_2561.method_43470("$" + String.format("%.2f", currentBid))
                    .method_27692(class_124.field_1060));
        }
        
        // Create auction header
        class_2561 auctionHeader = class_2561.method_43470("🔨 Active Auction ")
            .method_27695(class_124.field_1065, class_124.field_1067)
            .method_10852(class_2561.method_43470("(" + AuctionManager.formatTimeLeft(timeLeft) + ")")
                .method_27692(class_124.field_1080));
        
        // Create auction info
        class_2561 auctionInfo = class_2561.method_43470("Seller: ")
            .method_27692(class_124.field_1068)
            .method_10852(class_2561.method_43470(sellerName)
                .method_27692(class_124.field_1054))
            .method_10852(class_2561.method_43470("\nItem: ")
                .method_27692(class_124.field_1068))
            .method_10852(itemComponent)
            .method_10852(class_2561.method_43470("\n"))
            .method_10852(bidInfo)
            .method_10852(class_2561.method_43470("\nMinimum bid: ")
                .method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470("$" + String.format("%.2f", minimumBid))
                .method_27692(class_124.field_1060));
        
        // Send the auction info
        source.method_9226(() -> auctionHeader, false);
        source.method_9226(() -> auctionInfo, false);
        
        // Show suggested bids if the command was run by a player
        if (source.method_9228() instanceof class_3222 player) {
            showSuggestedBids(player, auction);
        }
        
        return 1;
    }
    
    /**
     * Show suggested bids to a player
     */
    private static void showSuggestedBids(class_3222 player, AuctionManager.Auction auction) {
        double minBid = auction.getMinimumBid();
        double currentPrice = auction.getCurrentPrice();
        
        // Create standard bid suggestions
        class_2561 standardBids = createStandardBidSuggestions(player, auction, minBid);
        
        // Create fixed increment bid options (+$1, +$10, +$100)
        class_2561 fixedIncrementBids = createFixedIncrementBids(currentPrice, minBid);
        
        // Create percentage increment bid options (+1%, +10%, +100%)
        class_2561 percentageIncrementBids = createPercentageIncrementBids(currentPrice, minBid);
        
        // Send all bid suggestions to the player
        player.method_7353(standardBids, false);
        player.method_7353(class_2561.method_43470(""), false); // Empty line for spacing
        player.method_7353(fixedIncrementBids, false);
        player.method_7353(percentageIncrementBids, false);
    }
    
    /**
     * Create standard bid suggestions (like in the original code)
     */
    private static class_2561 createStandardBidSuggestions(class_3222 player, AuctionManager.Auction auction, double minBid) {
        // Find appropriate bid increments based on the minimum bid
        double[] suggestedBids = new double[3];
        
        // First suggestion is always the minimum bid
        suggestedBids[0] = minBid;
        
        // Find increments for the other suggestions
        double increment = 0;
        for (double bidIncrement : BID_INCREMENTS) {
            if (minBid >= bidIncrement) {
                increment = bidIncrement;
            } else {
                break;
            }
        }
        
        // If we have a very low price, use 50% and 100% increments
        if (increment <= 0) {
            suggestedBids[1] = Math.ceil((minBid * 1.5) * 100) / 100; // 50% more
            suggestedBids[2] = Math.ceil((minBid * 2.0) * 100) / 100; // Double
        } else {
            // Otherwise use appropriate increments
            suggestedBids[1] = Math.ceil((minBid + increment) * 100) / 100;
            suggestedBids[2] = Math.ceil((minBid + increment * 2) * 100) / 100;
        }
        
        // Create clickable bid options
        class_2561 message = class_2561.method_43470("📊 Standard Bids: ")
            .method_27692(class_124.field_1054);
        
        for (int i = 0; i < suggestedBids.length; i++) {
            if (i > 0) {
                message = message.method_27661().method_10852(class_2561.method_43470(" | ").method_27692(class_124.field_1080));
            }
            
            double bidAmount = suggestedBids[i];
            message = message.method_27661().method_10852(createClickableBid(bidAmount));
        }
        
        // Add custom bid option
        message = message.method_27661()
            .method_10852(class_2561.method_43470(" | ").method_27692(class_124.field_1080))
            .method_10852(class_2561.method_43470("Custom Bid")
                .method_27692(class_124.field_1075)
                .method_27694(style -> style
                    .method_10958(new class_2558(class_2558.class_2559.field_11745, "/bid "))
                    .method_10949(new class_2568(class_2568.class_5247.field_24342, 
                        class_2561.method_43470("Enter a custom bid amount")
                            .method_27692(class_124.field_1065))))
            );
        
        return message;
    }
    
    /**
     * Create fixed increment bid options (+$1, +$10, +$100)
     */
    private static class_2561 createFixedIncrementBids(double currentPrice, double minBid) {
        class_2561 message = class_2561.method_43470("📈 Fixed Increments: ")
            .method_27692(class_124.field_1060);
        
        for (int i = 0; i < FIXED_INCREMENTS.length; i++) {
            if (i > 0) {
                message = message.method_27661().method_10852(class_2561.method_43470(" | ").method_27692(class_124.field_1080));
            }
            
            double increment = FIXED_INCREMENTS[i];
            double bidAmount = Math.max(minBid, Math.ceil((currentPrice + increment) * 100) / 100);
            
            message = message.method_27661().method_10852(
                class_2561.method_43470("+$" + String.format("%.0f", increment))
                    .method_27692(class_124.field_1065)
                    .method_27694(style -> style
                        .method_10958(new class_2558(class_2558.class_2559.field_11750, "/bid " + bidAmount))
                        .method_10949(new class_2568(class_2568.class_5247.field_24342, 
                            class_2561.method_43470("Bid $" + String.format("%.2f", bidAmount) + 
                                " (Current + $" + String.format("%.0f", increment) + ")")
                                .method_27692(class_124.field_1054))))
            );
        }
        
        return message;
    }
    
    /**
     * Create percentage increment bid options (+1%, +10%, +100%)
     */
    private static class_2561 createPercentageIncrementBids(double currentPrice, double minBid) {
        class_2561 message = class_2561.method_43470("📊 Percentage Increments: ")
            .method_27692(class_124.field_1075);
        
        for (int i = 0; i < PERCENTAGE_INCREMENTS.length; i++) {
            if (i > 0) {
                message = message.method_27661().method_10852(class_2561.method_43470(" | ").method_27692(class_124.field_1080));
            }
            
            double percentage = PERCENTAGE_INCREMENTS[i];
            int percentDisplay = (int)(percentage * 100);
            double increment = currentPrice * percentage;
            double bidAmount = Math.max(minBid, Math.ceil((currentPrice + increment) * 100) / 100);
            
            message = message.method_27661().method_10852(
                class_2561.method_43470("+" + percentDisplay + "%")
                    .method_27692(class_124.field_1076)
                    .method_27694(style -> style
                        .method_10958(new class_2558(class_2558.class_2559.field_11750, "/bid " + bidAmount))
                        .method_10949(new class_2568(class_2568.class_5247.field_24342, 
                            class_2561.method_43470("Bid $" + String.format("%.2f", bidAmount) + 
                                " (Current + " + percentDisplay + "%)")
                                .method_27692(class_124.field_1054))))
            );
        }
        
        return message;
    }
    
    /**
     * Create a clickable bid text
     */
    private static class_2561 createClickableBid(double amount) {
        return class_2561.method_43470("$" + String.format("%.2f", amount))
            .method_27692(class_124.field_1060)
            .method_27694(style -> style
                .method_10958(new class_2558(class_2558.class_2559.field_11750, "/bid " + amount))
                .method_10949(new class_2568(class_2568.class_5247.field_24342, 
                    class_2561.method_43470("Click to bid $" + String.format("%.2f", amount))
                        .method_27692(class_124.field_1065)))
            );
    }
    
    /**
     * Broadcast a bid to all players
     */
    private static void broadcastBid(class_2168 source, String bidderName, AuctionManager.Auction auction, double bidAmount) {
        class_2561 message = class_2561.method_43470("🔨 New Bid! ")
            .method_27695(class_124.field_1065, class_124.field_1067)
            .method_10852(class_2561.method_43470(bidderName)
                .method_27692(class_124.field_1075))
            .method_10852(class_2561.method_43470(" bid ")
                .method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470("$" + String.format("%.2f", bidAmount))
                .method_27692(class_124.field_1060))
            .method_10852(class_2561.method_43470(" on ")
                .method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470(auction.getItem().method_7947() + "x " + auction.getItem().method_7964().getString())
                .method_27692(class_124.field_1054))
            .method_10852(class_2561.method_43470(" (")
                .method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470(AuctionManager.formatTimeLeft(auction.getTimeLeft()) + " left")
                .method_27692(class_124.field_1061))
            .method_10852(class_2561.method_43470(")")
                .method_27692(class_124.field_1068));
        
        source.method_9211().method_3760().method_43514(message, false);
    }

    /**
     * Get a player's name from their UUID
     * @param source The command source
     * @param uuid The UUID to look up
     * @return The player's name or a placeholder if not found
     */
    private static String getPlayerName(class_2168 source, UUID uuid) {
        // Try to find the player on the server
        class_3222 player = source.method_9211().method_3760().method_14602(uuid);
        if (player != null) {
            return player.method_5477().getString();
        }
        
        // If player is offline, try to get their name from the user cache
        var userCache = source.method_9211().method_3793();
        if (userCache != null) {
            Optional<GameProfile> profileOpt = userCache.method_14512(uuid);
            if (profileOpt.isPresent()) {
                return profileOpt.get().getName();
            }
        }
        
        // If we can't find the name, use a shortened UUID
        return shortenUuid(uuid);
    }
    
    /**
     * Shorten a UUID for display purposes
     */
    private static String shortenUuid(UUID uuid) {
        String uuidString = uuid.toString();
        return uuidString.substring(0, 8) + "...";
    }
} 