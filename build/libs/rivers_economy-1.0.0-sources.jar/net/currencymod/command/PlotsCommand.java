package net.currencymod.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.currencymod.plots.ChunkKey;
import net.currencymod.plots.PlotManager;
import net.currencymod.plots.PlotType;
import net.currencymod.plots.WorldPlot;
import net.currencymod.ui.ConfirmScreenHandler;
import net.currencymod.ui.PlotInfoScreenHandler;
import net.currencymod.ui.PlotTypeSelectScreenHandler;
import net.minecraft.class_124;
import net.minecraft.class_1802;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_7157;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

/**
 * /plots command — reworked for GUI-based plot interaction.
 *
 * Player commands (no permission required):
 *   /plots          → opens PlotInfoScreenHandler (dashboard)
 *
 * Admin commands (permission level 2):
 *   /plots create   → registers current chunk as buyable (all types enabled), opens type-select UI
 *   /plots edit     → opens type-select UI for current chunk
 *   /plots remove   → unregisters current chunk (blocked if owned)
 *
 * Op escape hatches (permission level 2, hidden from tab-complete for non-ops):
 *   /plots buy <type> [quantity]
 *   /plots sell <type>
 *   /plots confirm
 *   /plots cancel
 */
public class PlotsCommand {

    private static final SuggestionProvider<class_2168> PLOT_TYPE_SUGGESTIONS = (ctx, builder) ->
            class_2172.method_9265(
                    Arrays.stream(PlotType.values())
                            .map(PlotType::getDisplayName)
                            .collect(Collectors.toList()),
                    builder);

    private static final SuggestionProvider<class_2168> ONLINE_PLAYER_SUGGESTIONS = (ctx, builder) ->
            class_2172.method_9265(
                    ctx.getSource().method_9211().method_3760().method_14571()
                            .stream()
                            .map(p -> p.method_5477().getString())
                            .collect(Collectors.toList()),
                    builder);

    public static void register(CommandDispatcher<class_2168> dispatcher,
                                 class_7157 registryAccess,
                                 class_2170.class_5364 environment) {
        dispatcher.register(
            method_9247("plots")
                // ---- Base command: player dashboard ----
                .executes(PlotsCommand::openDashboard)

                // ---- Admin: create ----
                .then(method_9247("create")
                    .requires(src -> src.method_9259(2))
                    .executes(PlotsCommand::createPlot))

                // ---- Admin: edit ----
                .then(method_9247("edit")
                    .requires(src -> src.method_9259(2))
                    .executes(PlotsCommand::editPlot))

                // ---- Admin: remove ----
                .then(method_9247("remove")
                    .requires(src -> src.method_9259(2))
                    .executes(PlotsCommand::removePlot))

                // ---- Admin: grant ----
                .then(method_9247("grant")
                    .requires(src -> src.method_9259(2))
                    .then(method_9244("player", StringArgumentType.word())
                        .suggests(ONLINE_PLAYER_SUGGESTIONS)
                        .then(method_9244("type", StringArgumentType.word())
                            .suggests(PLOT_TYPE_SUGGESTIONS)
                            .executes(ctx -> grantPlot(ctx,
                                    StringArgumentType.getString(ctx, "player"),
                                    StringArgumentType.getString(ctx, "type"))))))

                // ---- Admin: delete ----
                .then(method_9247("delete")
                    .requires(src -> src.method_9259(2))
                    .executes(PlotsCommand::deletePlot))

                // ---- Op escape hatch: buy ----
                .then(method_9247("buy")
                    .requires(src -> src.method_9259(2))
                    .executes(PlotsCommand::showBuyHelp)
                    .then(method_9244("type", StringArgumentType.word())
                        .suggests(PLOT_TYPE_SUGGESTIONS)
                        .executes(ctx -> legacyBuy(ctx, StringArgumentType.getString(ctx, "type"), 1))
                        .then(method_9244("quantity", IntegerArgumentType.integer(1))
                            .executes(ctx -> legacyBuy(ctx,
                                    StringArgumentType.getString(ctx, "type"),
                                    IntegerArgumentType.getInteger(ctx, "quantity"))))))

                // ---- Op escape hatch: sell ----
                .then(method_9247("sell")
                    .requires(src -> src.method_9259(2))
                    .executes(PlotsCommand::showSellHelp)
                    .then(method_9244("type", StringArgumentType.word())
                        .suggests(PLOT_TYPE_SUGGESTIONS)
                        .executes(ctx -> legacySell(ctx, StringArgumentType.getString(ctx, "type")))))

                // ---- Op escape hatch: confirm / cancel ----
                .then(method_9247("confirm")
                    .requires(src -> src.method_9259(2))
                    .executes(PlotsCommand::confirmPurchase))

                .then(method_9247("cancel")
                    .requires(src -> src.method_9259(2))
                    .executes(PlotsCommand::cancelPurchase))
        );
    }

    // =========================================================================
    // Base — player dashboard
    // =========================================================================

    private static int openDashboard(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        class_2168 source = ctx.getSource();
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be used by a player."));
            return 0;
        }
        PlotInfoScreenHandler.open(player);
        return 1;
    }

    // =========================================================================
    // Admin — create
    // =========================================================================

    private static int createPlot(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        class_2168 source = ctx.getSource();
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be used by a player."));
            return 0;
        }

        ChunkKey key = ChunkKey.fromPlayer(player);
        PlotManager pm = PlotManager.getInstance();

        if (pm.getWorldPlot(key) != null) {
            source.method_9213(class_2561.method_43470("This chunk is already registered. Use ")
                    .method_10852(class_2561.method_43470("/plots edit").method_27692(class_124.field_1054))
                    .method_10852(class_2561.method_43470(" to modify it.")));
            return 0;
        }

        // Register with all configured types enabled
        Set<PlotType> allTypes = EnumSet.allOf(PlotType.class);
        pm.registerPlot(key, allTypes);

        source.method_9226(() -> class_2561.method_43470("Chunk registered as a buyable plot. Opening type configuration...")
                .method_27692(class_124.field_1060), false);

        // Open type-select UI so admin can fine-tune
        PlotTypeSelectScreenHandler.open(player, key, allTypes);
        return 1;
    }

    // =========================================================================
    // Admin — edit
    // =========================================================================

    private static int editPlot(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        class_2168 source = ctx.getSource();
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be used by a player."));
            return 0;
        }

        ChunkKey key = ChunkKey.fromPlayer(player);
        WorldPlot worldPlot = PlotManager.getInstance().getWorldPlot(key);

        if (worldPlot == null) {
            source.method_9213(class_2561.method_43470("No registered plot in this chunk. Use ")
                    .method_10852(class_2561.method_43470("/plots create").method_27692(class_124.field_1054))
                    .method_10852(class_2561.method_43470(" first.")));
            return 0;
        }

        PlotTypeSelectScreenHandler.open(player, key, worldPlot.getEnabledTypes());
        return 1;
    }

    // =========================================================================
    // Admin — remove
    // =========================================================================

    private static int removePlot(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        class_2168 source = ctx.getSource();
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be used by a player."));
            return 0;
        }

        ChunkKey key = ChunkKey.fromPlayer(player);
        PlotManager pm = PlotManager.getInstance();
        WorldPlot worldPlot = pm.getWorldPlot(key);

        if (worldPlot == null) {
            source.method_9213(class_2561.method_43470("No registered plot in this chunk."));
            return 0;
        }

        if (worldPlot.isOwned()) {
            source.method_9213(class_2561.method_43470("This plot is owned by a player. It cannot be removed while owned."));
            return 0;
        }

        pm.unregisterPlot(key);
        source.method_9226(() -> class_2561.method_43470("Plot removed from the registry.")
                .method_27692(class_124.field_1054), false);
        return 1;
    }

    // =========================================================================
    // Admin — grant
    // =========================================================================

    private static int grantPlot(CommandContext<class_2168> ctx,
                                   String playerName, String typeName) throws CommandSyntaxException {
        class_2168 source = ctx.getSource();
        if (!(source.method_9228() instanceof class_3222 admin)) {
            source.method_9213(class_2561.method_43470("This command can only be used by a player."));
            return 0;
        }

        // Resolve target (online players only)
        class_3222 target = source.method_9211().method_3760().method_14566(playerName);
        if (target == null) {
            source.method_9213(class_2561.method_43470("Player \"" + playerName + "\" is not online."));
            return 0;
        }

        // Resolve plot type
        PlotType plotType = PlotType.fromString(typeName);
        if (plotType == null) {
            source.method_9213(class_2561.method_43470("Unknown plot type: " + typeName));
            return 0;
        }

        ChunkKey key = ChunkKey.fromPlayer(admin);
        PlotManager pm = PlotManager.getInstance();
        WorldPlot worldPlot = pm.getWorldPlot(key);

        if (worldPlot == null) {
            source.method_9213(class_2561.method_43470("No registered plot in this chunk. Use ")
                    .method_10852(class_2561.method_43470("/plots create").method_27692(class_124.field_1054))
                    .method_10852(class_2561.method_43470(" to register it first.")));
            return 0;
        }

        if (worldPlot.isOwned()) {
            source.method_9213(class_2561.method_43470("This plot is already owned. Use ")
                    .method_10852(class_2561.method_43470("/plots delete").method_27692(class_124.field_1054))
                    .method_10852(class_2561.method_43470(" to clear it first.")));
            return 0;
        }

        boolean success = pm.grantPlot(target, worldPlot, plotType);
        if (success) {
            source.method_9226(() -> class_2561.method_43470("Granted a ")
                    .method_10852(class_2561.method_43470(plotType.getDisplayName()).method_27692(class_124.field_1060))
                    .method_10852(class_2561.method_43470(" plot to "))
                    .method_10852(class_2561.method_43470(target.method_5477().getString()).method_27692(class_124.field_1075))
                    .method_10852(class_2561.method_43470(".")), false);
            target.method_43496(class_2561.method_43470("An admin has granted you a ")
                    .method_10852(class_2561.method_43470(plotType.getDisplayName()).method_27695(class_124.field_1060, class_124.field_1067))
                    .method_10852(class_2561.method_43470(" plot. Daily tax: "))
                    .method_10852(class_2561.method_43470("$" + plotType.getDailyTax() + "/day").method_27692(class_124.field_1054)));
        } else {
            source.method_9213(class_2561.method_43470("Failed to grant plot — it may have become owned during the operation."));
        }
        return success ? 1 : 0;
    }

    // =========================================================================
    // Admin — delete
    // =========================================================================

    private static int deletePlot(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        class_2168 source = ctx.getSource();
        if (!(source.method_9228() instanceof class_3222 admin)) {
            source.method_9213(class_2561.method_43470("This command can only be used by a player."));
            return 0;
        }

        ChunkKey key = ChunkKey.fromPlayer(admin);
        PlotManager pm = PlotManager.getInstance();
        WorldPlot worldPlot = pm.getWorldPlot(key);

        if (worldPlot == null) {
            source.method_9213(class_2561.method_43470("No registered plot in this chunk."));
            return 0;
        }

        // Build confirmation info
        String ownerLine = worldPlot.isOwned()
                ? "§c⚠ Owned by a player — ownership record will be removed."
                : "§7Unowned.";

        List<String> lore = new java.util.ArrayList<>();
        lore.add("§7Chunk: §f" + key.chunkX + ", " + key.chunkZ);
        lore.add("§7Dimension: §f" + key.dimension);
        lore.add(ownerLine);
        lore.add("");
        lore.add("§cThis permanently removes all data");
        lore.add("§cfor this chunk.");

        ConfirmScreenHandler.open(
                admin,
                "Delete Plot — Are you sure?",
                class_1802.field_8077,
                "§c§lDelete This Plot",
                lore,
                () -> {
                    pm.deletePlot(key);
                    admin.method_43496(class_2561.method_43470("Plot at chunk ")
                            .method_10852(class_2561.method_43470(key.chunkX + ", " + key.chunkZ).method_27692(class_124.field_1054))
                            .method_10852(class_2561.method_43470(" has been permanently deleted.").method_27692(class_124.field_1061)));
                },
                () -> admin.method_43496(class_2561.method_43470("Plot deletion cancelled.").method_27692(class_124.field_1080)));
        return 1;
    }

    // =========================================================================
    // Op escape hatches — legacy command-based buy/sell
    // =========================================================================

    private static int legacyBuy(CommandContext<class_2168> ctx,
                                   String typeName, int quantity) throws CommandSyntaxException {
        class_2168 source = ctx.getSource();
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be used by a player."));
            return 0;
        }
        PlotType plotType = PlotType.fromString(typeName);
        if (plotType == null) {
            source.method_9213(class_2561.method_43470("Unknown plot type: " + typeName));
            return 0;
        }
        return PlotManager.getInstance().buyPlots(player, plotType, quantity) ? 1 : 0;
    }

    private static int legacySell(CommandContext<class_2168> ctx,
                                    String typeName) throws CommandSyntaxException {
        class_2168 source = ctx.getSource();
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be used by a player."));
            return 0;
        }
        PlotType plotType = PlotType.fromString(typeName);
        if (plotType == null) {
            source.method_9213(class_2561.method_43470("Unknown plot type: " + typeName));
            return 0;
        }
        return PlotManager.getInstance().sellPlot(player, plotType) ? 1 : 0;
    }

    private static int showBuyHelp(CommandContext<class_2168> ctx) {
        StringBuilder sb = new StringBuilder("Available plot types:\n");
        for (PlotType type : PlotType.values()) {
            sb.append("  • ").append(type.getDisplayName())
              .append(" — $").append(type.getPurchasePrice())
              .append(" (Tax: $").append(type.getDailyTax()).append("/day)\n");
        }
        ctx.getSource().method_9226(() -> class_2561.method_43470(sb.toString().trim()).method_27692(class_124.field_1065), false);
        return 1;
    }

    private static int showSellHelp(CommandContext<class_2168> ctx) {
        StringBuilder sb = new StringBuilder("Sell a plot (20% refund):\n");
        for (PlotType type : PlotType.values()) {
            int refund = (int)(type.getPurchasePrice() * 0.2);
            sb.append("  • ").append(type.getDisplayName())
              .append(" — Refund: $").append(refund).append("\n");
        }
        ctx.getSource().method_9226(() -> class_2561.method_43470(sb.toString().trim()).method_27692(class_124.field_1065), false);
        return 1;
    }

    private static int confirmPurchase(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        class_2168 source = ctx.getSource();
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be used by a player."));
            return 0;
        }
        return PlotManager.getInstance().confirmPurchase(player) ? 1 : 0;
    }

    private static int cancelPurchase(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        class_2168 source = ctx.getSource();
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be used by a player."));
            return 0;
        }
        return PlotManager.getInstance().cancelPurchase(player) ? 1 : 0;
    }
}
