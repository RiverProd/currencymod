package net.currencymod.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.currencymod.trade.TradeManager;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_7157;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public class TradeCommand {
    
    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 registryAccess, class_2170.class_5364 environment) {
        dispatcher.register(
            method_9247("tradehand")
                .executes(TradeCommand::showHelp)
                .then(method_9247("accept")
                    .executes(TradeCommand::acceptTrade)
                )
                .then(method_9247("deny")
                    .executes(TradeCommand::denyTrade)
                )
                .then(method_9244("player", class_2186.method_9305())
                    .then(method_9244("price", DoubleArgumentType.doubleArg(0.01))
                        .executes(TradeCommand::createTradeRequest)
                    )
                )
        );
    }
    
    /**
     * Show help for the tradehand command
     */
    private static int showHelp(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        class_2561 header = class_2561.method_43470("📦 ").method_27692(class_124.field_1065)
            .method_10852(class_2561.method_43470("Trade Command Help").method_27695(class_124.field_1065, class_124.field_1067));
            
        class_2561 usage = class_2561.method_43470("\nUsage:")
            .method_10852(class_2561.method_43470("\n• /tradehand <player> <price>").method_27692(class_124.field_1054))
            .method_10852(class_2561.method_43470(" - Send a trade request for the item in your hand"))
            .method_10852(class_2561.method_43470("\n• /tradehand accept").method_27692(class_124.field_1060))
            .method_10852(class_2561.method_43470(" - Accept an incoming trade request"))
            .method_10852(class_2561.method_43470("\n• /tradehand deny").method_27692(class_124.field_1061))
            .method_10852(class_2561.method_43470(" - Deny an incoming trade request"));
            
        class_2561 note = class_2561.method_43470("\n\nNotes:")
            .method_10852(class_2561.method_43470("\n• When you create a trade request, the item is immediately removed from your inventory"))
            .method_10852(class_2561.method_43470("\n• If the trade expires (after 1 minute) or is denied, the item is returned to you"))
            .method_10852(class_2561.method_43470("\n• You'll receive reminders as the trade request approaches expiration"));
            
        source.method_9226(() -> header.method_27661().method_10852(usage).method_10852(note), false);
        return 1;
    }
    
    /**
     * Create a new trade request
     */
    private static int createTradeRequest(CommandContext<class_2168> context) throws CommandSyntaxException {
        class_2168 source = context.getSource();
        
        // Check if the command was run by a player
        if (!(source.method_9228() instanceof class_3222 sender)) {
            source.method_9213(class_2561.method_43470("This command can only be executed by a player"));
            return 0;
        }
        
        // Get the target player and price
        class_3222 target = class_2186.method_9315(context, "player");
        double price = DoubleArgumentType.getDouble(context, "price");
        
        // Don't allow trading with yourself
        if (sender.equals(target)) {
            source.method_9213(class_2561.method_43470("You can't trade with yourself"));
            return 0;
        }
        
        // Check if the player has an item in their hand
        // Make sure to use Hand.MAIN_HAND explicitly for consistency
        class_1799 handItem = sender.method_5998(class_1268.field_5808);
        if (handItem.method_7960()) {
            source.method_9213(class_2561.method_43470("You need to hold an item in your main hand to trade"));
            return 0;
        }
        
        // Create the trade request
        boolean success = TradeManager.getInstance().createTradeRequest(sender, target, handItem, price);
        
        if (!success) {
            source.method_9213(class_2561.method_43470("That player already has a pending trade request. Try again later."));
            return 0;
        }
        
        return 1;
    }
    
    /**
     * Accept an incoming trade request
     */
    private static int acceptTrade(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        // Check if the command was run by a player
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be executed by a player"));
            return 0;
        }
        
        // Accept the trade request
        boolean success = TradeManager.getInstance().acceptTradeRequest(player);
        
        if (!success) {
            source.method_9213(class_2561.method_43470("You don't have any pending trade requests to accept"));
            return 0;
        }
        
        return 1;
    }
    
    /**
     * Deny an incoming trade request
     */
    private static int denyTrade(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        // Check if the command was run by a player
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be executed by a player"));
            return 0;
        }
        
        // Deny the trade request
        boolean success = TradeManager.getInstance().denyTradeRequest(player);
        
        if (!success) {
            source.method_9213(class_2561.method_43470("You don't have any pending trade requests to deny"));
            return 0;
        }
        
        return 1;
    }
} 