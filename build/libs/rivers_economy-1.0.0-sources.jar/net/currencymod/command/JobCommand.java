package net.currencymod.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.currencymod.CurrencyMod;
import net.currencymod.jobs.Job;
import net.currencymod.jobs.JobManager;
import net.currencymod.jobs.PlayerJobLevel;
import net.currencymod.jobs.PlayerJobStreak;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_3222;
import net.minecraft.class_5250;
import net.minecraft.class_7157;
import net.minecraft.server.MinecraftServer;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.currencymod.jobs.Booster;
import net.currencymod.jobs.BoosterType;
import net.currencymod.jobs.PlayerBoosterData;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.currencymod.config.GuiPreferenceManager;
import net.currencymod.ui.JobsScreenHandler;

import java.util.List;
import java.util.UUID;
import java.util.ArrayList;

import static net.minecraft.class_2170.method_9247;
import static net.minecraft.class_2170.method_9244;

public class JobCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 registryAccess, class_2170.class_5364 environment) {
        dispatcher.register(
            method_9247("jobs")
                .executes(JobCommand::openOrHelp)
                .then(method_9247("list")
                    .executes(JobCommand::openOrList)
                )
                .then(method_9247("activate")
                    .then(method_9244("jobId", StringArgumentType.greedyString())
                        .executes(context -> activateJob(context, StringArgumentType.getString(context, "jobId")))
                    )
                    .executes(context -> {
                        class_2168 source = context.getSource();
                        source.method_9226(() -> class_2561.method_43470("Use ").method_10852(
                            class_2561.method_43470("/jobs list").method_27692(class_124.field_1054)
                        ).method_27693(" to see available jobs and click on one to activate it."), false);
                        return 1;
                    })
                )
                .then(method_9247("abandon")
                    .executes(JobCommand::promptAbandonJob)
                    .then(method_9247("confirm")
                        .executes(JobCommand::confirmAbandonJob)
                    )
                )
                .then(method_9247("complete")
                    .executes(JobCommand::completeJob)
                )
                .then(method_9247("info")
                    .executes(JobCommand::showActiveJob)
                )
                .then(method_9247("level")
                    .executes(JobCommand::showPlayerLevel)
                )
                .then(method_9247("boosters")
                    .executes(context -> showBoosters(context.getSource()))
                    .then(method_9247("use")
                        .then(method_9244("type", StringArgumentType.word())
                            .suggests((context, builder) -> {
                                for (BoosterType type : BoosterType.values()) {
                                    builder.suggest(type.name().toLowerCase());
                                }
                                return builder.buildFuture();
                            })
                            .executes(context -> useBooster(
                                context.getSource(), 
                                StringArgumentType.getString(context, "type")
                            ))
                        )
                    )
                )
                .then(method_9247("skip")
                    .executes(JobCommand::promptSkipJob)
                    .then(method_9247("confirm")
                        .executes(JobCommand::confirmSkipJob)
                    )
                )
        );
    }
    
    /** Opens GUI if enabled, otherwise falls back to the help text. */
    private static int openOrHelp(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        if (source.method_9228() instanceof class_3222 player
                && GuiPreferenceManager.getInstance().isGuiEnabled(player.method_5667())) {
            JobsScreenHandler.open(player);
            return 1;
        }
        return showHelp(context);
    }

    /** Opens GUI if enabled, otherwise falls back to the text job list. */
    private static int openOrList(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        if (source.method_9228() instanceof class_3222 player
                && GuiPreferenceManager.getInstance().isGuiEnabled(player.method_5667())) {
            JobsScreenHandler.open(player);
            return 1;
        }
        return listJobs(context);
    }

    /**
     * Show command help
     */
    private static int showHelp(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        class_2561 helpHeader = class_2561.method_43470("=== Jobs Help ===").method_27695(class_124.field_1065, class_124.field_1067);
        
        // Description of the system
        class_2561 description = class_2561.method_43470("Complete jobs to earn money. Jobs require collecting specific items and have varying rewards. Higher job levels provide bonus rewards and unlock more available jobs.").method_27692(class_124.field_1054);
        
        // Commands list
        class_2561 commandsHeader = class_2561.method_43470("\nCommands:").method_27692(class_124.field_1065);
        
        class_2561 listCmd = class_2561.method_43470("\n/jobs list").method_27692(class_124.field_1060)
            .method_10852(class_2561.method_43470(" - View your available jobs").method_27692(class_124.field_1080));
        
        class_2561 activeCmd = class_2561.method_43470("\n/jobs active").method_27692(class_124.field_1060)
            .method_10852(class_2561.method_43470(" - View your current active job").method_27692(class_124.field_1080));
        
        class_2561 activateCmd = class_2561.method_43470("\n/jobs activate <id>").method_27692(class_124.field_1060)
            .method_10852(class_2561.method_43470(" - Activate a job by its ID").method_27692(class_124.field_1080));
        
        class_2561 completeCmd = class_2561.method_43470("\n/jobs complete").method_27692(class_124.field_1060)
            .method_10852(class_2561.method_43470(" - Complete your active job").method_27692(class_124.field_1080));
        
        class_2561 abandonCmd = class_2561.method_43470("\n/jobs abandon").method_27692(class_124.field_1060)
            .method_10852(class_2561.method_43470(" - Abandon your active job (with penalty)").method_27692(class_124.field_1080));
        
        class_2561 levelCmd = class_2561.method_43470("\n/jobs level").method_27692(class_124.field_1060)
            .method_10852(class_2561.method_43470(" - View your job level progress").method_27692(class_124.field_1080));
        
        // Job slots information
        class_2561 jobSlotsHeader = class_2561.method_43470("\n\nJob Slots:").method_27692(class_124.field_1065);
        
        class_2561 jobSlotsInfo = class_2561.method_43470("\nYour job level determines how many jobs you can choose from:").method_27692(class_124.field_1054);
        class_2561 level0Info = class_2561.method_43470("\n • Levels 0-4: 5 jobs").method_27692(class_124.field_1080);
        class_2561 level5Info = class_2561.method_43470("\n • Levels 5-9: 6 jobs").method_27692(class_124.field_1080);
        class_2561 level10Info = class_2561.method_43470("\n • Levels 10-14: 7 jobs").method_27692(class_124.field_1080);
        class_2561 level15Info = class_2561.method_43470("\n • Levels 15-19: 8 jobs").method_27692(class_124.field_1080);
        class_2561 level20Info = class_2561.method_43470("\n • Levels 20-24: 10 jobs").method_27692(class_124.field_1080);
        class_2561 level25Info = class_2561.method_43470("\n • Levels 25-29: 12 jobs").method_27692(class_124.field_1080);
        class_2561 level30Info = class_2561.method_43470("\n • Level 30: 14 jobs").method_27692(class_124.field_1080);
        
        // Send help messages
        source.method_9226(() -> helpHeader, false);
        source.method_9226(() -> description, false);
        source.method_9226(() -> commandsHeader, false);
        source.method_9226(() -> listCmd, false);
        source.method_9226(() -> activeCmd, false);
        source.method_9226(() -> activateCmd, false);
        source.method_9226(() -> completeCmd, false);
        source.method_9226(() -> abandonCmd, false);
        source.method_9226(() -> levelCmd, false);
        
        // Send job slots information
        source.method_9226(() -> jobSlotsHeader, false);
        source.method_9226(() -> jobSlotsInfo, false);
        source.method_9226(() -> level0Info, false);
        source.method_9226(() -> level5Info, false);
        source.method_9226(() -> level10Info, false);
        source.method_9226(() -> level15Info, false);
        source.method_9226(() -> level20Info, false);
        source.method_9226(() -> level25Info, false);
        source.method_9226(() -> level30Info, false);
        
        return 1;
    }
    
    /**
     * Helper method to check and end expired streaks
     * This should be called at the beginning of each job command
     */
    private static void checkAndEndExpiredStreak(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        // Only proceed if this is a player
        if (!(source.method_9228() instanceof class_3222 player)) {
            return;
        }
        
        MinecraftServer server = player.method_5682();
        if (server == null) return;
        
        JobManager jobManager = JobManager.getInstance();
        PlayerJobStreak streak = jobManager.getPlayerJobStreak(player);
        
        // Only check if player had an active streak
        if (streak.getStreakLength() > 0) {
            if (streak.checkAndEndExpiredStreak(server)) {
                // The streak was ended - silently update data
                jobManager.save();
            }
        }
    }
    
    /**
     * Shows a list of all jobs and their rewards.
     *
     * @param context The command context
     * @return 1 if successful
     */
    private static int listJobs(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        // Check if the command was run by a player
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be executed by a player"));
            return 0;
        }
        
        List<Job> jobs = JobManager.getInstance().getPlayerJobs(player);
        PlayerJobLevel jobLevel = JobManager.getInstance().getPlayerJobLevel(player);
        PlayerJobStreak jobStreak = JobManager.getInstance().getPlayerJobStreak(player);
        PlayerBoosterData boosterData = JobManager.getInstance().getPlayerBoosterData(player);
        
        // Get the active job for this player
        Job activeJob = JobManager.getInstance().getActiveJob(player);
        
        // Get all bonuses
        int[] bonuses = JobManager.getBonusPercentages(jobLevel, jobStreak, boosterData);
        int levelBonus = bonuses[0];
        int streakBonus = bonuses[1];
        int boosterBonus = bonuses[2];
        int totalBonusPercent = bonuses[3];
        
        double totalMultiplier = 1.0 + (totalBonusPercent / 100.0);
        
        // Create a sorted list for display - active job first, then sorted by reward
        List<Job> sortedJobs = new ArrayList<>(jobs);
        sortedJobs.sort((job1, job2) -> {
            boolean job1Active = job1.equals(activeJob);
            boolean job2Active = job2.equals(activeJob);
            if (job1Active != job2Active) {
                return job1Active ? -1 : 1;
            }
            return Integer.compare(job2.getReward(), job1.getReward());
        });
        
        // Display job list header
        source.method_9226(() -> class_2561.method_43470("Available Jobs:").method_27695(class_124.field_1065, class_124.field_1067), false);
        
        // Display job skips
        net.currencymod.jobs.PlayerJobSkipData skipData = JobManager.getInstance().getPlayerSkipData(player);
        int skipCount = skipData.getSkipCount();
        source.method_9226(() -> class_2561.method_43470("Job Skips Available: ").method_27692(class_124.field_1080)
                .method_10852(class_2561.method_43470(String.valueOf(skipCount)).method_27692(class_124.field_1065)), false);
        
        // Display bonuses if any
        if (totalBonusPercent > 0) {
            class_5250 bonusText = class_2561.method_43470("Bonuses: ").method_27692(class_124.field_1054);
            
            if (levelBonus > 0) {
                bonusText.method_10852(class_2561.method_43470("+" + levelBonus + "% (Level " + jobLevel.getLevel() + ") ").method_27692(class_124.field_1060));
            }
            
            if (streakBonus > 0) {
                bonusText.method_10852(class_2561.method_43470("+" + streakBonus + "% (Streak) ").method_27692(class_124.field_1075));
            }
            
            if (boosterBonus > 0) {
                Booster activeBooster = boosterData.getActiveBooster();
                if (activeBooster != null) {
                    bonusText.method_10852(class_2561.method_43470("+" + boosterBonus + "% (" + activeBooster.getType().getDisplayName() + ") ")
                            .method_27692(class_124.field_1076));
                }
            }
            
            bonusText.method_10852(class_2561.method_43470("= +" + totalBonusPercent + "% Total").method_27692(class_124.field_1065));
            source.method_9226(() -> bonusText, false);
        }
        
        // Show an empty line
        source.method_9226(() -> class_2561.method_43470(""), false);
        
        // Display each job
        for (Job job : sortedJobs) {
            boolean isActive = job.equals(activeJob);
            
            // Calculate adjusted reward based on bonuses
            int baseReward = job.getReward();
            int adjustedReward = (int) Math.ceil(baseReward * totalMultiplier);
            
            // Calculate adjusted quantity based on boosters
            int originalQuantity = job.getQuantity();
            int adjustedQuantity = JobManager.getAdjustedQuantity(originalQuantity, boosterData);
            
            // Use the new consolidated method that handles both reward and quantity adjustments
            class_2561 clickableText = job.createClickableTextWithAdjustments(
                "/jobs activate ", 
                adjustedQuantity, 
                adjustedQuantity != originalQuantity, 
                adjustedReward, 
                baseReward != adjustedReward);
            
            source.method_9226(() -> clickableText, false);
        }
        
        return 1;
    }
    
    /**
     * Activate a job for a player
     */
    private static int activateJob(CommandContext<class_2168> context, String jobId) {
        class_2168 source = context.getSource();
        
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be executed by a player"));
            return 0;
        }
        
        // Check if streak should end
        checkAndEndExpiredStreak(context);
        
        // Trim the job ID to handle any extra whitespace that might be causing issues
        String cleanJobId = jobId.trim();
        
        // Log the job ID being used for debugging
        CurrencyMod.LOGGER.debug("Attempting to activate job with ID: '{}'", cleanJobId);
        
        // Try to activate the job
        JobManager jobManager = JobManager.getInstance();
        boolean success = jobManager.activateJob(player, cleanJobId);
        
        if (!success) {
            // If there was an existing active job, first check if the job actually exists
            Job activeJob = jobManager.getActiveJob(player);
            
            if (activeJob != null) {
                // Player already has an active job - error message is sent by the job manager
                return 0;
            }
            
            // Log this situation for debugging
            CurrencyMod.LOGGER.warn("Failed to activate job for player {}, jobId: '{}'", 
                player.method_5477().getString(), cleanJobId);
            
            // Try to provide helpful feedback if the job doesn't exist
            source.method_9226(() -> class_2561.method_43470("⚠️ Could not activate the job. Please use ")
                .method_10852(class_2561.method_43470("/jobs list").method_27692(class_124.field_1054))
                .method_10852(class_2561.method_43470(" to see available jobs.")), false);
                
            return 0;
        }
        
        // Get the activated job and calculate adjusted values
        Job activatedJob = jobManager.getActiveJob(player);
        if (activatedJob != null) {
            // Get player's boosters, level, and streak for adjustments
            PlayerJobLevel jobLevel = jobManager.getPlayerJobLevel(player);
            PlayerJobStreak jobStreak = jobManager.getPlayerJobStreak(player);
            PlayerBoosterData boosterData = jobManager.getPlayerBoosterData(player);
            
            // Calculate adjusted reward and quantity
            double totalMultiplier = JobManager.getTotalMultiplier(jobLevel, jobStreak, boosterData);
            int adjustedReward = (int) Math.ceil(activatedJob.getReward() * totalMultiplier);
            int adjustedQuantity = JobManager.getAdjustedQuantity(activatedJob.getQuantity(), boosterData);
            
            // Show the job with both adjusted reward and quantity
            source.method_9226(() -> activatedJob.getDisplayTextWithAdjustments(
                true, // includeStatus
                adjustedQuantity,
                boosterData.hasActiveBooster(), // showOriginalQuantity if there's a booster
                adjustedReward,
                totalMultiplier > 1.0), // showBaseReward if there's any bonus
                false);
            
            source.method_9226(() -> class_2561.method_43470("Job activated! Collect the items and use /jobs complete to finish.")
                .method_27692(class_124.field_1060), false);
        }
        
        return 1;
    }
    
    /**
     * Prompt to abandon the active job
     */
    private static int promptAbandonJob(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be executed by a player"));
            return 0;
        }
        
        // Check if streak should end
        checkAndEndExpiredStreak(context);
        
        // Get the active job to show the penalty before abandoning
        Job activeJob = JobManager.getInstance().getActiveJob(player);
        if (activeJob == null) {
            source.method_9226(() -> class_2561.method_43470("You don't have an active job to abandon.").method_27692(class_124.field_1061), false);
            return 0;
        }
        
        // Check if this is a mega job - if so, no abandonment fee
        if (activeJob.isMegaJob()) {
            source.method_9226(() -> class_2561.method_43470("✓ MEGA jobs can be abandoned without a penalty. ")
                .method_27692(class_124.field_1060)
                .method_10852(class_2561.method_43470("Type ")
                .method_27692(class_124.field_1054))
                .method_10852(class_2561.method_43470("/jobs abandon confirm")
                .method_27692(class_124.field_1075))
                .method_10852(class_2561.method_43470(" to confirm.")
                .method_27692(class_124.field_1054)), false);
            return 1;
        }
        
        // For regular jobs, calculate the penalty
        PlayerJobLevel jobLevel = JobManager.getInstance().getPlayerJobLevel(player);
        PlayerJobStreak jobStreak = JobManager.getInstance().getPlayerJobStreak(player);
        int level = jobLevel.getLevel();
        
        // Calculate the adjusted reward with level and streak bonuses
        int baseReward = activeJob.getReward();
        double totalMultiplier = JobManager.getTotalMultiplier(jobLevel, jobStreak);
        int adjustedReward = (int) Math.ceil(baseReward * totalMultiplier);
        
        // Calculate penalty as 75% of the adjusted reward
        int penalty = Math.max(1, (int)(adjustedReward * 0.75));
        
        source.method_9226(() -> class_2561.method_43470("⚠️ Warning: ").method_27695(class_124.field_1061, class_124.field_1067)
                .method_10852(class_2561.method_43470("Abandoning this job will cost you ")
                .method_27692(class_124.field_1054))
                .method_10852(class_2561.method_43470("$" + penalty).method_27695(class_124.field_1061, class_124.field_1067))
                .method_10852(class_2561.method_43470(". Type ").method_27692(class_124.field_1054))
                .method_10852(class_2561.method_43470("/jobs abandon confirm").method_27692(class_124.field_1061))
                .method_10852(class_2561.method_43470(" to confirm.").method_27692(class_124.field_1054)), false);
        
        return 1;
    }
    
    /**
     * Confirm and abandon the active job for the player
     */
    private static int confirmAbandonJob(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be executed by a player"));
            return 0;
        }
        
        // Check if streak should end
        checkAndEndExpiredStreak(context);
        
        boolean success = JobManager.getInstance().abandonJob(player);
        
        if (!success) {
            // Error message is sent by the job manager
            return 0;
        }
        
        return 1;
    }
    
    /**
     * Complete the active job for the player
     */
    private static int completeJob(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be executed by a player"));
            return 0;
        }
        
        // Check if streak should end
        checkAndEndExpiredStreak(context);
        
        // Get necessary job info before completing it
        Job job = JobManager.getInstance().getActiveJob(player);
        if (job == null) {
            source.method_9213(class_2561.method_43470("You don't have an active job to complete"));
            return 0;
        }
        
        // Get bonus and reward information before completing the job
        PlayerJobLevel jobLevel = JobManager.getInstance().getPlayerJobLevel(player);
        PlayerJobStreak jobStreak = JobManager.getInstance().getPlayerJobStreak(player);
        PlayerBoosterData boosterData = JobManager.getInstance().getPlayerBoosterData(player);
        
        // Calculate reward with bonuses
        double totalMultiplier = JobManager.getTotalMultiplier(jobLevel, jobStreak, boosterData);
        int baseReward = job.getReward();
        int finalReward = (int) Math.ceil(baseReward * totalMultiplier);
        String itemName = job.getItem().method_7848().getString();
        int quantity = JobManager.getAdjustedQuantity(job.getQuantity(), boosterData);
        
        // Complete the job
        boolean success = JobManager.getInstance().completeJob(player);
        
        if (!success) {
            source.method_9213(class_2561.method_43470("You don't have enough items to complete your job"));
            return 0;
        }
        
        // Send success messages
        source.method_9226(() -> class_2561.method_43470("✓ ").method_27692(class_124.field_1060)
            .method_10852(class_2561.method_43470("Job Completed!").method_27695(class_124.field_1060, class_124.field_1067)), false);
            
        source.method_9226(() -> class_2561.method_43470("• You sold: ").method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43470(quantity + " " + itemName).method_27692(class_124.field_1075)), false);
            
        source.method_9226(() -> class_2561.method_43470("• You earned: ").method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43470("$" + finalReward).method_27692(class_124.field_1065)), false);
        
        // Show bonus info if there was a bonus
        if (finalReward > baseReward) {
            int[] bonuses = JobManager.getBonusPercentages(jobLevel, jobStreak, boosterData);
            int totalBonusPercent = bonuses[3];
            
            source.method_9226(() -> class_2561.method_43470("  (").method_27692(class_124.field_1080)
                .method_10852(class_2561.method_43470("+" + totalBonusPercent + "%").method_27692(class_124.field_1060))
                .method_10852(class_2561.method_43470(" bonus applied)").method_27692(class_124.field_1080)), false);
        }

        return 1;
    }
    
    /**
     * Shows information about a player's active job.
     *
     * @param context The command context
     * @return 1 if successful, 0 if no active job
     */
    private static int showActiveJob(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        // Check if the command was run by a player
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be executed by a player"));
            return 0;
        }
        
        UUID playerUuid = player.method_5667();
        
        // Get the active job
        Job job = JobManager.getInstance().getActiveJob(player);
        if (job == null) {
            source.method_9226(() -> class_2561.method_43470("You don't have an active job. Use /jobs list to see available jobs.").method_27692(class_124.field_1061), false);
            return 0;
        }
        
        // Get player job level and streak
        PlayerJobLevel jobLevel = JobManager.getInstance().getPlayerJobLevel(playerUuid);
        PlayerJobStreak jobStreak = JobManager.getInstance().getPlayerJobStreak(player);
        PlayerBoosterData boosterData = JobManager.getInstance().getPlayerBoosterData(player);
        
        // Get bonuses
        int[] bonuses = JobManager.getBonusPercentages(jobLevel, jobStreak, boosterData);
        int levelBonus = bonuses[0];
        int streakBonus = bonuses[1];
        int boosterBonus = bonuses[2];
        int totalBonusPercent = bonuses[3];
        
        // Calculate the actual reward
        double totalMultiplier = 1.0 + (totalBonusPercent / 100.0);
        int baseReward = job.getReward();
        int actualReward = (int) Math.ceil(baseReward * totalMultiplier);
        
        // Calculate adjusted quantity if a booster with quantity reduction is active
        int originalQuantity = job.getQuantity();
        int adjustedQuantity = JobManager.getAdjustedQuantity(originalQuantity, boosterData);
        
        // Get counts of collected items
        int itemsCollected = JobManager.getInstance().getCollectedItems(playerUuid, job.getItem());
        int itemsRemaining = adjustedQuantity - itemsCollected;
        float percentComplete = (float) itemsCollected / adjustedQuantity * 100;
        
        // Create header
        source.method_9226(() -> class_2561.method_43470("Your Active Job:").method_27695(class_124.field_1065, class_124.field_1067), false);
        
        // Use the new consolidated method to display job details with both adjusted quantity and reward
        class_5250 jobDisplayText = job.getDisplayTextWithAdjustments(
            true, // Include active status
            adjustedQuantity, 
            originalQuantity != adjustedQuantity, // Show original quantity if different
            actualReward,
            baseReward != actualReward // Show base reward if different
        );
        source.method_9226(() -> jobDisplayText, false);
        
        // Display individual bonuses if any
        if (totalBonusPercent > 0) {
            class_5250 bonusText = class_2561.method_43470("  Bonuses: ").method_27692(class_124.field_1080);
            
            if (levelBonus > 0) {
                bonusText.method_10852(class_2561.method_43470("+" + levelBonus + "% (Level " + jobLevel.getLevel() + ") ").method_27692(class_124.field_1060));
            }
            
            if (streakBonus > 0) {
                bonusText.method_10852(class_2561.method_43470("+" + streakBonus + "% (Streak) ").method_27692(class_124.field_1075));
            }
            
            if (boosterBonus > 0) {
                Booster activeBooster = boosterData.getActiveBooster();
                if (activeBooster != null) {
                    bonusText.method_10852(class_2561.method_43470("+" + boosterBonus + "% (" + activeBooster.getType().getDisplayName() + ") ")
                            .method_27692(class_124.field_1076));
                }
            }
            
            source.method_9226(() -> bonusText, false);
        }
        
        // Progress details
        source.method_9226(() -> class_2561.method_43470("• Progress: ")
            .method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43470(itemsCollected + "/" + adjustedQuantity + " (" + String.format("%.1f", percentComplete) + "%)").method_27692(class_124.field_1068)), false);
        
        // Progress bar
        int barLength = 20;
        int filledBars = (int) (barLength * percentComplete / 100);
        StringBuilder progressBar = new StringBuilder("[");
        for (int i = 0; i < barLength; i++) {
            if (i < filledBars) {
                progressBar.append("■");
            } else {
                progressBar.append("□");
            }
        }
        progressBar.append("]");
        
        // Make barColor final before using it in lambda
        final class_124 barColor;
        if (percentComplete >= 85) {
            barColor = class_124.field_1060;
        } else if (percentComplete >= 50) {
            barColor = class_124.field_1054;
        } else if (percentComplete >= 25) {
            barColor = class_124.field_1065;
        } else {
            barColor = class_124.field_1061;
        }
        
        source.method_9226(() -> class_2561.method_43470("  " + progressBar.toString()).method_27692(barColor), false);
        
        // Action buttons
        class_5250 actionText = class_2561.method_43470("• Actions: ").method_27692(class_124.field_1080);
        
        // Add abandon button
        class_2561 abandonButton = class_2561.method_43470("[Abandon Job]")
            .method_27694(style -> style
                .method_10977(class_124.field_1061)
                .method_10958(new class_2558(class_2558.class_2559.field_11750, "/jobs abandon"))
                .method_10949(new class_2568(class_2568.class_5247.field_24342, class_2561.method_43470("Abandon this job (no reward)")))
            );
        actionText.method_10852(abandonButton);
        
        // Add complete button if job is complete
        if (itemsCollected >= adjustedQuantity) {
            actionText.method_10852(class_2561.method_43470(" ").method_27692(class_124.field_1080));
            class_2561 completeButton = class_2561.method_43470("[Complete Job]")
                .method_27694(style -> style
                    .method_10977(class_124.field_1060)
                    .method_10982(true)
                    .method_10958(new class_2558(class_2558.class_2559.field_11750, "/jobs complete"))
                    .method_10949(new class_2568(class_2568.class_5247.field_24342, class_2561.method_43470("Complete this job and get your reward!")))
                );
            actionText.method_10852(completeButton);
        }
        
        source.method_9226(() -> actionText, false);
        
        return 1;
    }
    
    /**
     * Shows the player's job level.
     *
     * @param context The command context
     * @return 1 if successful
     */
    private static int showPlayerLevel(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        // Check if the command was run by a player
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be executed by a player"));
            return 0;
        }
        
        PlayerJobLevel jobLevel = JobManager.getInstance().getPlayerJobLevel(player);
        PlayerJobStreak jobStreak = JobManager.getInstance().getPlayerJobStreak(player);
        PlayerBoosterData boosterData = JobManager.getInstance().getPlayerBoosterData(player);
        
        // Get current level data
        int level = jobLevel.getLevel();
        int jobsCompleted = jobLevel.getCompletedJobs();
        int jobsRequired = jobLevel.getRequiredJobsForNextLevel();
        int nextLevel = level + 1;
        boolean isMaxLevel = level >= PlayerJobLevel.MAX_LEVEL;
        
        // Get all bonuses
        int[] bonuses = JobManager.getBonusPercentages(jobLevel, jobStreak, boosterData);
        int levelBonus = bonuses[0];
        int streakBonus = bonuses[1]; 
        int boosterBonus = bonuses[2];
        int totalBonusPercent = bonuses[3];
        
        // Calculate percent complete
        float percentComplete = (float) jobsCompleted / jobsRequired * 100;
        
        // Create progress bar
        int barLength = 20;
        int filledBars = (int) (barLength * percentComplete / 100);
        StringBuilder progressBar = new StringBuilder("[");
        for (int i = 0; i < barLength; i++) {
            if (i < filledBars) {
                progressBar.append("■");
            } else {
                progressBar.append("□");
            }
        }
        progressBar.append("]");
        
        // Make barColor final before using it in lambda
        final class_124 barColor;
        if (percentComplete >= 85) {
            barColor = class_124.field_1060;
        } else if (percentComplete >= 50) {
            barColor = class_124.field_1054;
        } else if (percentComplete >= 25) {
            barColor = class_124.field_1065;
        } else {
            barColor = class_124.field_1061;
        }
        
        // Display level info
        source.method_9226(() -> class_2561.method_43470("Your Job Stats:").method_27695(class_124.field_1065, class_124.field_1067), false);
        
        // Level info
        class_5250 levelText = class_2561.method_43470("• Level: ").method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43470(String.valueOf(level)).method_27695(class_124.field_1075, class_124.field_1067));
        
        if (level > 0) {
            levelText.method_10852(class_2561.method_43470(" (+" + levelBonus + "% reward bonus)").method_27692(class_124.field_1060));
        }
        source.method_9226(() -> levelText, false);
        
        // Progress to next level
        if (!isMaxLevel) {
            source.method_9226(() -> class_2561.method_43470("• Next Level: ")
                .method_27692(class_124.field_1080)
                .method_10852(class_2561.method_43470(jobsCompleted + "/" + jobsRequired + " jobs (" + String.format("%.1f", percentComplete) + "%)").method_27692(class_124.field_1068)), false);
            
            // Progress bar
            source.method_9226(() -> class_2561.method_43470("  " + progressBar.toString()).method_27692(barColor), false);
            
            source.method_9226(() -> class_2561.method_43470("• Reaching Level " + nextLevel + ": ")
                .method_27692(class_124.field_1080)
                .method_10852(class_2561.method_43470("+" + (levelBonus + PlayerJobLevel.LEVEL_BONUS_PERCENT) + "% reward bonus").method_27692(class_124.field_1060)), false);
        } else {
            source.method_9226(() -> class_2561.method_43470("• Maximum level reached!").method_27695(class_124.field_1060, class_124.field_1067), false);
        }
        
        // Streak info
        int streakLength = jobStreak.getStreakLength();
        source.method_9226(() -> class_2561.method_43470("• Streak: ").method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43470(String.valueOf(streakLength) + " day" + (streakLength == 1 ? "" : "s")).method_27692(class_124.field_1075)), false);
        
        if (streakLength > 0) {
            source.method_9226(() -> class_2561.method_43470("  • Streak Bonus: ")
                .method_27692(class_124.field_1080)
                .method_10852(class_2561.method_43470("+" + streakBonus + "% to rewards").method_27692(class_124.field_1075)), false);
            
            source.method_9226(() -> class_2561.method_43470("  • Tip: ")
                .method_27692(class_124.field_1080)
                .method_10852(class_2561.method_43470("Complete at least 1 job every Minecraft day to maintain your streak!").method_27692(class_124.field_1054)), false);
        } else {
            source.method_9226(() -> class_2561.method_43470("  • Tip: ")
                .method_27692(class_124.field_1080)
                .method_10852(class_2561.method_43470("Complete jobs on consecutive Minecraft days to earn streak bonuses!").method_27692(class_124.field_1054)), false);
        }
        
        // Active booster info
        Booster activeBooster = boosterData.getActiveBooster();
        if (activeBooster != null) {
            BoosterType type = activeBooster.getType();
            source.method_9226(() -> class_2561.method_43470("• Active Booster: ").method_27692(class_124.field_1080)
                .method_10852(class_2561.method_43470(type.getDisplayName()).method_27695(class_124.field_1076, class_124.field_1067)), false);
            
            source.method_9226(() -> class_2561.method_43470("  • Bonus: ")
                .method_27692(class_124.field_1080)
                .method_10852(class_2561.method_43470("+" + type.getRewardBonus() + "% to rewards").method_27692(class_124.field_1076)), false);
            
            if (type.getQuantityReduction() > 0) {
                source.method_9226(() -> class_2561.method_43470("  • Item Reduction: ")
                    .method_27692(class_124.field_1080)
                    .method_10852(class_2561.method_43470("-" + type.getQuantityReduction() + "% to required items").method_27692(class_124.field_1076)), false);
            }
            
            source.method_9226(() -> class_2561.method_43470("  • Time Remaining: ")
                .method_27692(class_124.field_1080)
                .method_10852(class_2561.method_43470(activeBooster.getFormattedRemainingTime()).method_27692(class_124.field_1054)), false);
        }
        
        // Total bonus info
        if (totalBonusPercent > 0) {
            source.method_9226(() -> class_2561.method_43470("• Total Bonus: ")
                .method_27692(class_124.field_1080)
                .method_10852(class_2561.method_43470("+" + totalBonusPercent + "% to rewards").method_27695(class_124.field_1065, class_124.field_1067)), false);
        }
        
        // Jobs allowed
        int jobsAllowed = jobLevel.getJobsAllowed();
        source.method_9226(() -> class_2561.method_43470("• Jobs Allowed: ")
            .method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43470(String.valueOf(jobsAllowed)).method_27692(class_124.field_1068)), false);
        
        return 1;
    }

    /**
     * Shows the player's boosters.
     *
     * @param source The command source
     * @return 1 if successful
     */
    private static int showBoosters(class_2168 source) {
        class_3222 player = source.method_44023();
        PlayerBoosterData boosterData = JobManager.getInstance().getPlayerBoosterData(player);
        
        // Display header
        source.method_9226(() -> class_2561.method_43470("Your Job Boosters:").method_27695(class_124.field_1065, class_124.field_1067), false);
        
        // Show active booster if any
        Booster activeBooster = boosterData.getActiveBooster();
        if (activeBooster != null) {
            BoosterType type = activeBooster.getType();
            
            source.method_9226(() -> class_2561.method_43470("• Active: ").method_27692(class_124.field_1080)
                .method_10852(class_2561.method_43470(type.getDisplayName()).method_27695(
                    type == BoosterType.PREMIUM ? class_124.field_1065 : class_124.field_1075, class_124.field_1067)), false);
            
            // Show remaining time
            source.method_9226(() -> class_2561.method_43470("  • Time Remaining: ")
                .method_27692(class_124.field_1080)
                .method_10852(class_2561.method_43470(activeBooster.getFormattedRemainingTime()).method_27692(class_124.field_1054)), false);
            
            // Show bonuses
            source.method_9226(() -> class_2561.method_43470("  • Reward Bonus: ")
                .method_27692(class_124.field_1080)
                .method_10852(class_2561.method_43470("+" + type.getRewardBonus() + "%").method_27692(class_124.field_1060)), false);
            
            if (type.getQuantityReduction() > 0) {
                source.method_9226(() -> class_2561.method_43470("  • Item Reduction: ")
                    .method_27692(class_124.field_1080)
                    .method_10852(class_2561.method_43470("-" + type.getQuantityReduction() + "%").method_27692(class_124.field_1076)), false);
            }
        } else {
            source.method_9226(() -> class_2561.method_43470("• No Active Booster").method_27692(class_124.field_1080), false);
        }
        
        // Show owned boosters
        source.method_9226(() -> class_2561.method_43470("• Owned Boosters:").method_27692(class_124.field_1054), false);
        
        boolean hasAnyBoosters = false;
        for (BoosterType type : BoosterType.values()) {
            int count = boosterData.getBoosterCount(type);
            if (count > 0) {
                hasAnyBoosters = true;
                
                // Create formatted booster text
                class_5250 boosterText = class_2561.method_43470("  • ").method_27692(class_124.field_1080)
                    .method_10852(class_2561.method_43470(type.getDisplayName()).method_27692(
                        type == BoosterType.PREMIUM ? class_124.field_1065 : class_124.field_1075))
                    .method_10852(class_2561.method_43470(" x" + count).method_27692(class_124.field_1068))
                    .method_10852(class_2561.method_43470(" (+" + type.getRewardBonus() + "% rewards").method_27692(class_124.field_1060));
                
                if (type.getQuantityReduction() > 0) {
                    boosterText.method_10852(class_2561.method_43470(", -" + type.getQuantityReduction() + "% items").method_27692(class_124.field_1076));
                }
                
                boosterText.method_10852(class_2561.method_43470(")").method_27692(class_124.field_1060));
                
                // Add use button if no active booster
                if (activeBooster == null) {
                    class_2561 useButton = class_2561.method_43470(" [Use]")
                        .method_27694(style -> style
                            .method_10977(class_124.field_1054)
                            .method_30938(true)
                            .method_10958(new class_2558(
                                class_2558.class_2559.field_11750, 
                                "/jobs boosters use " + type.name().toLowerCase()
                            ))
                            .method_10949(new class_2568(
                                class_2568.class_5247.field_24342, 
                                class_2561.method_43470("Activate this booster")
                            ))
                        );
                    boosterText.method_10852(useButton);
                }
                
                source.method_9226(() -> boosterText, false);
            }
        }
        
        if (!hasAnyBoosters) {
            source.method_9226(() -> class_2561.method_43470("  • None").method_27692(class_124.field_1061), false);
            source.method_9226(() -> class_2561.method_43470("  • Complete jobs to have a chance of finding boosters!").method_27692(class_124.field_1054), false);
        }
        
        // Display information about booster effects
        source.method_9226(() -> class_2561.method_43470("• Info:").method_27692(class_124.field_1075), false);
        source.method_9226(() -> class_2561.method_43470("  • Boosters last for 30 minutes").method_27692(class_124.field_1080), false);
        source.method_9226(() -> class_2561.method_43470("  • Only one booster can be active at a time").method_27692(class_124.field_1080), false);
        
        return 1;
    }
    
    /**
     * Uses a booster.
     *
     * @param source The command source
     * @param typeStr The booster type string
     * @return 1 if successful
     */
    private static int useBooster(class_2168 source, String typeStr) {
        class_3222 player = source.method_44023();
        PlayerBoosterData boosterData = JobManager.getInstance().getPlayerBoosterData(player);
        
        // Check if player already has an active booster
        if (boosterData.hasActiveBooster()) {
            source.method_9213(class_2561.method_43470("You already have an active booster! Wait for it to expire before using another."));
            return 0;
        }
        
        // Parse booster type
        BoosterType type;
        try {
            type = BoosterType.valueOf(typeStr.toUpperCase());
        } catch (IllegalArgumentException e) {
            source.method_9213(class_2561.method_43470("Invalid booster type: " + typeStr));
            return 0;
        }
        
        // Try to use the booster
        if (boosterData.useBooster(type)) {
            // Save changes
            JobManager.getInstance().save();
            
            // Send success message
            source.method_9226(() -> class_2561.method_43470("You activated a ").method_27692(class_124.field_1060)
                .method_10852(class_2561.method_43470(type.getDisplayName()).method_27695(
                    type == BoosterType.PREMIUM ? class_124.field_1065 : class_124.field_1075, class_124.field_1067))
                .method_10852(class_2561.method_43470("!").method_27692(class_124.field_1060)), false);
            
            // Show the benefits
            source.method_9226(() -> class_2561.method_43470("• Duration: ")
                .method_27692(class_124.field_1080)
                .method_10852(class_2561.method_43470(type.getDurationMinutes() + " minutes").method_27692(class_124.field_1054)), false);
            
            source.method_9226(() -> class_2561.method_43470("• Reward Bonus: ")
                .method_27692(class_124.field_1080)
                .method_10852(class_2561.method_43470("+" + type.getRewardBonus() + "%").method_27692(class_124.field_1060)), false);
            
            if (type.getQuantityReduction() > 0) {
                source.method_9226(() -> class_2561.method_43470("• Item Reduction: ")
                    .method_27692(class_124.field_1080)
                    .method_10852(class_2561.method_43470("-" + type.getQuantityReduction() + "%").method_27692(class_124.field_1076)), false);
            }
            
            // Let the player know how to check booster time
            source.method_9226(() -> class_2561.method_43470("Type ")
                .method_27692(class_124.field_1080)
                .method_10852(class_2561.method_43470("/jobs boosters").method_27692(class_124.field_1054))
                .method_10852(class_2561.method_43470(" to check your booster status.").method_27692(class_124.field_1080)), false);
            
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("You don't have any " + type.getDisplayName() + " boosters!"));
            return 0;
        }
    }
    
    /**
     * Prompt to skip the active job
     */
    private static int promptSkipJob(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be executed by a player"));
            return 0;
        }
        
        // Check if streak should end
        checkAndEndExpiredStreak(context);
        
        // Get the active job
        Job activeJob = JobManager.getInstance().getActiveJob(player);
        if (activeJob == null) {
            source.method_9226(() -> class_2561.method_43470("You don't have an active job to skip.").method_27692(class_124.field_1061), false);
            return 0;
        }
        
        // Get player's skip count
        net.currencymod.jobs.PlayerJobSkipData skipData = JobManager.getInstance().getPlayerSkipData(player);
        int skipCount = skipData.getSkipCount();
        
        if (skipCount <= 0) {
            source.method_9226(() -> class_2561.method_43470("You don't have any job skips available.").method_27692(class_124.field_1061), false);
            return 0;
        }
        
        // Show confirmation message
        source.method_9226(() -> class_2561.method_43470("⚠️ ").method_27695(class_124.field_1054, class_124.field_1067)
                .method_10852(class_2561.method_43470("Skip this job? ").method_27692(class_124.field_1054))
                .method_10852(class_2561.method_43470("This will complete your current job without penalty and generate a new one. ").method_27692(class_124.field_1080))
                .method_10852(class_2561.method_43470("Type ").method_27692(class_124.field_1054))
                .method_10852(class_2561.method_43470("/jobs skip confirm").method_27692(class_124.field_1061))
                .method_10852(class_2561.method_43470(" to confirm.").method_27692(class_124.field_1054)), false);
        
        source.method_9226(() -> class_2561.method_43470("Job Skips Available: ").method_27692(class_124.field_1080)
                .method_10852(class_2561.method_43470(String.valueOf(skipCount)).method_27692(class_124.field_1065)), false);
        
        return 1;
    }
    
    /**
     * Confirm and skip the active job for the player
     */
    private static int confirmSkipJob(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be executed by a player"));
            return 0;
        }
        
        // Check if streak should end
        checkAndEndExpiredStreak(context);
        
        boolean success = JobManager.getInstance().useJobSkip(player);
        
        if (!success) {
            // Error message is sent by the job manager
            return 0;
        }
        
        return 1;
    }
} 