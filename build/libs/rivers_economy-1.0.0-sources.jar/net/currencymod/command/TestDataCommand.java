package net.currencymod.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import net.currencymod.data.DataManager;
import net.currencymod.util.FileUtil;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_7157;
import net.minecraft.server.MinecraftServer;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.UUID;

import static net.minecraft.class_2170.method_9247;

/**
 * Command for testing data storage functionality
 * This is intended for diagnostic purposes only
 */
public class TestDataCommand {
    
    /**
     * Register the command
     */
    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 registryAccess, class_2170.class_5364 environment) {
        dispatcher.register(
            method_9247("testdata")
                .requires(source -> source.method_9259(4)) // Operator only
                .executes(TestDataCommand::execute)
                .then(method_9247("checkpaths")
                    .executes(TestDataCommand::checkPaths)
                )
                .then(method_9247("filetest")
                    .executes(TestDataCommand::fileTest)
                )
                .then(method_9247("checkpermissions")
                    .executes(TestDataCommand::checkPermissions)
                )
        );
    }
    
    /**
     * Execute the base command - shows available subcommands
     */
    private static int execute(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        source.method_9226(() -> class_2561.method_43470("🔍 Data Storage Testing Tool")
            .method_27695(class_124.field_1075, class_124.field_1067), false);
            
        source.method_9226(() -> class_2561.method_43470("\nAvailable tests:")
            .method_27692(class_124.field_1068), false);
            
        source.method_9226(() -> class_2561.method_43470(" • /testdata checkpaths")
            .method_27692(class_124.field_1054)
            .method_10852(class_2561.method_43470(" - Check critical file paths").method_27692(class_124.field_1080)), false);
            
        source.method_9226(() -> class_2561.method_43470(" • /testdata filetest")
            .method_27692(class_124.field_1054)
            .method_10852(class_2561.method_43470(" - Test file write/read operations").method_27692(class_124.field_1080)), false);
            
        source.method_9226(() -> class_2561.method_43470(" • /testdata checkpermissions")
            .method_27692(class_124.field_1054)
            .method_10852(class_2561.method_43470(" - Check directory and file permissions").method_27692(class_124.field_1080)), false);
            
        return 1;
    }
    
    /**
     * Check critical file paths in the mod
     */
    private static int checkPaths(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        MinecraftServer server = source.method_9211();
        
        source.method_9226(() -> class_2561.method_43470("🔍 Checking critical file paths...")
            .method_27695(class_124.field_1054, class_124.field_1067), true);
            
        // Get the server run directory
        Path runDir = server.method_3831();
        
        source.method_9226(() -> class_2561.method_43470("Server Run Directory: ")
            .method_10852(class_2561.method_43470(runDir.toString()).method_27692(class_124.field_1075)), false);
            
        // Check important directories
        checkDirectory(source, runDir.toFile(), "currency_mod");
        checkDirectory(source, runDir.toFile(), "currency_mod/economy");
        checkDirectory(source, runDir.toFile(), "currency_mod/shops");
        checkDirectory(source, runDir.toFile(), "currency_mod/backups");
        checkDirectory(source, runDir.toFile(), "currency_mod/jobs");
        checkDirectory(source, runDir.toFile(), "currency_mod/plots");
        
        // Check important files
        checkFile(source, runDir.toFile(), "currency_mod/economy.json");
        checkFile(source, runDir.toFile(), "currency_mod/shops.json");
        checkFile(source, runDir.toFile(), "currency_mod/auction_pending_items.json");
        checkFile(source, runDir.toFile(), "currency_mod/job_templates.json");
        checkFile(source, runDir.toFile(), "currency_mod/jobs.json");
        checkFile(source, runDir.toFile(), "currency_mod/plots.json");
        checkFile(source, runDir.toFile(), "currency_mod/shop_transactions.json");
        checkFile(source, runDir.toFile(), "currency_mod/marketplace.json");
        
        return 1;
    }
    
    /**
     * Check if a directory exists and report to user
     */
    private static void checkDirectory(class_2168 source, File baseDir, String relativePath) {
        File dir = new File(baseDir, relativePath);
        
        if (dir.exists() && dir.isDirectory()) {
            source.method_9226(() -> class_2561.method_43470("✅ Directory exists: ")
                .method_10852(class_2561.method_43470(relativePath).method_27692(class_124.field_1060)), false);
        } else if (dir.exists() && !dir.isDirectory()) {
            source.method_9226(() -> class_2561.method_43470("❌ Path exists but is not a directory: ")
                .method_10852(class_2561.method_43470(relativePath).method_27692(class_124.field_1061)), false);
        } else {
            source.method_9226(() -> class_2561.method_43470("❌ Directory does not exist: ")
                .method_10852(class_2561.method_43470(relativePath).method_27692(class_124.field_1061)), false);
        }
    }
    
    /**
     * Check if a file exists and report to user
     */
    private static void checkFile(class_2168 source, File baseDir, String relativePath) {
        File file = new File(baseDir, relativePath);
        
        if (file.exists() && file.isFile()) {
            source.method_9226(() -> class_2561.method_43470("✅ File exists: ")
                .method_10852(class_2561.method_43470(relativePath).method_27692(class_124.field_1060))
                .method_10852(class_2561.method_43470(" (" + (file.length() / 1024) + " KB)").method_27692(class_124.field_1080)), false);
        } else if (file.exists() && !file.isFile()) {
            source.method_9226(() -> class_2561.method_43470("❌ Path exists but is not a file: ")
                .method_10852(class_2561.method_43470(relativePath).method_27692(class_124.field_1061)), false);
        } else {
            source.method_9226(() -> class_2561.method_43470("⚠️ File does not exist: ")
                .method_10852(class_2561.method_43470(relativePath).method_27692(class_124.field_1065)), false);
        }
    }
    
    /**
     * Test file write and read operations
     */
    private static int fileTest(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        MinecraftServer server = source.method_9211();
        
        source.method_9226(() -> class_2561.method_43470("🔍 Testing file operations...")
            .method_27695(class_124.field_1054, class_124.field_1067), true);
            
        // Generate a unique test filename
        String testFileName = "currency_mod/test_" + UUID.randomUUID() + ".txt";
        String testContent = "This is a test file created at " + System.currentTimeMillis() + "\n" +
                             "It should be automatically deleted after the test.";
        
        // Create test file using FileUtil
        Path runDirPath = server.method_3831();
        File testFile = runDirPath.resolve(testFileName).toFile();
        
        try {
            // Test parent directory creation
            File parent = testFile.getParentFile();
            if (!parent.exists()) {
                boolean created = parent.mkdirs();
                source.method_9226(() -> class_2561.method_43470(created ? 
                    "✅ Created parent directory: " : 
                    "❌ Failed to create parent directory: ")
                    .method_10852(class_2561.method_43470(parent.toString())
                    .method_27692(created ? class_124.field_1060 : class_124.field_1061)), false);
            }
            
            // Test file writing
            boolean writeSuccess = FileUtil.safeWriteToFile(server, testFile, testContent);
            
            if (writeSuccess) {
                source.method_9226(() -> class_2561.method_43470("✅ Successfully wrote test file: ")
                    .method_10852(class_2561.method_43470(testFileName).method_27692(class_124.field_1060)), false);
                
                // Test file reading
                String readContent = FileUtil.safeReadFromFile(testFile);
                boolean readSuccess = readContent != null && readContent.trim().equals(testContent);
                
                source.method_9226(() -> class_2561.method_43470(readSuccess ?
                    "✅ Successfully read test file with matching content" :
                    "❌ Failed to read test file or content did not match")
                    .method_27692(readSuccess ? class_124.field_1060 : class_124.field_1061), false);
                
                // Delete test file
                boolean deleteSuccess = testFile.delete();
                source.method_9226(() -> class_2561.method_43470(deleteSuccess ?
                    "✅ Successfully deleted test file" :
                    "❌ Failed to delete test file")
                    .method_27692(deleteSuccess ? class_124.field_1060 : class_124.field_1061), false);
            } else {
                source.method_9226(() -> class_2561.method_43470("❌ Failed to write test file: ")
                    .method_10852(class_2561.method_43470(testFileName).method_27692(class_124.field_1061)), false);
            }
        } catch (Exception e) {
            source.method_9226(() -> class_2561.method_43470("❌ Exception during file test: ")
                .method_10852(class_2561.method_43470(e.getMessage()).method_27692(class_124.field_1061)), false);
            
            try {
                // Attempt to clean up
                if (testFile.exists()) {
                    testFile.delete();
                }
            } catch (Exception ignored) {
                // Ignore cleanup errors
            }
        }
        
        return 1;
    }
    
    /**
     * Check file and directory permissions
     */
    private static int checkPermissions(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        MinecraftServer server = source.method_9211();
        
        source.method_9226(() -> class_2561.method_43470("🔍 Checking file permissions...")
            .method_27695(class_124.field_1054, class_124.field_1067), true);
            
        // Get the server run directory
        Path runDirPath = server.method_3831();
        File runDir = runDirPath.toFile();
        
        // Check run directory
        checkDirectoryPermissions(source, runDir, "Server Run Directory");
        
        // Check important directories
        File currencyModDir = new File(runDir, "currency_mod");
        checkDirectoryPermissions(source, currencyModDir, "Currency Mod Directory");
        
        if (currencyModDir.exists()) {
            File economyDir = new File(currencyModDir, "economy");
            checkDirectoryPermissions(source, economyDir, "Economy Data Directory");
            
            File shopsDir = new File(currencyModDir, "shops");
            checkDirectoryPermissions(source, shopsDir, "Shops Data Directory");
            
            File backupsDir = new File(currencyModDir, "backups");
            checkDirectoryPermissions(source, backupsDir, "Backups Directory");
            
            // Check important files
            File economyFile = new File(runDir, "currency_mod/economy.json");
            testFilePermissions(source, economyFile, "Economy Data File");
            
            File shopsFile = new File(runDir, "currency_mod/shops.json");
            testFilePermissions(source, shopsFile, "Shops Data File");
        }
        
        return 1;
    }
    
    /**
     * Test and report directory permissions
     */
    private static void checkDirectoryPermissions(class_2168 source, File dir, String description) {
        if (!dir.exists()) {
            source.method_9226(() -> class_2561.method_43470("⚠️ " + description + " does not exist: ")
                .method_10852(class_2561.method_43470(dir.toString()).method_27692(class_124.field_1065)), false);
            return;
        }
        
        if (!dir.isDirectory()) {
            source.method_9226(() -> class_2561.method_43470("❌ " + description + " exists but is not a directory: ")
                .method_10852(class_2561.method_43470(dir.toString()).method_27692(class_124.field_1061)), false);
            return;
        }
        
        boolean canRead = dir.canRead();
        boolean canWrite = dir.canWrite();
        boolean canExecute = dir.canExecute();
        
        source.method_9226(() -> class_2561.method_43470((canRead && canWrite && canExecute) ? "✅ " : "❌ ")
            .method_10852(class_2561.method_43470(description + ": ").method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470(dir.toString()).method_27692(class_124.field_1075))
            .method_10852(class_2561.method_43470(" [Read: " + (canRead ? "Yes" : "No") + 
                              ", Write: " + (canWrite ? "Yes" : "No") + 
                              ", Execute: " + (canExecute ? "Yes" : "No") + "]")
                  .method_27692(canRead && canWrite && canExecute ? class_124.field_1060 : class_124.field_1061)), false);
    }
    
    /**
     * Test and report file permissions
     */
    private static void testFilePermissions(class_2168 source, File file, String description) {
        if (!file.exists()) {
            source.method_9226(() -> class_2561.method_43470("⚠️ " + description + " does not exist: ")
                .method_10852(class_2561.method_43470(file.toString()).method_27692(class_124.field_1065)), false);
            return;
        }
        
        if (!file.isFile()) {
            source.method_9226(() -> class_2561.method_43470("❌ " + description + " exists but is not a file: ")
                .method_10852(class_2561.method_43470(file.toString()).method_27692(class_124.field_1061)), false);
            return;
        }
        
        boolean canRead = file.canRead();
        boolean canWrite = file.canWrite();
        
        source.method_9226(() -> class_2561.method_43470((canRead && canWrite) ? "✅ " : "❌ ")
            .method_10852(class_2561.method_43470(description + ": ").method_27692(class_124.field_1068))
            .method_10852(class_2561.method_43470(file.toString()).method_27692(class_124.field_1075))
            .method_10852(class_2561.method_43470(" [Read: " + (canRead ? "Yes" : "No") + 
                              ", Write: " + (canWrite ? "Yes" : "No") + "]")
                  .method_27692(canRead && canWrite ? class_124.field_1060 : class_124.field_1061)), false);
    }
} 