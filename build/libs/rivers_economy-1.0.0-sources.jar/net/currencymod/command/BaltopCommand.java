package net.currencymod.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import net.currencymod.CurrencyMod;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_7157;
import com.mojang.authlib.GameProfile;

import java.util.*;
import java.util.stream.Collectors;

import static net.minecraft.class_2170.method_9247;

public class BaltopCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 registryAccess, class_2170.class_5364 environment) {
        dispatcher.register(
            method_9247("baltop")
                .executes(BaltopCommand::execute)
        );
    }
    
    /**
     * Execute the baltop command to show the top 10 richest players
     */
    private static int execute(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        // Make sure the current player is in the economy system
        if (source.method_9228() instanceof class_3222 player) {
            // This will add the player to the economy if they don't exist yet
            CurrencyMod.getEconomyManager().getBalance(player.method_5667());
        }
        
        // Get all player balances
        Map<UUID, Double> allBalances = CurrencyMod.getEconomyManager().getAllBalances();
        
        // Check if there are any balances
        if (allBalances.isEmpty()) {
            source.method_9226(() -> class_2561.method_43470("No player balances found. The economy system may not be properly initialized.").method_27692(class_124.field_1061), false);
            return 0;
        }
        
        // Sort the balances in descending order and take the top 10
        List<Map.Entry<UUID, Double>> topPlayers = allBalances.entrySet().stream()
            .sorted(Map.Entry.<UUID, Double>comparingByValue().reversed())
            .limit(10)
            .collect(Collectors.toList());
        
        // Send header message
        int playerCount = topPlayers.size();
        source.method_9226(() -> class_2561.method_43470("Top " + playerCount + " Richest Players:").method_27695(class_124.field_1065, class_124.field_1067), false);
        
        // Send each player's rank and balance
        int rank = 1;
        for (Map.Entry<UUID, Double> entry : topPlayers) {
            UUID playerUuid = entry.getKey();
            double balance = entry.getValue();
            
            // Format the balance
            String formattedBalance = formatBalance(balance);
            
            // Try to get the player's name from the server
            String playerName = getPlayerNameFromUuid(source, playerUuid);
            
            // Create final copies for use in lambda
            final int currentRank = rank;
            final class_124 rankColor = getRankColor(currentRank);
            
            // Format and send the message
            source.method_9226(() -> class_2561.method_43470("#" + currentRank + " ")
                .method_27692(rankColor)
                .method_10852(class_2561.method_43470(playerName)
                    .method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470(": $" + formattedBalance)
                    .method_27692(class_124.field_1054)), false);
            
            rank++;
        }
        
        return 1;
    }
    
    /**
     * Get a player's name from their UUID.
     * If the player is offline, try to find their name in the user cache.
     */
    private static String getPlayerNameFromUuid(class_2168 source, UUID playerUuid) {
        // Try to find the player on the server
        class_3222 player = source.method_9211().method_3760().method_14602(playerUuid);
        if (player != null) {
            return player.method_5477().getString();
        }
        
        // If player is offline, try to get their name from the user cache
        var userCache = source.method_9211().method_3793();
        if (userCache != null) {
            Optional<GameProfile> profileOpt = userCache.method_14512(playerUuid);
            if (profileOpt.isPresent()) {
                GameProfile profile = profileOpt.get();
                return profile.getName();
            }
        }
        
        // If we can't find the name, use a shortened UUID
        return shortenUuid(playerUuid);
    }
    
    /**
     * Shorten a UUID for display purposes
     */
    private static String shortenUuid(UUID uuid) {
        String uuidString = uuid.toString();
        return uuidString.substring(0, 8) + "...";
    }
    
    /**
     * Get the color for a specific rank
     */
    private static class_124 getRankColor(int rank) {
        return switch (rank) {
            case 1 -> class_124.field_1065;
            case 2 -> class_124.field_1080;
            case 3 -> class_124.field_1079;
            default -> class_124.field_1060;
        };
    }
    
    /**
     * Format a balance to show only 2 decimal places if there are decimals
     */
    private static String formatBalance(double balance) {
        return balance == Math.floor(balance) 
            ? String.format("%.0f", balance) 
            : String.format("%.2f", balance);
    }
} 