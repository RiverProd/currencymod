package net.currencymod.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.currencymod.CurrencyMod;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2191;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_7157;
import com.mojang.authlib.GameProfile;

import java.util.Collection;
import java.util.UUID;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

/**
 * Commands for administrators to modify player balances
 */
public class AdminMoneyCommand {

    /**
     * Register both adminpay and adminfine commands
     */
    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 registryAccess, class_2170.class_5364 environment) {
        // Register adminpay command
        dispatcher.register(
            method_9247("adminpay")
                .requires(source -> source.method_9259(2)) // Require permission level 2 (admin/op)
                .then(method_9244("player", class_2191.method_9329()) // Use GameProfile to allow targeting offline players
                    .then(method_9244("amount", DoubleArgumentType.doubleArg(0.01))
                        .executes(context -> adminPay(context))
                    )
                )
        );

        // Register adminfine command
        dispatcher.register(
            method_9247("adminfine")
                .requires(source -> source.method_9259(2)) // Require permission level 2 (admin/op)
                .then(method_9244("player", class_2191.method_9329()) // Use GameProfile to allow targeting offline players
                    .then(method_9244("amount", DoubleArgumentType.doubleArg(0.01))
                        .executes(context -> adminFine(context))
                    )
                )
        );
    }

    /**
     * Handle the adminpay command - adds funds to a player's balance
     */
    private static int adminPay(CommandContext<class_2168> context) throws CommandSyntaxException {
        class_2168 source = context.getSource();
        
        // Get the target player profile
        Collection<GameProfile> profiles = class_2191.method_9330(context, "player");
        if (profiles.isEmpty()) {
            source.method_9213(class_2561.method_43470("Player not found"));
            return 0;
        }
        
        // Get the first profile (command should only target one player)
        GameProfile targetProfile = profiles.iterator().next();
        UUID targetUuid = targetProfile.getId();
        String targetName = targetProfile.getName();
        
        // Get the amount
        double amount = DoubleArgumentType.getDouble(context, "amount");
        
        // Format the amount for display
        String formattedAmount = formatAmount(amount);
        
        // Add money to the target player's balance
        CurrencyMod.getEconomyManager().addBalance(targetUuid, amount);
        
        // Notify the admin
        source.method_9226(() -> class_2561.method_43470("💰 Added ")
            .method_10852(class_2561.method_43470("$" + formattedAmount)
                .method_27695(class_124.field_1060, class_124.field_1067))
            .method_10852(class_2561.method_43470(" to " + targetName + "'s account.")), true);
        
        // Notify the target player if they're online
        class_3222 targetPlayer = source.method_9211().method_3760().method_14602(targetUuid);
        if (targetPlayer != null) {
            targetPlayer.method_43496(class_2561.method_43470("💰 You received ")
                .method_27692(class_124.field_1065)
                .method_10852(class_2561.method_43470("$" + formattedAmount)
                    .method_27695(class_124.field_1060, class_124.field_1067))
                .method_10852(class_2561.method_43470(" from an administrator.")));
        }
        
        return 1;
    }
    
    /**
     * Handle the adminfine command - removes funds from a player's balance
     */
    private static int adminFine(CommandContext<class_2168> context) throws CommandSyntaxException {
        class_2168 source = context.getSource();
        
        // Get the target player profile
        Collection<GameProfile> profiles = class_2191.method_9330(context, "player");
        if (profiles.isEmpty()) {
            source.method_9213(class_2561.method_43470("Player not found"));
            return 0;
        }
        
        // Get the first profile (command should only target one player)
        GameProfile targetProfile = profiles.iterator().next();
        UUID targetUuid = targetProfile.getId();
        String targetName = targetProfile.getName();
        
        // Get the amount
        double amount = DoubleArgumentType.getDouble(context, "amount");
        
        // Format the amount for display
        String formattedAmount = formatAmount(amount);
        
        // Remove money from the target player's balance
        // Note: We're not checking if they have enough since this is an admin command
        // and should work regardless of the player's current balance
        CurrencyMod.getEconomyManager().removeBalance(targetUuid, amount);
        
        // Notify the admin
        source.method_9226(() -> class_2561.method_43470("💰 Removed ")
            .method_10852(class_2561.method_43470("$" + formattedAmount)
                .method_27695(class_124.field_1061, class_124.field_1067))
            .method_10852(class_2561.method_43470(" from " + targetName + "'s account.")), true);
        
        // Notify the target player if they're online
        class_3222 targetPlayer = source.method_9211().method_3760().method_14602(targetUuid);
        if (targetPlayer != null) {
            targetPlayer.method_43496(class_2561.method_43470("💰 You have been fined ")
                .method_27692(class_124.field_1065)
                .method_10852(class_2561.method_43470("$" + formattedAmount)
                    .method_27695(class_124.field_1061, class_124.field_1067))
                .method_10852(class_2561.method_43470(" by an administrator.")));
        }
        
        return 1;
    }
    
    /**
     * Format a currency amount with proper decimal places
     */
    private static String formatAmount(double amount) {
        // Format with 2 decimal places if there are any cents, otherwise as a whole number
        return amount == Math.floor(amount) 
            ? String.format("%.0f", amount) 
            : String.format("%.2f", amount);
    }
} 