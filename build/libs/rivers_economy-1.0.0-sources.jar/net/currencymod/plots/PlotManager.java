package net.currencymod.plots;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import net.currencymod.CurrencyMod;
import net.currencymod.util.FileUtil;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import org.joml.Vector3f;
import net.minecraft.class_124;
import net.minecraft.class_2398;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2583;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5250;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/**
 * Manages player plot ownership, taxation, and the world-chunk plot registry.
 */
public class PlotManager {
    private static final Logger LOGGER = LoggerFactory.getLogger("CurrencyMod/PlotManager");
    private static final String PLOTS_FILE = "currency_mod/plots.json";
    private static PlotManager instance;

    // --- Ownership records (unchanged) ---
    private final Map<UUID, List<Plot>> playerPlots = new HashMap<>();
    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
    private ScheduledFuture<?> taxTask;

    // --- Tax tracking ---
    private long lastTaxDay = -1;
    private long lastCheckedTime = 0;
    private final Set<UUID> taxedPlayersToday = new HashSet<>();

    // --- Bulk-purchase confirmations (kept for op-level escape hatch) ---
    private static class PendingPurchase {
        final PlotType plotType;
        final int quantity;
        final int totalCost;
        final long timestamp;

        PendingPurchase(PlotType plotType, int quantity, int totalCost) {
            this.plotType = plotType;
            this.quantity = quantity;
            this.totalCost = totalCost;
            this.timestamp = System.currentTimeMillis();
        }
    }

    private final Map<UUID, PendingPurchase> pendingPurchases = new HashMap<>();
    private static final long PURCHASE_TIMEOUT = 60000;

    // --- World chunk registry (new) ---
    private final Map<ChunkKey, WorldPlot> registeredPlots = new HashMap<>();

    // --- Plot Vision ---
    private final Set<UUID> plotVisionEnabled = new HashSet<>();
    private int visionTickCounter = 0;

    // --- Multi-buy ---
    private final Set<UUID> multiBuyMode = new HashSet<>();
    private final Map<UUID, LinkedHashSet<ChunkKey>> selectedPlots = new HashMap<>();

    // =========================================================================
    // Singleton
    // =========================================================================

    public static PlotManager getInstance() {
        if (instance == null) instance = new PlotManager();
        return instance;
    }

    private PlotManager() {}

    // =========================================================================
    // Lifecycle
    // =========================================================================

    public void initialize(MinecraftServer server) {
        loadData(server);
        startTaxCollection(server);
        registerSleepWatcher();
        registerPlotVisionTick();
        LOGGER.info("PlotManager initialized. Last tax day: {}. Registered plots: {}",
                lastTaxDay, registeredPlots.size());
    }

    private void registerSleepWatcher() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            long currentTime = server.method_30002().method_8532();
            if (lastCheckedTime == 0) {
                lastCheckedTime = currentTime;
                return;
            }
            if (currentTime - lastCheckedTime > 100) {
                long currentDay = currentTime / 24000L;
                long previousDay = lastCheckedTime / 24000L;
                if (currentDay > previousDay && currentDay != lastTaxDay) {
                    LOGGER.info("Day change detected during time skip (sleep). Day {} → {}.",
                            previousDay, currentDay);
                    taxedPlayersToday.clear();
                    lastTaxDay = currentDay;
                    collectTaxesForOnlinePlayers(server, true);
                    saveData(server);
                }
            }
            lastCheckedTime = currentTime;
        });
        LOGGER.info("Registered sleep watcher for tax collection");
    }

    // =========================================================================
    // Plot Vision
    // =========================================================================

    /**
     * Toggles Plot Vision for a player. Returns the new state (true = enabled).
     */
    public boolean togglePlotVision(UUID playerUuid) {
        if (plotVisionEnabled.contains(playerUuid)) {
            plotVisionEnabled.remove(playerUuid);
            return false;
        } else {
            plotVisionEnabled.add(playerUuid);
            return true;
        }
    }

    /** Returns true if the player has Plot Vision active. */
    public boolean hasPlotVision(UUID playerUuid) {
        return plotVisionEnabled.contains(playerUuid);
    }

    /**
     * Registers a server-tick listener that spawns particles every second (20 ticks)
     * for every online player who has Plot Vision enabled.
     */
    private void registerPlotVisionTick() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            visionTickCounter++;
            if (visionTickCounter % 20 != 0) return;
            for (class_3222 player : server.method_3760().method_14571()) {
                if (plotVisionEnabled.contains(player.method_5667())) {
                    spawnPlotVisionParticles(player);
                }
            }
        });
        LOGGER.info("Registered Plot Vision particle tick");
    }

    /**
     * Spawns END_ROD particles for every available (unowned, registered) chunk within
     * a 5×5 chunk grid centred on the player:
     *   - A floating cluster 3 blocks above the chunk centre.
     *   - A 3-particle vertical line at each of the 4 chunk corners, just above the surface.
     *
     * Only considers chunks in the same dimension as the player.
     */
    private void spawnPlotVisionParticles(class_3222 player) {
        class_3218 world = player.method_51469();
        String dim = world.method_27983().method_29177().toString();
        int playerCX = player.method_24515().method_10263() >> 4;
        int playerCZ = player.method_24515().method_10260() >> 4;

        // Corner offsets within a chunk (0.5 = centre of the corner block)
        double[][] cornerOffsets = {
            {  0.5,  0.5 },   // NW
            { 15.5,  0.5 },   // NE
            {  0.5, 15.5 },   // SW
            { 15.5, 15.5 }    // SE
        };

        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                int cx = playerCX + dx;
                int cz = playerCZ + dz;
                ChunkKey key = new ChunkKey(cx, cz, dim);
                WorldPlot wp = registeredPlots.get(key);
                if (wp == null || !wp.isAvailable()) continue;

                boolean loaded = world.method_8393(cx, cz);
                double fallbackY = player.method_23318();

                // --- Centre glow (floating 3 blocks above surface) ---
                double centreX = cx * 16 + 8.5;
                double centreZ = cz * 16 + 8.5;
                double centreY = loaded
                        ? world.method_8624(class_2902.class_2903.field_13202, (int) centreX, (int) centreZ) + 3.0
                        : fallbackY + 3.0;

                world.method_14166(player, class_2398.field_11207, false,
                        centreX, centreY, centreZ, 4, 0.4, 0.15, 0.4, 0.02);

                // --- Corner lines (3 stacked particles per corner, just above surface) ---
                for (double[] offset : cornerOffsets) {
                    double cornerX = cx * 16 + offset[0];
                    double cornerZ = cz * 16 + offset[1];
                    double baseY = loaded
                            ? world.method_8624(class_2902.class_2903.field_13202, (int) cornerX, (int) cornerZ)
                            : fallbackY;

                    // Three evenly-spaced particles form a short vertical line
                    world.method_14166(player, class_2398.field_11207, false,
                            cornerX, baseY + 0.5, cornerZ, 1, 0, 0, 0, 0);
                }
            }
        }
    }

    // =========================================================================
    // Multi-buy
    // =========================================================================

    /**
     * Toggles multi-buy mode for a player. Clears any existing selections when turning off.
     * Returns the new state (true = enabled).
     */
    public boolean toggleMultiBuy(UUID playerUuid) {
        if (multiBuyMode.contains(playerUuid)) {
            multiBuyMode.remove(playerUuid);
            selectedPlots.remove(playerUuid);
            return false;
        } else {
            multiBuyMode.add(playerUuid);
            selectedPlots.put(playerUuid, new LinkedHashSet<>());
            return true;
        }
    }

    public boolean isMultiBuyMode(UUID playerUuid) {
        return multiBuyMode.contains(playerUuid);
    }

    public Set<ChunkKey> getSelectedPlots(UUID playerUuid) {
        Set<ChunkKey> sel = selectedPlots.get(playerUuid);
        return sel != null ? Collections.unmodifiableSet(sel) : Collections.emptySet();
    }

    public int getSelectionCount(UUID playerUuid) {
        Set<ChunkKey> sel = selectedPlots.get(playerUuid);
        return sel != null ? sel.size() : 0;
    }

    /**
     * Toggles a chunk in/out of the player's selection.
     * Returns the new selection count, or -1 if the cap of 16 has been reached
     * and the chunk was not already selected.
     */
    public int togglePlotSelection(UUID playerUuid, ChunkKey key) {
        LinkedHashSet<ChunkKey> sel =
                selectedPlots.computeIfAbsent(playerUuid, k -> new LinkedHashSet<>());
        if (sel.contains(key)) {
            sel.remove(key);
        } else {
            if (sel.size() >= 16) return -1;
            sel.add(key);
        }
        return sel.size();
    }

    /**
     * Purchases all plots in plotKeys as the given type, applying the bulk discount.
     * Validates availability and shared type support before deducting any currency.
     * Clears the player's multi-buy state on success.
     */
    public boolean buyMultiWorldPlots(class_3222 player, Set<ChunkKey> plotKeys, PlotType type) {
        List<WorldPlot> plots = new ArrayList<>();
        for (ChunkKey key : plotKeys) {
            WorldPlot wp = registeredPlots.get(key);
            if (wp == null || !wp.isAvailable() || !wp.getEnabledTypes().contains(type)) {
                player.method_43496(class_2561.method_43470(
                        "One or more selected plots are no longer available or don't support that type.")
                        .method_27692(class_124.field_1061));
                return false;
            }
            plots.add(wp);
        }

        int quantity = plots.size();
        if (quantity == 0) return false;

        int basePrice = type.getPurchasePrice();
        int totalCost = calculateBulkPurchaseCost(basePrice, quantity);
        UUID playerUuid = player.method_5667();

        if (CurrencyMod.getEconomyManager().getBalance(playerUuid) < totalCost) {
            player.method_43496(class_2561.method_43470("Insufficient funds. Total cost for " + quantity + " plots: ")
                    .method_10852(class_2561.method_43470("$" + totalCost).method_27692(class_124.field_1061)));
            return false;
        }

        CurrencyMod.getEconomyManager().removeBalance(playerUuid, totalCost);
        for (WorldPlot wp : plots) {
            Plot plot = new Plot(type);
            playerPlots.computeIfAbsent(playerUuid, k -> new ArrayList<>()).add(plot);
            wp.setOwnerUuid(playerUuid);
            wp.setPlotId(plot.getId());
        }

        // Clear multi-buy state after a successful bulk purchase
        selectedPlots.remove(playerUuid);
        multiBuyMode.remove(playerUuid);

        saveData(CurrencyMod.getServer());

        int totalTax = quantity * type.getDailyTax();
        player.method_43496(class_2561.method_43470("✅ Purchased ")
                .method_10852(class_2561.method_43470(quantity + "x ").method_27695(class_124.field_1060, class_124.field_1067))
                .method_10852(class_2561.method_43470(type.getDisplayName()).method_27695(class_124.field_1060, class_124.field_1067))
                .method_10852(class_2561.method_43470(" plots for "))
                .method_10852(class_2561.method_43470("$" + totalCost).method_27692(class_124.field_1065))
                .method_10852(class_2561.method_43470(" (bulk discount applied). Daily tax: "))
                .method_10852(class_2561.method_43470("$" + totalTax + "/day").method_27692(class_124.field_1054)));
        LOGGER.info("Player {} purchased {}x {} plots via multi-buy for ${}",
                player.method_5477().getString(), quantity, type.getDisplayName(), totalCost);
        return true;
    }

    public void checkPlayerTaxStatus(class_3222 player) {
        UUID playerUuid = player.method_5667();
        long currentDay = player.method_5682().method_30002().method_8532() / 24000L;
        if (currentDay == lastTaxDay && !taxedPlayersToday.contains(playerUuid)) {
            if (playerHasPlots(playerUuid)) {
                collectTaxFromPlayer(player);
                taxedPlayersToday.add(playerUuid);
                saveData(player.method_5682());
                LOGGER.info("Collected tax on join from {} (day {})",
                        player.method_5477().getString(), currentDay);
            }
        }
    }

    private boolean playerHasPlots(UUID playerUuid) {
        return playerPlots.containsKey(playerUuid) && !playerPlots.get(playerUuid).isEmpty();
    }

    public void shutdown(MinecraftServer server) {
        saveData(server);
        if (taxTask != null && !taxTask.isDone()) taxTask.cancel(false);
        if (scheduler != null) scheduler.shutdown();
        LOGGER.info("PlotManager shutdown complete");
    }

    private void startTaxCollection(MinecraftServer server) {
        taxTask = scheduler.scheduleAtFixedRate(() -> checkForNewDay(server), 1, 1, TimeUnit.MINUTES);
        LOGGER.info("Scheduled tax collection task started");
    }

    private void checkForNewDay(MinecraftServer server) {
        if (server == null) return;
        long currentDay = server.method_30002().method_8532() / 24000L;
        if (currentDay != lastTaxDay) {
            LOGGER.info("New Minecraft day: {}. Previous tax day: {}", currentDay, lastTaxDay);
            taxedPlayersToday.clear();
            lastTaxDay = currentDay;
            collectTaxesForOnlinePlayers(server, false);
            saveData(server);
        }
    }

    private void collectTaxesForOnlinePlayers(MinecraftServer server, boolean wasSleeping) {
        for (class_3222 player : server.method_3760().method_14571()) {
            UUID playerUuid = player.method_5667();
            if (taxedPlayersToday.contains(playerUuid)) continue;
            if (!playerHasPlots(playerUuid)) continue;
            collectTaxFromPlayer(player);
            taxedPlayersToday.add(playerUuid);
            if (wasSleeping) {
                player.method_43496(class_2561.method_43470("Taxes are collected at dawn, even when you sleep through the night!")
                        .method_27695(class_124.field_1080, class_124.field_1056));
            }
        }
    }

    private boolean collectTaxFromPlayer(class_3222 player) {
        UUID playerUuid = player.method_5667();
        List<Plot> plots = playerPlots.get(playerUuid);
        int totalTax = calculateTotalTax(plots);

        if (totalTax < 0) {
            int subsidy = -totalTax;
            CurrencyMod.getEconomyManager().addBalance(playerUuid, subsidy);
            player.method_43496(class_2561.method_43470("💵 Daily plot payment of ")
                    .method_10852(class_2561.method_43470("$" + subsidy).method_27692(class_124.field_1060))
                    .method_10852(class_2561.method_43470(" has been paid to you for your plots.").method_27692(class_124.field_1068)));
            LOGGER.info("Paid ${} daily plot payment to {}", subsidy, player.method_5477().getString());
            return true;
        } else if (totalTax == 0) {
            return true;
        }

        double playerBalance = CurrencyMod.getEconomyManager().getBalance(playerUuid);
        if (playerBalance >= totalTax) {
            CurrencyMod.getEconomyManager().removeBalance(playerUuid, totalTax);
            player.method_43496(class_2561.method_43470("💰 Daily plot tax of ")
                    .method_10852(class_2561.method_43470("$" + totalTax).method_27692(class_124.field_1065))
                    .method_10852(class_2561.method_43470(" has been collected for your plots.").method_27692(class_124.field_1068)));
            LOGGER.info("Collected ${} in taxes from {}", totalTax, player.method_5477().getString());
            return true;
        } else {
            player.method_43496(class_2561.method_43470("⚠️ WARNING: You do not have enough money to pay your property tax of ")
                    .method_10852(class_2561.method_43470("$" + totalTax).method_27692(class_124.field_1061))
                    .method_10852(class_2561.method_43470(". Your plots may be repossessed soon!").method_27692(class_124.field_1061)));
            LOGGER.warn("Player {} has insufficient funds for tax payment of ${}",
                    player.method_5477().getString(), totalTax);
            return false;
        }
    }

    public int collectManualTax(MinecraftServer server) {
        if (server == null) { LOGGER.warn("Cannot collect tax: server is null"); return 0; }
        taxedPlayersToday.clear();
        int count = 0;
        for (class_3222 player : server.method_3760().method_14571()) {
            if (!playerHasPlots(player.method_5667())) continue;
            if (collectTaxFromPlayer(player)) {
                count++;
                taxedPlayersToday.add(player.method_5667());
            }
        }
        saveData(server);
        return count;
    }

    // =========================================================================
    // World chunk registry — admin operations
    // =========================================================================

    /**
     * Returns the WorldPlot for the chunk the player is standing in, or null.
     */
    public WorldPlot getWorldPlotAt(class_3222 player) {
        return registeredPlots.get(ChunkKey.fromPlayer(player));
    }

    /**
     * Returns the WorldPlot for an explicit key, or null.
     */
    public WorldPlot getWorldPlot(ChunkKey key) {
        return registeredPlots.get(key);
    }

    /**
     * Returns an unmodifiable view of all registered plots.
     */
    public Map<ChunkKey, WorldPlot> getRegisteredPlots() {
        return Collections.unmodifiableMap(registeredPlots);
    }

    /**
     * Registers a chunk as a buyable plot. Does nothing if already registered.
     */
    public void registerPlot(ChunkKey key, Set<PlotType> enabledTypes) {
        if (registeredPlots.containsKey(key)) return;
        registeredPlots.put(key, new WorldPlot(key, enabledTypes));
        saveData(CurrencyMod.getServer());
        LOGGER.info("Registered plot at {}", key);
    }

    /**
     * Removes a chunk from the registry. Returns false if it is currently owned.
     */
    public boolean unregisterPlot(ChunkKey key) {
        WorldPlot wp = registeredPlots.get(key);
        if (wp == null) return false;
        if (wp.isOwned()) return false;
        registeredPlots.remove(key);
        saveData(CurrencyMod.getServer());
        LOGGER.info("Unregistered plot at {}", key);
        return true;
    }

    /**
     * Updates the enabled types for an already-registered plot (admin edit).
     */
    public void updateEnabledTypes(ChunkKey key, Set<PlotType> enabledTypes) {
        WorldPlot wp = registeredPlots.get(key);
        if (wp != null) {
            wp.setEnabledTypes(enabledTypes);
            saveData(CurrencyMod.getServer());
        }
    }

    /**
     * Admin grant: assigns an unowned registered chunk to an online player as a specific type.
     * Does not require the type to be in the chunk's enabledTypes — admin grants bypass that.
     * Returns false if the chunk is already owned.
     */
    public boolean grantPlot(class_3222 target, WorldPlot worldPlot, PlotType type) {
        if (worldPlot.isOwned()) return false;
        UUID targetUuid = target.method_5667();

        Plot plot = new Plot(type);
        playerPlots.computeIfAbsent(targetUuid, k -> new ArrayList<>()).add(plot);
        worldPlot.setOwnerUuid(targetUuid);
        worldPlot.setPlotId(plot.getId());
        saveData(CurrencyMod.getServer());

        LOGGER.info("Admin granted {} plot at {} to {}",
                type.getDisplayName(), worldPlot.getLocation(), target.method_5477().getString());
        return true;
    }

    /**
     * Admin delete: removes all data for a registered chunk — unlinks ownership records,
     * removes the player's Plot entry, and deletes the WorldPlot from the registry.
     * Works regardless of whether the chunk is owned.
     */
    public void deletePlot(ChunkKey key) {
        WorldPlot wp = registeredPlots.get(key);
        if (wp == null) return;

        if (wp.isOwned() && wp.getPlotId() != null) {
            List<Plot> plots = playerPlots.get(wp.getOwnerUuid());
            if (plots != null) {
                plots.removeIf(p -> p.getId().equals(wp.getPlotId()));
                if (plots.isEmpty()) playerPlots.remove(wp.getOwnerUuid());
            }
        }

        registeredPlots.remove(key);
        saveData(CurrencyMod.getServer());
        LOGGER.info("Admin deleted plot at {}", key);
    }

    // =========================================================================
    // Chunk-aware purchase
    // =========================================================================

    /**
     * Purchases the given WorldPlot as the specified type.
     * Validates availability, type enabled, and balance.
     * Creates the Plot record, links it to the WorldPlot, and saves.
     */
    public boolean buyWorldPlot(class_3222 player, WorldPlot worldPlot, PlotType type) {
        if (!worldPlot.isAvailable()) {
            player.method_43496(class_2561.method_43470("This plot is not available for purchase.").method_27692(class_124.field_1061));
            return false;
        }
        if (!worldPlot.getEnabledTypes().contains(type)) {
            player.method_43496(class_2561.method_43470("That plot type is not available at this location.").method_27692(class_124.field_1061));
            return false;
        }
        int price = type.getPurchasePrice();
        UUID playerUuid = player.method_5667();
        if (CurrencyMod.getEconomyManager().getBalance(playerUuid) < price) {
            player.method_43496(class_2561.method_43470("You cannot afford this plot.")
                    .method_10852(class_2561.method_43470(" Cost: $" + price).method_27692(class_124.field_1061)));
            return false;
        }

        // Deduct currency, create plot record, link WorldPlot
        CurrencyMod.getEconomyManager().removeBalance(playerUuid, price);
        Plot plot = new Plot(type);
        playerPlots.computeIfAbsent(playerUuid, k -> new ArrayList<>()).add(plot);
        worldPlot.setOwnerUuid(playerUuid);
        worldPlot.setPlotId(plot.getId());
        saveData(CurrencyMod.getServer());

        player.method_43496(class_2561.method_43470("You purchased a ")
                .method_10852(class_2561.method_43470(type.getDisplayName()).method_27695(class_124.field_1060, class_124.field_1067))
                .method_10852(class_2561.method_43470(" plot for "))
                .method_10852(class_2561.method_43470("$" + price).method_27692(class_124.field_1065))
                .method_10852(class_2561.method_43470(". Daily tax: "))
                .method_10852(class_2561.method_43470("$" + type.getDailyTax() + "/day").method_27692(class_124.field_1054)));
        LOGGER.info("Player {} purchased {} plot at {}", player.method_5477().getString(),
                type.getDisplayName(), worldPlot.getLocation());
        return true;
    }

    /**
     * Sells the WorldPlot owned by the player, refunding 20% of the original price.
     * Unlinks the WorldPlot and removes the Plot record.
     */
    public boolean sellWorldPlot(class_3222 player, WorldPlot worldPlot) {
        UUID playerUuid = player.method_5667();
        if (!worldPlot.isOwned() || !playerUuid.equals(worldPlot.getOwnerUuid())) {
            player.method_43496(class_2561.method_43470("You don't own this plot.").method_27692(class_124.field_1061));
            return false;
        }
        UUID plotId = worldPlot.getPlotId();
        List<Plot> plots = playerPlots.get(playerUuid);
        if (plots == null) {
            player.method_43496(class_2561.method_43470("Error: plot ownership data not found.").method_27692(class_124.field_1061));
            return false;
        }
        Optional<Plot> plotOpt = plots.stream().filter(p -> p.getId().equals(plotId)).findFirst();
        if (plotOpt.isEmpty()) {
            player.method_43496(class_2561.method_43470("Error: plot record not found.").method_27692(class_124.field_1061));
            return false;
        }
        Plot plot = plotOpt.get();
        PlotType plotType = plot.getType();
        int refundAmount = (int)(plotType.getPurchasePrice() * 0.2);

        CurrencyMod.getEconomyManager().addBalance(playerUuid, refundAmount);
        plots.remove(plot);
        if (plots.isEmpty()) playerPlots.remove(playerUuid);
        worldPlot.setOwnerUuid(null);
        worldPlot.setPlotId(null);
        saveData(CurrencyMod.getServer());

        player.method_43496(class_2561.method_43470("You sold your ")
                .method_10852(class_2561.method_43470(plotType.getDisplayName()).method_27695(class_124.field_1061, class_124.field_1067))
                .method_10852(class_2561.method_43470(" plot for "))
                .method_10852(class_2561.method_43470("$" + refundAmount).method_27692(class_124.field_1065))
                .method_10852(class_2561.method_43470(" (20% of original price).").method_27692(class_124.field_1080)));
        LOGGER.info("Player {} sold {} plot at {}", player.method_5477().getString(),
                plotType.getDisplayName(), worldPlot.getLocation());
        return true;
    }

    // =========================================================================
    // Legacy command-based purchase (kept for op-level escape hatch)
    // =========================================================================

    public boolean buyPlot(class_3222 player, PlotType plotType) {
        return buyPlots(player, plotType, 1);
    }

    public boolean buyPlots(class_3222 player, PlotType plotType, int quantity) {
        if (quantity < 1) {
            player.method_43496(class_2561.method_43470("Quantity must be at least 1").method_27692(class_124.field_1061));
            return false;
        }
        UUID playerUuid = player.method_5667();
        int basePrice = plotType.getPurchasePrice();
        int totalCost = calculateBulkPurchaseCost(basePrice, quantity);

        if (CurrencyMod.getEconomyManager().getBalance(playerUuid) < totalCost) {
            player.method_43496(class_2561.method_43470("You don't have enough money. Total cost: ")
                    .method_10852(class_2561.method_43470("$" + totalCost).method_27692(class_124.field_1061)));
            return false;
        }
        if (quantity == 1) return processPurchase(player, plotType, quantity, totalCost);
        showPurchaseConfirmation(player, plotType, quantity, totalCost, basePrice);
        return true;
    }

    private void showPurchaseConfirmation(class_3222 player, PlotType plotType,
                                          int quantity, int totalCost, int basePrice) {
        UUID playerUuid = player.method_5667();
        pendingPurchases.put(playerUuid, new PendingPurchase(plotType, quantity, totalCost));

        class_5250 header = class_2561.method_43470("🏞️ ")
                .method_10852(class_2561.method_43470("Plot Purchase Confirmation").method_27695(class_124.field_1065, class_124.field_1067));
        class_5250 details = class_2561.method_43470("\nYou are about to purchase:").method_27692(class_124.field_1068)
                .method_10852(class_2561.method_43470("\n  • ").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470(String.valueOf(quantity)).method_27695(class_124.field_1060, class_124.field_1067))
                .method_10852(class_2561.method_43470("x " + plotType.getDisplayName()).method_27695(class_124.field_1065, class_124.field_1067))
                .method_10852(class_2561.method_43470(" plots").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470("\n  • Daily tax: ").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470("$" + (quantity * plotType.getDailyTax())).method_27692(class_124.field_1054));

        class_5250 breakdown = class_2561.method_43470("\n\nPrice breakdown:").method_27692(class_124.field_1068);
        for (int i = 0; i < quantity; i++) {
            int plotPrice = calculatePlotPriceWithDiscount(basePrice, i);
            int discountPercent = Math.min(50, i * 5);
            if (i == 0) {
                breakdown.method_10852(class_2561.method_43470("\n  Plot 1: $").method_27692(class_124.field_1068)
                        .method_10852(class_2561.method_43470(String.valueOf(plotPrice)).method_27692(class_124.field_1065))
                        .method_10852(class_2561.method_43470(" (full price)").method_27692(class_124.field_1080)));
            } else {
                breakdown.method_10852(class_2561.method_43470("\n  Plot " + (i + 1) + ": $").method_27692(class_124.field_1068)
                        .method_10852(class_2561.method_43470(String.valueOf(plotPrice)).method_27692(class_124.field_1065))
                        .method_10852(class_2561.method_43470(" (" + discountPercent + "% off)").method_27692(class_124.field_1060)));
            }
        }

        class_5250 totalSummary = class_2561.method_43470("\n\nTotal cost: ")
                .method_10852(class_2561.method_43470("$" + totalCost).method_27695(class_124.field_1060, class_124.field_1067));
        class_5250 confirmButton = class_2561.method_43470("[Confirm Purchase]")
                .method_10862(class_2583.field_24360.method_10977(class_124.field_1060).method_10982(true)
                        .method_10958(new class_2558(class_2558.class_2559.field_11750, "/plots confirm"))
                        .method_10949(new class_2568(class_2568.class_5247.field_24342,
                                class_2561.method_43470("Click to confirm"))));
        class_5250 cancelButton = class_2561.method_43470("[Cancel]")
                .method_10862(class_2583.field_24360.method_10977(class_124.field_1061).method_10982(true)
                        .method_10958(new class_2558(class_2558.class_2559.field_11750, "/plots cancel"))
                        .method_10949(new class_2568(class_2568.class_5247.field_24342,
                                class_2561.method_43470("Click to cancel"))));

        player.method_43496(header.method_10852(details).method_10852(breakdown).method_10852(totalSummary)
                .method_10852(class_2561.method_43470("\n")).method_10852(confirmButton)
                .method_10852(class_2561.method_43470(" ")).method_10852(cancelButton));
    }

    private boolean processPurchase(class_3222 player, PlotType plotType, int quantity, int totalCost) {
        UUID playerUuid = player.method_5667();
        if (CurrencyMod.getEconomyManager().getBalance(playerUuid) < totalCost) {
            player.method_43496(class_2561.method_43470("You don't have enough money to complete this purchase.")
                    .method_27692(class_124.field_1061));
            pendingPurchases.remove(playerUuid);
            return false;
        }
        int basePrice = plotType.getPurchasePrice();
        CurrencyMod.getEconomyManager().removeBalance(playerUuid, totalCost);
        for (int i = 0; i < quantity; i++) {
            playerPlots.computeIfAbsent(playerUuid, k -> new ArrayList<>()).add(new Plot(plotType));
        }
        saveData(CurrencyMod.getServer());

        if (quantity == 1) {
            player.method_43496(class_2561.method_43470("You have purchased a ")
                    .method_10852(class_2561.method_43470(plotType.getDisplayName()).method_27695(class_124.field_1060, class_124.field_1067))
                    .method_10852(class_2561.method_43470(" plot for "))
                    .method_10852(class_2561.method_43470("$" + totalCost).method_27692(class_124.field_1065))
                    .method_10852(class_2561.method_43470("\nDaily tax: "))
                    .method_10852(class_2561.method_43470("$" + plotType.getDailyTax()).method_27692(class_124.field_1054)));
        } else {
            class_5250 message = class_2561.method_43470("✅ Purchase confirmed! ")
                    .method_10852(class_2561.method_43470(quantity + "x ").method_27695(class_124.field_1060, class_124.field_1067))
                    .method_10852(class_2561.method_43470(plotType.getDisplayName()).method_27695(class_124.field_1060, class_124.field_1067))
                    .method_10852(class_2561.method_43470(" plots for "))
                    .method_10852(class_2561.method_43470("$" + totalCost).method_27692(class_124.field_1065))
                    .method_10852(class_2561.method_43470(" (bulk discount applied)"));
            message.method_10852(class_2561.method_43470("\nBreakdown:").method_27692(class_124.field_1068));
            for (int i = 0; i < quantity; i++) {
                int plotPrice = calculatePlotPriceWithDiscount(basePrice, i);
                int discountPercent = Math.min(50, i * 5);
                if (i == 0) {
                    message.method_10852(class_2561.method_43470("\n  Plot 1: $" + plotPrice + " (full price)").method_27692(class_124.field_1068));
                } else {
                    message.method_10852(class_2561.method_43470("\n  Plot " + (i + 1) + ": $" + plotPrice
                            + " (" + discountPercent + "% off)").method_27692(class_124.field_1068));
                }
            }
            message.method_10852(class_2561.method_43470("\nTotal daily tax: "))
                    .method_10852(class_2561.method_43470("$" + (quantity * plotType.getDailyTax())).method_27692(class_124.field_1054));
            player.method_43496(message);
        }
        return true;
    }

    public boolean confirmPurchase(class_3222 player) {
        UUID playerUuid = player.method_5667();
        PendingPurchase pending = pendingPurchases.get(playerUuid);
        if (pending == null) {
            player.method_43496(class_2561.method_43470("No pending plot purchase to confirm.").method_27692(class_124.field_1061));
            return false;
        }
        if (System.currentTimeMillis() - pending.timestamp > PURCHASE_TIMEOUT) {
            pendingPurchases.remove(playerUuid);
            player.method_43496(class_2561.method_43470("Purchase confirmation expired. Please try again.").method_27692(class_124.field_1061));
            return false;
        }
        pendingPurchases.remove(playerUuid);
        return processPurchase(player, pending.plotType, pending.quantity, pending.totalCost);
    }

    public boolean cancelPurchase(class_3222 player) {
        UUID playerUuid = player.method_5667();
        PendingPurchase pending = pendingPurchases.remove(playerUuid);
        if (pending == null) {
            player.method_43496(class_2561.method_43470("No pending plot purchase to cancel.").method_27692(class_124.field_1061));
            return false;
        }
        player.method_43496(class_2561.method_43470("Purchase cancelled.").method_27692(class_124.field_1054));
        return true;
    }

    /**
     * Legacy command-based sell. Also clears any WorldPlot binding for the removed plot.
     */
    public boolean sellPlot(class_3222 player, PlotType plotType) {
        UUID playerUuid = player.method_5667();
        if (!playerPlots.containsKey(playerUuid) || playerPlots.get(playerUuid).isEmpty()) {
            player.method_43496(class_2561.method_43470("You don't own any plots to sell.").method_27692(class_124.field_1061));
            return false;
        }
        List<Plot> plots = playerPlots.get(playerUuid);
        Optional<Plot> plotOpt = plots.stream().filter(p -> p.getType() == plotType).findFirst();
        if (plotOpt.isEmpty()) {
            player.method_43496(class_2561.method_43470("You don't own any ")
                    .method_10852(class_2561.method_43470(plotType.getDisplayName()).method_27692(class_124.field_1065))
                    .method_10852(class_2561.method_43470(" plots to sell.").method_27692(class_124.field_1061)));
            return false;
        }
        Plot plotToSell = plotOpt.get();
        int refundAmount = (int)(plotType.getPurchasePrice() * 0.2);
        CurrencyMod.getEconomyManager().addBalance(playerUuid, refundAmount);
        plots.remove(plotToSell);
        if (plots.isEmpty()) playerPlots.remove(playerUuid);

        // Clear WorldPlot binding if one exists for this specific plot
        for (WorldPlot wp : registeredPlots.values()) {
            if (plotToSell.getId().equals(wp.getPlotId())) {
                wp.setOwnerUuid(null);
                wp.setPlotId(null);
                break;
            }
        }
        saveData(CurrencyMod.getServer());

        player.method_43496(class_2561.method_43470("You have sold your ")
                .method_10852(class_2561.method_43470(plotType.getDisplayName()).method_27695(class_124.field_1061, class_124.field_1067))
                .method_10852(class_2561.method_43470(" plot for "))
                .method_10852(class_2561.method_43470("$" + refundAmount).method_27692(class_124.field_1065))
                .method_10852(class_2561.method_43470(" (20% of original price).").method_27692(class_124.field_1080)));
        return true;
    }

    // =========================================================================
    // Read-only queries
    // =========================================================================

    public List<Plot> getPlayerPlots(UUID playerUuid) {
        return playerPlots.getOrDefault(playerUuid, Collections.emptyList());
    }

    public Map<PlotType, Integer> getPlayerPlotCounts(UUID playerUuid) {
        List<Plot> plots = getPlayerPlots(playerUuid);
        Map<PlotType, Integer> counts = new EnumMap<>(PlotType.class);
        for (PlotType type : PlotType.values()) counts.put(type, 0);
        for (Plot plot : plots) counts.merge(plot.getType(), 1, Integer::sum);
        return counts;
    }

    public int getPlayerDailyTax(UUID playerUuid) {
        return calculateTotalTax(getPlayerPlots(playerUuid));
    }

    // =========================================================================
    // Math helpers
    // =========================================================================

    private int calculateTotalTax(List<Plot> plots) {
        return plots.stream().mapToInt(Plot::getDailyTax).sum();
    }

    private int calculatePlotPriceWithDiscount(int basePrice, int plotIndex) {
        if (plotIndex == 0) return basePrice;
        int discountPercent = Math.min(50, plotIndex * 5);
        double multiplier = 1.0 - (discountPercent / 100.0);
        return (int) Math.round(basePrice * multiplier);
    }

    public int calculateBulkPurchaseCost(int basePrice, int quantity) {
        int total = 0;
        for (int i = 0; i < quantity; i++) total += calculatePlotPriceWithDiscount(basePrice, i);
        return total;
    }

    // =========================================================================
    // Persistence
    // =========================================================================

    public void loadData(MinecraftServer server) {
        if (server == null) { LOGGER.warn("Cannot load plot data: server is null"); return; }
        File file = server.method_3831().resolve(PLOTS_FILE).toFile();
        if (!file.exists()) { LOGGER.info("Plots file not found; starting fresh."); return; }

        try (FileReader reader = new FileReader(file)) {
            JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();

            if (root.has("lastTaxDay"))
                lastTaxDay = root.get("lastTaxDay").getAsLong();

            if (root.has("taxedPlayers")) {
                taxedPlayersToday.clear();
                for (JsonElement e : root.getAsJsonArray("taxedPlayers"))
                    taxedPlayersToday.add(UUID.fromString(e.getAsString()));
            }

            if (root.has("playerPlots")) {
                JsonObject plotsObj = root.getAsJsonObject("playerPlots");
                for (Map.Entry<String, JsonElement> entry : plotsObj.entrySet()) {
                    UUID playerUuid = UUID.fromString(entry.getKey());
                    List<Plot> plots = new ArrayList<>();
                    for (JsonElement elem : entry.getValue().getAsJsonArray()) {
                        JsonObject plotObj = elem.getAsJsonObject();
                        UUID plotId = UUID.fromString(plotObj.get("id").getAsString());
                        PlotType type = PlotType.valueOf(plotObj.get("type").getAsString());
                        long timestamp = plotObj.get("timestamp").getAsLong();
                        plots.add(new Plot(plotId, type, timestamp));
                    }
                    playerPlots.put(playerUuid, plots);
                }
            }

            if (root.has("registeredPlots")) {
                JsonObject regObj = root.getAsJsonObject("registeredPlots");
                for (Map.Entry<String, JsonElement> entry : regObj.entrySet()) {
                    ChunkKey key = ChunkKey.fromString(entry.getKey());
                    if (key == null) continue;
                    JsonObject wpObj = entry.getValue().getAsJsonObject();

                    Set<PlotType> enabledTypes = EnumSet.noneOf(PlotType.class);
                    if (wpObj.has("enabledTypes")) {
                        for (JsonElement e : wpObj.getAsJsonArray("enabledTypes")) {
                            try { enabledTypes.add(PlotType.valueOf(e.getAsString())); }
                            catch (IllegalArgumentException ignored) {}
                        }
                    }

                    UUID ownerUuid = (wpObj.has("ownerUuid") && !wpObj.get("ownerUuid").isJsonNull())
                            ? UUID.fromString(wpObj.get("ownerUuid").getAsString()) : null;
                    UUID plotId = (wpObj.has("plotId") && !wpObj.get("plotId").isJsonNull())
                            ? UUID.fromString(wpObj.get("plotId").getAsString()) : null;

                    registeredPlots.put(key, new WorldPlot(key, enabledTypes, ownerUuid, plotId));
                }
            }

            LOGGER.info("Loaded plot data: {} players, {} registered chunks, last tax day: {}",
                    playerPlots.size(), registeredPlots.size(), lastTaxDay);
        } catch (IOException e) {
            LOGGER.error("Failed to load plot data", e);
        } catch (Exception e) {
            LOGGER.error("Error parsing plot data", e);
        }
    }

    public void saveData(MinecraftServer server) {
        if (server == null) { LOGGER.warn("Cannot save plot data: server is null"); return; }
        File file = FileUtil.getServerFile(server, PLOTS_FILE);
        if (file == null) { LOGGER.error("Failed to get plot file path"); return; }

        try {
            JsonObject root = new JsonObject();

            root.addProperty("lastTaxDay", lastTaxDay);

            JsonArray taxedArr = new JsonArray();
            for (UUID uuid : taxedPlayersToday) taxedArr.add(uuid.toString());
            root.add("taxedPlayers", taxedArr);

            JsonObject plotsObj = new JsonObject();
            for (Map.Entry<UUID, List<Plot>> entry : playerPlots.entrySet()) {
                JsonArray arr = new JsonArray();
                for (Plot plot : entry.getValue()) {
                    JsonObject p = new JsonObject();
                    p.addProperty("id", plot.getId().toString());
                    p.addProperty("type", plot.getType().name());
                    p.addProperty("timestamp", plot.getPurchaseTimestamp());
                    arr.add(p);
                }
                plotsObj.add(entry.getKey().toString(), arr);
            }
            root.add("playerPlots", plotsObj);

            JsonObject regObj = new JsonObject();
            for (Map.Entry<ChunkKey, WorldPlot> entry : registeredPlots.entrySet()) {
                WorldPlot wp = entry.getValue();
                JsonObject wpObj = new JsonObject();

                JsonArray enabledArr = new JsonArray();
                for (PlotType t : wp.getEnabledTypes()) enabledArr.add(t.name());
                wpObj.add("enabledTypes", enabledArr);

                wpObj.add("ownerUuid", wp.getOwnerUuid() != null
                        ? new com.google.gson.JsonPrimitive(wp.getOwnerUuid().toString()) : JsonNull.INSTANCE);
                wpObj.add("plotId", wp.getPlotId() != null
                        ? new com.google.gson.JsonPrimitive(wp.getPlotId().toString()) : JsonNull.INSTANCE);

                regObj.add(entry.getKey().toString(), wpObj);
            }
            root.add("registeredPlots", regObj);

            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            boolean ok = FileUtil.safeWriteToFile(server, file, gson.toJson(root));
            if (ok) {
                LOGGER.info("Saved plot data: {} players, {} registered chunks",
                        playerPlots.size(), registeredPlots.size());
            } else {
                LOGGER.error("FileUtil.safeWriteToFile returned failure");
            }
        } catch (Exception e) {
            LOGGER.error("Failed to save plot data", e);
        }
    }
}
