package net.currencymod.trade;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.currencymod.CurrencyMod;
import net.currencymod.economy.EconomyManager;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2583;
import net.minecraft.class_3222;
import net.minecraft.class_5250;
import net.minecraft.class_6880;
import net.minecraft.class_9304;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/**
 * Manages player-to-player trades
 */
public class TradeManager {
    private static final Logger LOGGER = LoggerFactory.getLogger("CurrencyMod/TradeManager");
    private static final TradeManager INSTANCE = new TradeManager();
    
    // Trade timeout in seconds
    private static final int TRADE_TIMEOUT = 60; // 1 minute
    
    // Reminder intervals in seconds
    private static final int[] REMINDER_INTERVALS = {30, 15, 5};
    
    // Map of active trade requests: target player UUID -> trade request
    private final Map<UUID, TradeRequest> activeTradeRequests = new HashMap<>();
    
    // Scheduler for trade timeouts
    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
    
    /**
     * Private constructor for singleton
     */
    private TradeManager() {
    }
    
    /**
     * Get the singleton instance
     */
    public static TradeManager getInstance() {
        return INSTANCE;
    }
    
    /**
     * Create a new trade request
     * @param sender The player sending the trade request
     * @param target The player receiving the trade request
     * @param item The item being offered
     * @param price The price being asked
     * @return true if request was created, false if a request already exists
     */
    public boolean createTradeRequest(class_3222 sender, class_3222 target, class_1799 item, double price) {
        // Check if target already has an active trade request
        if (activeTradeRequests.containsKey(target.method_5667())) {
            return false;
        }
        
        // Make a copy of the item before removing it from the inventory
        class_1799 tradedItem = item.method_7972();
        
        // Remove the item from the sender's hand immediately
        sender.method_6122(class_1268.field_5808, class_1799.field_8037);
        
        // Create a new trade request
        TradeRequest request = new TradeRequest(sender, target, tradedItem, price);
        activeTradeRequests.put(target.method_5667(), request);
        
        // Send trade request message to the target player
        sendTradeRequest(request);
        
        // Schedule request timeout
        ScheduledFuture<?> timeoutFuture = scheduler.schedule(
            () -> expireTradeRequest(request),
            TRADE_TIMEOUT,
            TimeUnit.SECONDS
        );
        request.setTimeoutFuture(timeoutFuture);
        
        // Schedule reminders
        scheduleReminders(request);
        
        LOGGER.info("Created trade request from {} to {}: {} for ${}", 
            sender.method_5477().getString(), target.method_5477().getString(), 
            tradedItem.method_7964().getString(), price);
        
        return true;
    }
    
    /**
     * Schedule reminders for the trade request
     */
    private void scheduleReminders(TradeRequest request) {
        for (int seconds : REMINDER_INTERVALS) {
            int delaySeconds = TRADE_TIMEOUT - seconds;
            
            if (delaySeconds > 0) {
                scheduler.schedule(
                    () -> sendReminderMessage(request, seconds),
                    delaySeconds,
                    TimeUnit.SECONDS
                );
            }
        }
    }
    
    /**
     * Send a reminder message to the target player
     */
    private void sendReminderMessage(TradeRequest request, int secondsLeft) {
        class_3222 target = request.getTarget();
        class_3222 sender = request.getSender();
        
        // Check if the request is still active
        if (!activeTradeRequests.containsKey(target.method_5667())) {
            return;
        }
        
        // Send reminder to target
        if (target != null && !target.method_14239()) {
            class_2561 reminderText = class_2561.method_43470("⏰ ").method_27692(class_124.field_1054)
                .method_10852(class_2561.method_43470("Trade Reminder").method_27695(class_124.field_1054, class_124.field_1067))
                .method_10852(class_2561.method_43470("\nYou have a pending trade request from "))
                .method_10852(class_2561.method_43470(sender.method_5477().getString()).method_27692(class_124.field_1075))
                .method_10852(class_2561.method_43470("\nThis trade will expire in "))
                .method_10852(class_2561.method_43470(secondsLeft + " seconds").method_27692(class_124.field_1061));
                
            target.method_43496(reminderText);
        }
        
        // Send reminder to sender
        if (sender != null && !sender.method_14239()) {
            class_2561 reminderText = class_2561.method_43470("⏰ ").method_27692(class_124.field_1054)
                .method_10852(class_2561.method_43470("Trade Reminder").method_27695(class_124.field_1054, class_124.field_1067))
                .method_10852(class_2561.method_43470("\nYour trade request to "))
                .method_10852(class_2561.method_43470(target.method_5477().getString()).method_27692(class_124.field_1075))
                .method_10852(class_2561.method_43470(" will expire in "))
                .method_10852(class_2561.method_43470(secondsLeft + " seconds").method_27692(class_124.field_1061));
                
            sender.method_43496(reminderText);
        }
    }
    
    /**
     * Accept a trade request
     * @param targetPlayer The player accepting the request
     * @return true if the trade was successful, false otherwise
     */
    public boolean acceptTradeRequest(class_3222 targetPlayer) {
        UUID targetUuid = targetPlayer.method_5667();
        
        // Check if there's an active trade request for this player
        if (!activeTradeRequests.containsKey(targetUuid)) {
            return false;
        }
        
        TradeRequest request = activeTradeRequests.get(targetUuid);
        
        // Cancel the timeout future
        if (request.getTimeoutFuture() != null) {
            request.getTimeoutFuture().cancel(false);
        }
        
        // Execute the trade
        boolean success = executeTradeTransaction(request);
        
        // Remove the trade request
        activeTradeRequests.remove(targetUuid);
        
        return success;
    }
    
    /**
     * Deny a trade request
     * @param targetPlayer The player denying the request
     * @return true if a request was denied, false otherwise
     */
    public boolean denyTradeRequest(class_3222 targetPlayer) {
        UUID targetUuid = targetPlayer.method_5667();
        
        // Check if there's an active trade request for this player
        if (!activeTradeRequests.containsKey(targetUuid)) {
            return false;
        }
        
        TradeRequest request = activeTradeRequests.get(targetUuid);
        
        // Cancel the timeout future
        if (request.getTimeoutFuture() != null) {
            request.getTimeoutFuture().cancel(false);
        }
        
        // Return the item to the sender's inventory
        returnItemToSender(request, "trade denied");
        
        // Notify both players that the trade was denied
        class_3222 sender = request.getSender();
        if (sender != null && !sender.method_14239()) {
            class_2561 message = class_2561.method_43470("❌ ").method_27692(class_124.field_1061)
                .method_10852(class_2561.method_43470("Trade Denied").method_27695(class_124.field_1061, class_124.field_1067))
                .method_10852(class_2561.method_43470("\n" + targetPlayer.method_5477().getString() + " denied your trade request."))
                .method_10852(class_2561.method_43470("\nYour item has been returned to your inventory.").method_27692(class_124.field_1060));
            
            sender.method_43496(message);
        }
        
        class_2561 message = class_2561.method_43470("✓ ").method_27692(class_124.field_1060)
            .method_10852(class_2561.method_43470("Trade Denied").method_27695(class_124.field_1061, class_124.field_1067))
            .method_10852(class_2561.method_43470("\nYou denied the trade request from " + request.getSender().method_5477().getString() + "."));
            
        targetPlayer.method_43496(message);
        
        // Remove the trade request
        activeTradeRequests.remove(targetUuid);
        
        LOGGER.info("Trade request from {} to {} was denied", 
            request.getSender().method_5477().getString(), 
            targetPlayer.method_5477().getString());
        
        return true;
    }
    
    /**
     * Handle trade request expiration
     */
    private void expireTradeRequest(TradeRequest request) {
        class_3222 target = request.getTarget();
        
        // Check if the request is still active
        if (target == null || !activeTradeRequests.containsKey(target.method_5667())) {
            return;
        }
        
        // Return the item to the sender's inventory
        returnItemToSender(request, "trade expired");
        
        // Notify both players that the trade expired
        class_3222 sender = request.getSender();
        
        if (sender != null && !sender.method_14239()) {
            class_2561 message = class_2561.method_43470("⏰ ").method_27692(class_124.field_1054)
                .method_10852(class_2561.method_43470("Trade Expired").method_27695(class_124.field_1054, class_124.field_1067))
                .method_10852(class_2561.method_43470("\nYour trade request to " + target.method_5477().getString() + " has expired."))
                .method_10852(class_2561.method_43470("\nYour item has been returned to your inventory.").method_27692(class_124.field_1060));
                
            sender.method_43496(message);
        }
        
        if (target != null && !target.method_14239()) {
            class_2561 message = class_2561.method_43470("⏰ ").method_27692(class_124.field_1054)
                .method_10852(class_2561.method_43470("Trade Expired").method_27695(class_124.field_1054, class_124.field_1067))
                .method_10852(class_2561.method_43470("\nThe trade request from " + sender.method_5477().getString() + " has expired."));
                
            target.method_43496(message);
        }
        
        // Remove the trade request
        activeTradeRequests.remove(target.method_5667());
        
        LOGGER.info("Trade request from {} to {} expired", 
            sender != null ? sender.method_5477().getString() : "unknown", 
            target != null ? target.method_5477().getString() : "unknown");
    }
    
    /**
     * Return the traded item to the sender
     */
    private void returnItemToSender(TradeRequest request, String reason) {
        class_3222 sender = request.getSender();
        class_1799 itemToReturn = request.getItem();
        
        if (sender != null && !sender.method_14239()) {
            // Try to give the item back to the player
            if (!sender.method_31548().method_7394(itemToReturn)) {
                // If inventory is full, drop the item at the player's feet
                sender.method_7328(itemToReturn, false);
                
                sender.method_43496(class_2561.method_43470("⚠ Your inventory was full, so the traded item was dropped at your feet.")
                    .method_27692(class_124.field_1065));
            }
            
            LOGGER.info("Returned trade item to {} due to {}: {}", 
                sender.method_5477().getString(), reason, itemToReturn.method_7964().getString());
        } else {
            LOGGER.warn("Could not return trade item due to {}: sender is offline", reason);
        }
    }
    
    /**
     * Send the trade request message to the target player
     */
    private void sendTradeRequest(TradeRequest request) {
        class_3222 target = request.getTarget();
        class_3222 sender = request.getSender();
        class_1799 item = request.getItem();
        double price = request.getPrice();
        
        // Format item name with hover tooltip
        class_5250 itemComponent = createItemHoverTooltip(item);
        
        // Create clickable buttons
        class_5250 acceptButton = class_2561.method_43470("[Accept]")
            .method_10862(class_2583.field_24360
                .method_10977(class_124.field_1060)
                .method_10982(true)
                .method_10958(new class_2558(class_2558.class_2559.field_11750, "/tradehand accept"))
                .method_10949(new class_2568(class_2568.class_5247.field_24342, 
                    class_2561.method_43470("Click to accept this trade"))));
                    
        class_5250 denyButton = class_2561.method_43470("[Deny]")
            .method_10862(class_2583.field_24360
                .method_10977(class_124.field_1061)
                .method_10982(true)
                .method_10958(new class_2558(class_2558.class_2559.field_11750, "/tradehand deny"))
                .method_10949(new class_2568(class_2568.class_5247.field_24342, 
                    class_2561.method_43470("Click to deny this trade"))));
        
        // Create and send the message
        class_2561 header = class_2561.method_43470("📦 ")
            .method_27692(class_124.field_1065)
            .method_10852(class_2561.method_43470("Trade Request")
                .method_27692(class_124.field_1065));
            
        class_2561 details = class_2561.method_43470("\n" + sender.method_5477().getString() + " wants to sell you:")
            .method_10852(class_2561.method_43470("\n").method_10852(itemComponent))
            .method_10852(class_2561.method_43470("\nfor "))
            .method_10852(class_2561.method_43470("$" + formatPrice(price))
                .method_27695(class_124.field_1060, class_124.field_1067));
            
        class_2561 timer = class_2561.method_43470("\n\nThis request will expire in " + TRADE_TIMEOUT + " seconds.");
            
        class_2561 buttons = class_2561.method_43470("\n")
            .method_10852(acceptButton)
            .method_10852(class_2561.method_43470(" "))
            .method_10852(denyButton);
        
        target.method_43496(header.method_27661().method_10852(details).method_10852(timer).method_10852(buttons));
        
        // Notify the sender as well
        class_2561 senderMessage = class_2561.method_43470("📦 ")
            .method_27692(class_124.field_1065)
            .method_10852(class_2561.method_43470("Trade Request Sent")
                .method_27692(class_124.field_1065))
            .method_10852(class_2561.method_43470("\nYou offered to sell "))
            .method_10852(itemComponent)
            .method_10852(class_2561.method_43470(" to " + target.method_5477().getString() + " for "))
            .method_10852(class_2561.method_43470("$" + formatPrice(price))
                .method_27695(class_124.field_1060, class_124.field_1067))
            .method_10852(class_2561.method_43470("\nYour item has been removed from your inventory and will be returned if the trade expires or is denied."))
            .method_10852(class_2561.method_43470("\nWaiting for their response..."));
            
        sender.method_43496(senderMessage);
    }
    
    /**
     * Execute the trade transaction
     * @param request The trade request to execute
     * @return true if the trade was successful, false otherwise
     */
    private boolean executeTradeTransaction(TradeRequest request) {
        class_3222 sender = request.getSender();
        class_3222 target = request.getTarget();
        class_1799 item = request.getItem();
        double price = request.getPrice();
        
        LOGGER.info("Executing trade transaction: {} selling {} to {} for ${}", 
            sender.method_5477().getString(), 
            item.method_7964().getString(), 
            target.method_5477().getString(), 
            price);
        
        // Get the economy manager from the main mod class
        var economyManager = CurrencyMod.getEconomyManager();
        
        if (economyManager == null) {
            LOGGER.error("Cannot execute trade: Economy manager is null");
            return false;
        }
        
        // Check if the buyer has enough money
        if (economyManager.getBalance(target.method_5667()) < price) {
            // Notify both players that the buyer doesn't have enough money
            sender.method_43496(class_2561.method_43470("❌ Trade Failed: ").method_27695(class_124.field_1061, class_124.field_1067)
                .method_10852(class_2561.method_43470(target.method_5477().getString() + " doesn't have enough money.")));
                
            target.method_43496(class_2561.method_43470("❌ Trade Failed: ").method_27695(class_124.field_1061, class_124.field_1067)
                .method_10852(class_2561.method_43470("You don't have enough money to complete this trade.")));
                
            // Return the item to the sender
            returnItemToSender(request, "buyer insufficient funds");
            
            LOGGER.info("Trade failed: {} doesn't have enough money", target.method_5477().getString());
            return false;
        }
        
        // Transfer the money from the buyer to the seller
        boolean transferSuccess = economyManager.transferMoney(target.method_5667(), sender.method_5667(), price);
        
        if (!transferSuccess) {
            // Notify both players that the money transfer failed
            sender.method_43496(class_2561.method_43470("❌ Trade Failed: ").method_27695(class_124.field_1061, class_124.field_1067)
                .method_10852(class_2561.method_43470("Money transfer failed. The item has been returned to you.")));
                
            target.method_43496(class_2561.method_43470("❌ Trade Failed: ").method_27695(class_124.field_1061, class_124.field_1067)
                .method_10852(class_2561.method_43470("Money transfer failed.")));
                
            // Return the item to the sender
            returnItemToSender(request, "money transfer failed");
            
            LOGGER.error("Trade failed: Money transfer failed");
            return false;
        }
        
        // Give the item to the buyer
        boolean itemGiven = giveItemToBuyer(target, item);
        
        if (!itemGiven) {
            // Reverse the money transfer
            economyManager.transferMoney(sender.method_5667(), target.method_5667(), price);
            
            // Notify both players that the item transfer failed
            sender.method_43496(class_2561.method_43470("❌ Trade Failed: ").method_27695(class_124.field_1061, class_124.field_1067)
                .method_10852(class_2561.method_43470("Couldn't give the item to the buyer. The money has been refunded.")));
                
            target.method_43496(class_2561.method_43470("❌ Trade Failed: ").method_27695(class_124.field_1061, class_124.field_1067)
                .method_10852(class_2561.method_43470("Couldn't receive the item. Your money has been refunded.")));
                
            // Return the item to the sender
            returnItemToSender(request, "item transfer failed");
            
            LOGGER.error("Trade failed: Item transfer failed");
            return false;
        }
        
        // Notify both players that the trade was successful
        class_5250 itemComponent = createItemHoverTooltip(item);
        
        sender.method_43496(class_2561.method_43470("✓ Trade Successful! ").method_27695(class_124.field_1060, class_124.field_1067)
            .method_10852(class_2561.method_43470("You sold "))
            .method_10852(itemComponent)
            .method_10852(class_2561.method_43470(" to " + target.method_5477().getString() + " for "))
            .method_10852(class_2561.method_43470("$" + formatPrice(price)).method_27692(class_124.field_1060)));
            
        target.method_43496(class_2561.method_43470("✓ Trade Successful! ").method_27695(class_124.field_1060, class_124.field_1067)
            .method_10852(class_2561.method_43470("You bought "))
            .method_10852(itemComponent)
            .method_10852(class_2561.method_43470(" from " + sender.method_5477().getString() + " for "))
            .method_10852(class_2561.method_43470("$" + formatPrice(price)).method_27692(class_124.field_1060)));
            
        LOGGER.info("Trade successful: {} sold {} to {} for ${}", 
            sender.method_5477().getString(), 
            item.method_7964().getString(), 
            target.method_5477().getString(), 
            price);
            
        return true;
    }
    
    /**
     * Give an item to the buyer
     * @param buyer The player buying the item
     * @param item The item to give
     * @return true if the item was successfully given, false otherwise
     */
    private boolean giveItemToBuyer(class_3222 buyer, class_1799 item) {
        if (buyer == null || item == null || item.method_7960()) {
            return false;
        }
        
        // Try to add the item to the buyer's inventory
        boolean success = buyer.method_31548().method_7394(item.method_7972());
        
        if (!success) {
            // If the inventory is full, drop the item at the buyer's feet
            buyer.method_7328(item.method_7972(), false);
            
            buyer.method_43496(class_2561.method_43470("⚠ Your inventory was full, so the item was dropped at your feet.")
                .method_27692(class_124.field_1065));
        }
        
        return true;
    }

    public static class_9304 getEnchants(class_1799 stack) {
        // Under the hood this reads the "Enchantments" NBT list and
        // turns it into a Map<Enchantment, Integer>
        return class_1890.method_57532(stack);
    }

    /**
     * Extract enchantment information from an item using simplified approach for 1.21.1
     * @param item The item to extract enchantment info from
     * @return Text component with enchantment information or null if none
     */
    private class_2561 getEnchantmentInfoText(class_1799 item) {
        if (!item.method_7958()) {
            return null;
        }
        
        // In Minecraft 1.21.1, just provide a simple enchantment indicator without details
        // This avoids API compatibility issues

        class_9304 enchantments = getEnchants(item);
        // ask it to write its data into a fresh NbtCompound
        Set<class_6880<class_1887>> enchSet = enchantments.method_57534();
        Map<class_1887, Integer> enchMap = new HashMap<>();
        for (class_6880<class_1887> entry : enchSet) {
            enchMap.put(entry.comp_349(), enchantments.method_57536(entry));
        }

        var enchantmentText = class_2561.method_43470("✨ Enchanted with ")
                .method_27692(class_124.field_1076);

        int idx   = 0;
        int total = enchMap.size();

        List<class_2561> enchantmentTexts = new ArrayList<>();
        for (Map.Entry<class_1887, Integer> entry : enchMap.entrySet()) {
            enchantmentTexts.add(class_2561.method_43470(entry.getKey().toString().replace("minecraft:", "").replace("Enchantment ", ""))
                .method_27692(class_124.field_1076).method_27693(" " + entry.getValue()));
            idx++;
            if (idx < total) {
                enchantmentTexts.add(class_2561.method_43470(", "));
            }
            else if (idx == total) {
                enchantmentTexts.add(class_2561.method_43470("."));
            }
        }

        for (class_2561 text : enchantmentTexts) {
            enchantmentText.method_10852(text);
        }

        return enchantmentText;
    }
    
    /**
     * Creates a hover tooltip for an item with enchantment details
     */
    private class_5250 createItemHoverTooltip(class_1799 item) {
        class_5250 itemText = class_2561.method_43470(item.method_7947() + "x ")
            .method_27692(class_124.field_1054)
            .method_10852(item.method_7964().method_27661().method_27692(class_124.field_1065));
        
        // Create tooltip with item info
        List<class_2561> tooltip = new ArrayList<>();
        tooltip.add(item.method_7964().method_27661().method_27695(class_124.field_1065, class_124.field_1067));
        tooltip.add(class_2561.method_43470("")); // Empty line
        
        // In Minecraft 1.21.1, we can't easily get detailed enchantment info
        // Just indicate that the item is enchanted
        if (item.method_7958()) {
            tooltip.add(getEnchantmentInfoText(item));
        }
        
        // Set the hover event with our custom tooltip
        class_5250 joinedText = class_2561.method_43470("");
        for (int i = 0; i < tooltip.size(); i++) {
            joinedText.method_10852(tooltip.get(i));
            if (i < tooltip.size() - 1) {
                joinedText.method_10852(class_2561.method_43470("\n"));
            }
        }
        
        itemText.method_10862(itemText.method_10866().method_10949(
            new class_2568(class_2568.class_5247.field_24342, joinedText)
        ));
        
        return itemText;
    }
    
    /**
     * Format a price nicely
     */
    private String formatPrice(double price) {
        if (price == Math.floor(price)) {
            return String.format("%.0f", price);
        } else {
            return String.format("%.2f", price);
        }
    }
    
    /**
     * Clean up resources
     */
    public void shutdown() {
        // Return all traded items to their senders
        for (TradeRequest request : activeTradeRequests.values()) {
            returnItemToSender(request, "server shutdown");
        }
        
        // Clear active requests
        activeTradeRequests.clear();
        
        // Shutdown the scheduler
        scheduler.shutdown();
    }
    
    /**
     * Class to hold trade request information
     */
    private static class TradeRequest {
        private final class_3222 sender;
        private final class_3222 target;
        private final class_1799 item;
        private final double price;
        private ScheduledFuture<?> timeoutFuture;
        
        public TradeRequest(class_3222 sender, class_3222 target, class_1799 item, double price) {
            this.sender = sender;
            this.target = target;
            this.item = item;
            this.price = price;
        }
        
        public class_3222 getSender() {
            return sender;
        }
        
        public class_3222 getTarget() {
            return target;
        }
        
        public class_1799 getItem() {
            return item;
        }
        
        public double getPrice() {
            return price;
        }
        
        public ScheduledFuture<?> getTimeoutFuture() {
            return timeoutFuture;
        }
        
        public void setTimeoutFuture(ScheduledFuture<?> timeoutFuture) {
            this.timeoutFuture = timeoutFuture;
        }
    }
} 