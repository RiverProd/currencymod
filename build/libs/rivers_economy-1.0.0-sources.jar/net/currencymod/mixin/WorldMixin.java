package net.currencymod.mixin;

import net.currencymod.shop.ShopAccess;
import net.currencymod.shop.ShopManager;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1937.class)
public abstract class WorldMixin implements ShopAccess {
    
    @Shadow public abstract class_5321<class_1937> getRegistryKey();
    
    @Unique
    private ShopManager shopManager;
    
    @Inject(method = "<init>*", at = @At("RETURN"))
    private void onInit(CallbackInfo ci) {
        // Only initialize for server worlds
        if ((Object) this instanceof class_3218) {
            this.shopManager = new ShopManager();
        }
    }
    
    @Override
    public ShopManager getShopManager() {
        return shopManager;
    }
} 