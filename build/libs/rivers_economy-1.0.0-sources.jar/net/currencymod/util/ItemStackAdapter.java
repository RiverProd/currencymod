package net.currencymod.util;

import com.google.gson.*;
import java.lang.reflect.Type;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/**
 * A simplified adapter for serializing and deserializing ItemStack objects with GSON.
 * Only stores basic item information to avoid MC 1.21.1 API compatibility issues.
 */
public class ItemStackAdapter implements JsonSerializer<class_1799>, JsonDeserializer<class_1799> {
    
    @Override
    public JsonElement serialize(class_1799 itemStack, Type typeOfSrc, JsonSerializationContext context) {
        JsonObject jsonObject = new JsonObject();
        
        // Store only basic item data to avoid API compatibility issues
        // Get the registry ID of the item
        String itemId = class_7923.field_41178.method_10221(itemStack.method_7909()).toString();
        jsonObject.addProperty("id", itemId);
        jsonObject.addProperty("count", itemStack.method_7947());
        
        // Store the display name as basic text
        jsonObject.addProperty("displayName", itemStack.method_7964().getString());
        
        return jsonObject;
    }
    
    @Override
    public class_1799 deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        try {
            JsonObject obj = json.getAsJsonObject();
            
            // Get the ID of the item
            String itemId = obj.get("id").getAsString();
            
            // Parse the ID using Identifier.of which is the correct API for 1.21.1
            class_1792 item = class_7923.field_41178.method_10223(class_2960.method_60654(itemId));
            
            // Get the count
            int count = obj.has("count") ? obj.get("count").getAsInt() : 1;
            
            // Create the ItemStack
            return new class_1799(item, count);
        } catch (Exception e) {
            // Log error and return a fallback item
            System.err.println("Error deserializing ItemStack: " + e.getMessage());
            return new class_1799(class_7923.field_41178.method_10223(class_2960.method_60654("minecraft:stone")));
        }
    }
} 