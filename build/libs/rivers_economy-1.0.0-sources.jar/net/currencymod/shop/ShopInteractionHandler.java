package net.currencymod.shop;

import net.currencymod.CurrencyMod;
import net.currencymod.economy.EconomyManager;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1772;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2551;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2625;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import net.minecraft.class_7923;
import net.currencymod.services.ServiceManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Handles shop transactions when players interact with shop signs
 */
public class ShopInteractionHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger("CurrencyMod/ShopInteractionHandler");
    
    // Cache for item name to item mappings
    private static final Map<String, class_1792> itemNameCache = new HashMap<>();
    
    // Pattern to match quantity: just a number
    private static final Pattern QUANTITY_PATTERN = Pattern.compile("(\\d+)");
    
    // Pattern to match "quantity : price" format
    private static final Pattern QUANTITY_PRICE_PATTERN = Pattern.compile("(\\d+)\\s*:\\s*\\$?(\\d+(?:\\.\\d+)?)");
    
    /**
     * Register the shop interaction handler
     */
    public static void register() {
        UseBlockCallback.EVENT.register(ShopInteractionHandler::onUseBlock);
        LOGGER.info("Registered shop interaction handler");
    }
    
    /**
     * Handle block interaction events for shop transactions
     */
    private static class_1269 onUseBlock(class_1657 player, class_1937 world, class_1268 hand, class_3965 hitResult) {
        // Only process on server side
        if (world.method_8608() || !(world instanceof class_3218 serverWorld)) {
            return class_1269.field_5811;
        }
        
        class_2338 pos = hitResult.method_17777();
        class_2680 state = world.method_8320(pos);
        
        // Check if we're interacting with a sign (but not editing it)
        class_2586 blockEntity = world.method_8321(pos);
        if (!(blockEntity instanceof class_2625 signBlockEntity)) {
            return class_1269.field_5811;
        }
        
        // Get shop data from the shop manager
        ShopManager shopManager = ((ShopAccess) world).getShopManager();
        if (shopManager == null) {
            return class_1269.field_5811;
        }
        
        String worldId = ShopManager.getWorldId(world);
        ShopData shopData = shopManager.getShop(worldId, pos);
        
        // If this is not a shop sign, allow default behavior
        if (shopData == null) {
            return class_1269.field_5811;
        }
        
        LOGGER.info("Shop sign interaction at {} by {}", pos, player.method_5477().getString());
        
        // Check if this is an admin shop
        boolean isAdminShop = shopData.isAdminShop();
        
        // This is a shop sign! Handle shop logic
        class_2338 chestPos = findAttachedChest(world, pos, state);
        
        // Regular shops require a chest, but admin shops don't
        if (chestPos == null && !isAdminShop) {
            class_2561 errorText = class_2561.method_43470("❌ ").method_27692(class_124.field_1061)
                .method_10852(class_2561.method_43470("Chest Missing").method_27695(class_124.field_1061, class_124.field_1067));
                
            class_2561 detailsText = class_2561.method_43470("This shop is no longer connected to a chest and has been removed.");
                
            player.method_7353(errorText, false);
            player.method_7353(detailsText, false);
            
            boolean removed = removeShop(shopManager, worldId, pos);
            if (removed) {
                // Also remove from shop detector tracking
                ShopDetector.untrackShopSign(worldId, pos);
                LOGGER.info("Removed shop at {} because chest is missing", pos);
            } else {
                LOGGER.warn("Failed to remove shop at {} despite missing chest", pos);
            }
            return class_1269.field_5812;
        }
        
        // For regular shops, get the chest entity; admin shops don't need one
        class_2595 chestEntity = null;
        if (!isAdminShop) {
            chestEntity = (class_2595) world.method_8321(chestPos);
            if (chestEntity == null) {
                class_2561 errorText = class_2561.method_43470("❌ ").method_27692(class_124.field_1061)
                    .method_10852(class_2561.method_43470("Invalid Chest").method_27695(class_124.field_1061, class_124.field_1067));
                    
                player.method_7353(errorText, false);
                return class_1269.field_5812;
            }
        }
        
        // Parse shop sign to get item details
        class_2625 sign = (class_2625) blockEntity;

        // Check for service subscription restriction via first line, e.g. [Buy TAG] or [Sell TAG]
        String firstLineRaw = sign.method_49853().method_49859(0, false).getString().trim();
        String requiredServiceTag = extractServiceTag(firstLineRaw);
        
        // If shop is missing web sync data, try to migrate it now (chunk is loaded since player is interacting)
        if (!shopData.hasWebSyncData()) {
            if (shopManager != null) {
                shopManager.migrateShopDataIfNeeded(serverWorld, pos);
                // Refresh shop data after migration
                shopData = shopManager.getShop(worldId, pos);
            }
        }

        if (requiredServiceTag != null && player instanceof class_3222 serverPlayer) {
            // Allow shop owner to bypass the restriction
            if (!shopData.getOwner().equals(serverPlayer.method_5667())) {
                boolean subscribed = ServiceManager.getInstance()
                    .hasSubscription(serverPlayer.method_5667(), requiredServiceTag);
                if (!subscribed) {
                    serverPlayer.method_7353(
                        class_2561.method_43470("You must subscribe to service ")
                            .method_27692(class_124.field_1068)
                            .method_10852(class_2561.method_43470(requiredServiceTag).method_27695(class_124.field_1054, class_124.field_1067))
                            .method_10852(class_2561.method_43470(" to use this shop.").method_27692(class_124.field_1068)),
                        false
                    );
                    serverPlayer.method_7353(
                        class_2561.method_43470("Use ").method_27692(class_124.field_1068)
                            .method_10852(class_2561.method_43470("/service subscribe " + requiredServiceTag)
                                .method_27692(class_124.field_1060))
                            .method_10852(class_2561.method_43470(" to subscribe.").method_27692(class_124.field_1068)),
                        false
                    );
                    return class_1269.field_5812;
                }
            }
        }
        ItemDetails itemDetails = parseItemDetails(sign);
        
        if (itemDetails == null) {
            player.method_7353(class_2561.method_43470("Invalid shop configuration!").method_27692(class_124.field_1061), false);
            return class_1269.field_5812;
        }
        
        // Handle shop transaction with item transfer
        handleTransaction(player, shopData, chestEntity, itemDetails);
        
        // Prevent the sign edit interface from appearing
        return class_1269.field_5812;
    }
    
    /**
     * Helper class to hold item details from sign
     */
    private static class ItemDetails {
        String itemName;
        class_1792 item;
        int quantity;
        double price;
        
        ItemDetails(String itemName, class_1792 item, int quantity, double price) {
            this.itemName = itemName;
            this.item = item;
            this.quantity = quantity;
            this.price = price;
        }
    }
    
    /**
     * Parse item details from a shop sign
     */
    private static ItemDetails parseItemDetails(class_2625 sign) {
        try {
            String firstLine = sign.method_49853().method_49859(0, false).getString().trim();
            String secondLine = sign.method_49853().method_49859(1, false).getString().trim();
            String thirdLine = sign.method_49853().method_49859(2, false).getString().trim();
            String fourthLine = sign.method_49853().method_49859(3, false).getString().trim();
            
            // Normalize first line to base type (strip optional service tag)
            String baseType = normalizeShopType(firstLine);

            // Check for valid shop type
            boolean isValid = baseType.equalsIgnoreCase("[BUY]") || 
                              baseType.equalsIgnoreCase("[SELL]") ||
                              baseType.equalsIgnoreCase("[ADMINBUY]") || 
                              baseType.equalsIgnoreCase("[ADMINSELL]");
            
            if (!isValid) {
                LOGGER.warn("Invalid shop type: {}", firstLine);
                return null;
            }
            
            // Check if this is using the new format (quantity : price in fourth line)
            Matcher quantityPriceMatcher = QUANTITY_PRICE_PATTERN.matcher(fourthLine);
            if (quantityPriceMatcher.find()) {
                // This is the new format with two-line item name and quantity:price in fourth line
                // Combine second and third lines for item name
                String itemName = secondLine;
                if (!thirdLine.isEmpty()) {
                    itemName += " " + thirdLine;
                }
                
                // Parse quantity and price from fourth line
                int quantity = Integer.parseInt(quantityPriceMatcher.group(1));
                double price = Double.parseDouble(quantityPriceMatcher.group(2));
                
                // Find the item
                class_1792 item = getItemFromName(itemName);
                if (item == null) {
                    LOGGER.warn("Item not found: {}", itemName);
                    return null;
                }
                
                LOGGER.info("Successfully parsed shop sign (new format): {} item={}, quantity={}, price=${}", 
                    baseType, itemName, quantity, price);
                return new ItemDetails(itemName, item, quantity, price);
            } else {
                // Use the original format: item on second line, quantity on third, price on fourth
                String itemName = secondLine;
                String quantityLine = thirdLine;
                String priceLine = fourthLine;
                
                // Parse the quantity
                int quantity = 1;
                Matcher quantityMatcher = QUANTITY_PATTERN.matcher(quantityLine);
                if (quantityMatcher.find()) {
                    quantity = Integer.parseInt(quantityMatcher.group(1));
                } else {
                    try {
                        // Try direct parse if pattern doesn't match
                        quantity = Integer.parseInt(quantityLine);
                    } catch (NumberFormatException e) {
                        LOGGER.warn("No quantity found in: {}", quantityLine);
                        return null;
                    }
                }
                
                // Parse the price
                double price = 0.0;
                if (priceLine.startsWith("$")) {
                    try {
                        price = Double.parseDouble(priceLine.substring(1));
                    } catch (NumberFormatException e) {
                        LOGGER.warn("Invalid price format: {}", priceLine);
                        return null;
                    }
                } else {
                    try {
                        price = Double.parseDouble(priceLine);
                    } catch (NumberFormatException e) {
                        LOGGER.warn("No price found in: {}", priceLine);
                        return null;
                    }
                }
                
                // Find the item
                class_1792 item = getItemFromName(itemName);
                if (item == null) {
                    LOGGER.warn("Item not found: {}", itemName);
                    return null;
                }
                
                LOGGER.info("Successfully parsed shop sign (standard format): {} item={}, quantity={}, price=${}", 
                    baseType, itemName, quantity, price);
                return new ItemDetails(itemName, item, quantity, price);
            }
        } catch (Exception e) {
            LOGGER.error("Error parsing shop sign: {}", e.getMessage());
            return null;
        }
    }

    /**
     * Extract an optional service tag from the first line of a shop sign.
     * Supports formats like [Buy TAG] or [Sell TAG] (case-insensitive, TAG = 1-3 letters).
     * Returns the uppercased tag or null if none/invalid.
     */
    private static String extractServiceTag(String firstLine) {
        if (firstLine == null) return null;
        String trimmed = firstLine.trim();
        if (!trimmed.startsWith("[") || !trimmed.endsWith("]")) {
            return null;
        }
        String inner = trimmed.substring(1, trimmed.length() - 1).trim();
        String[] parts = inner.split("\\s+");
        if (parts.length != 2) {
            return null;
        }
        String base = parts[0];
        String tag = parts[1];
        if (!(base.equalsIgnoreCase("buy") || base.equalsIgnoreCase("sell"))) {
            return null;
        }
        if (tag.length() < 1 || tag.length() > 3) {
            return null;
        }
        // Ensure tag is letters only
        if (!tag.matches("(?i)[A-Z]{1,3}")) {
            return null;
        }
        return tag.toUpperCase();
    }

    /**
     * Normalize a shop sign's first line to its base type token.
     * E.g. "[Buy TAG]" -> "[BUY]", "[Sell]" -> "[SELL]".
     */
    private static String normalizeShopType(String firstLine) {
        if (firstLine == null) return "";
        String trimmed = firstLine.trim();
        if (!trimmed.startsWith("[") || !trimmed.endsWith("]")) {
            return trimmed;
        }
        String inner = trimmed.substring(1, trimmed.length() - 1).trim();
        String[] parts = inner.split("\\s+");
        String base = parts[0].toUpperCase();
        return "[" + base + "]";
    }
    
    /**
     * Find a matching item from the item name on the sign
     */
    private static class_1792 getItemFromName(String name) {
        // Check cache first
        if (itemNameCache.containsKey(name)) {
            return itemNameCache.get(name);
        }
        
        // Try exact match with registry ID
        for (class_1792 item : class_7923.field_41178) {
            // Try to match by translated name (more user-friendly)
            String translatedName = item.method_7848().getString();
            if (translatedName.equalsIgnoreCase(name)) {
                itemNameCache.put(name, item);
                return item;
            }
            
            // Try to match by identifier (technical name)
            class_2960 id = class_7923.field_41178.method_10221(item);
            String idPath = id.method_12832();
            if (idPath.equalsIgnoreCase(name)) {
                itemNameCache.put(name, item);
                return item;
            }
            
            // Try to match by identifier without namespace
            String[] parts = name.split(":");
            String nameWithoutNamespace = parts.length > 1 ? parts[1] : name;
            if (idPath.equalsIgnoreCase(nameWithoutNamespace)) {
                itemNameCache.put(name, item);
                return item;
            }
        }
        
        // Not found
        return null;
    }
    
    /**
     * Helper method to remove a shop and verify the removal
     * Note: After calling this, you should also call ShopDetector.untrackShopSign 
     * to ensure the position can be reused for a new shop
     */
    private static boolean removeShop(ShopManager shopManager, String worldId, class_2338 pos) {
        // Remove the shop
        shopManager.removeShop(worldId, pos);
        
        // Verify the shop was actually removed
        return shopManager.getShop(worldId, pos) == null;
    }
    
    /**
     * Handle a shop transaction with item transfer
     */
    private static void handleTransaction(class_1657 player, ShopData shopData, class_2595 chest, ItemDetails itemDetails) {
        EconomyManager economyManager = CurrencyMod.getEconomyManager();
        
        boolean isBuyShop = shopData.isBuyShop();
        boolean isAdminShop = shopData.isAdminShop();
        double price = shopData.getPrice();
        String formattedPrice = formatPrice(price);
        
        // Get the prototype item with NBT data (if available)
        class_1799 prototypeItem = null;
        
        // For buying from shop, get item from chest
        if (isBuyShop && !isAdminShop && chest != null) {
            // Look for the first item of the correct type in the chest
            for (int i = 0; i < chest.method_5439(); i++) {
                class_1799 stack = chest.method_5438(i);
                if (!stack.method_7960() && itemStacksMatch(stack, itemToItemStack(itemDetails.item))) {
                    prototypeItem = stack.method_7972();
                    prototypeItem.method_7939(1); // Just need 1 for reference
                    break;
                }
            }
        }
        
        // For selling to shop, get item from player
        if (!isBuyShop) {
            // Look for the first item of the correct type in the player's inventory
            for (int i = 0; i < player.method_31548().method_5439(); i++) {
                class_1799 stack = player.method_31548().method_5438(i);
                if (!stack.method_7960() && itemStacksMatch(stack, itemToItemStack(itemDetails.item))) {
                    prototypeItem = stack.method_7972();
                    prototypeItem.method_7939(1); // Just need 1 for reference
                    break;
                }
            }
        }
        
        // Default to a basic item if no prototype found
        if (prototypeItem == null) {
            prototypeItem = new class_1799(itemDetails.item);
        }
        
        // Verify that we have a chest for regular shops
        if (!isAdminShop && chest == null) {
            class_2561 errorText = class_2561.method_43470("❌ ").method_27692(class_124.field_1061)
                .method_10852(class_2561.method_43470("Shop Error").method_27695(class_124.field_1061, class_124.field_1067));
                
            class_2561 detailsText = class_2561.method_43470("This shop has no attached chest storage.");
                
            player.method_7353(errorText, false);
            player.method_7353(detailsText, false);
            return;
        }
        
        if (isBuyShop) {
            // Player is buying from the shop (taking items from chest, paying money)
            
            // Check if player has enough money
            if (economyManager.getBalance(player.method_5667()) < price) {
                class_2561 errorText = class_2561.method_43470("❌ ").method_27692(class_124.field_1061)
                    .method_10852(class_2561.method_43470("Insufficient Funds").method_27695(class_124.field_1061, class_124.field_1067));
                    
                class_2561 detailsText = class_2561.method_43470("You need ")
                    .method_10852(class_2561.method_43470("$" + formattedPrice).method_27692(class_124.field_1054))
                    .method_10852(class_2561.method_43470(" to make this purchase."));
                    
                player.method_7353(errorText, false);
                player.method_7353(detailsText, false);
                return;
            }
            
            // For regular shops, check if chest has the items
            if (!isAdminShop) {
                int availableItems = countItems(chest, itemDetails.item, prototypeItem);
                if (availableItems < itemDetails.quantity) {
                    class_2561 errorText = class_2561.method_43470("❌ ").method_27692(class_124.field_1061)
                        .method_10852(class_2561.method_43470("Shop Out of Stock").method_27695(class_124.field_1061, class_124.field_1067));
                        
                    class_2561 detailsText = class_2561.method_43470("Only ")
                        .method_10852(class_2561.method_43470(availableItems + "").method_27692(class_124.field_1054))
                        .method_10852(class_2561.method_43470(" items available."));
                        
                    player.method_7353(errorText, false);
                    player.method_7353(detailsText, false);
                    return;
                }
            }
            
            // Process transaction
            // 1. Remove money from player
            economyManager.removeBalance(player.method_5667(), price);
            
            if (!isAdminShop) {
                // 2. Add money to shop owner (skip for admin shops)
                economyManager.addBalance(shopData.getOwner(), price);
                // 3. Remove items from chest (skip for admin shops)
                removeItemsFromChest(chest, itemDetails.item, itemDetails.quantity, prototypeItem);
            }
            
            // 4. Add items to player (using prototype for enchantments)
            addItemsToPlayer(player, prototypeItem, itemDetails.quantity);
            
            // Send a single-line transaction message
            class_2561 message = class_2561.method_43470("✓ ")
                .method_27692(class_124.field_1060)
                .method_10852(class_2561.method_43470("You bought ").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470(itemDetails.quantity + "").method_27692(class_124.field_1054))
                .method_10852(class_2561.method_43470(" " + itemDetails.itemName + " for ").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470("$" + formattedPrice).method_27695(class_124.field_1054, class_124.field_1067));
                
            if (isAdminShop) {
                // Use a complete new text instance since we can't append to an immutable Text
                message = class_2561.method_43473()
                    .method_10852(message)
                    .method_10852(class_2561.method_43470(" (Admin Shop)").method_27692(class_124.field_1065));
            }
            
            player.method_7353(message, false);
            
            // Extra message if buying from your own shop (for testing)
            if (!isAdminShop && shopData.getOwner().equals(player.method_5667())) {
                player.method_7353(class_2561.method_43470("⚠ This is your own shop")
                        .method_27692(class_124.field_1065), false);
            }
            
            // Record the transaction for notification/summary
            ShopTransactionManager.getInstance().recordTransaction(
                new ShopTransactionManager.TransactionRecord(
                    player.method_5667(),
                    player.method_5477().getString(),
                    shopData.getOwner(),
                    itemDetails.itemName,
                    itemDetails.quantity,
                    price,
                    true, // isBuyShop
                    System.currentTimeMillis()
                )
            );
            
            LOGGER.info("Transaction completed at {} shop: Player {} bought {}x {} for ${}", 
                isAdminShop ? "admin" : "regular", player.method_5477().getString(), 
                itemDetails.quantity, itemDetails.itemName, formattedPrice);
            
        } else {
            // Player is selling to the shop (giving items to chest, receiving money)
            
            // Check if player has enough items
            int playerItemCount;
            if (prototypeItem != null && hasSpecialProperties(prototypeItem)) {
                playerItemCount = countPlayerItemsWithEnchants(player, prototypeItem);
            } else {
                playerItemCount = countPlayerItems(player, itemDetails.item);
            }
            
            if (playerItemCount < itemDetails.quantity) {
                class_2561 errorText = class_2561.method_43470("❌ ").method_27692(class_124.field_1061)
                    .method_10852(class_2561.method_43470("Insufficient Items").method_27695(class_124.field_1061, class_124.field_1067));
                    
                class_2561 detailsText = class_2561.method_43470("You only have ")
                    .method_10852(class_2561.method_43470(playerItemCount + "").method_27692(class_124.field_1054))
                    .method_10852(class_2561.method_43470(" of these items."));
                    
                player.method_7353(errorText, false);
                player.method_7353(detailsText, false);
                return;
            }
            
            // For regular shops, check if shop owner has enough money
            if (!isAdminShop) {
                double ownerBalance = economyManager.getBalance(shopData.getOwner());
                if (ownerBalance < price) {
                    class_2561 errorText = class_2561.method_43470("❌ ").method_27692(class_124.field_1061)
                        .method_10852(class_2561.method_43470("Shop Can't Afford Purchase").method_27695(class_124.field_1061, class_124.field_1067));
                        
                    class_2561 detailsText = class_2561.method_43470("The shop owner only has ")
                        .method_10852(class_2561.method_43470("$" + formatPrice(ownerBalance)).method_27692(class_124.field_1054));
                        
                    player.method_7353(errorText, false);
                    player.method_7353(detailsText, false);
                    return;
                }
            }
            
            // For regular shops, check if there's space in the chest
            if (!isAdminShop && !hasChestSpace(chest)) {
                class_2561 errorText = class_2561.method_43470("❌ ").method_27692(class_124.field_1061)
                    .method_10852(class_2561.method_43470("Shop Chest Full").method_27695(class_124.field_1061, class_124.field_1067));
                    
                class_2561 detailsText = class_2561.method_43470("The shop's chest is full and cannot accept more items.");
                    
                player.method_7353(errorText, false);
                player.method_7353(detailsText, false);
                return;
            }
            
            // Process transaction
            // 1. Add money to player
            economyManager.addBalance(player.method_5667(), price);
            
            if (!isAdminShop) {
                // 2. Remove money from shop owner (skip for admin shops)
                economyManager.removeBalance(shopData.getOwner(), price);
                // 3. Add items to chest (skip for admin shops)
                addItemsToChest(chest, itemDetails.item, itemDetails.quantity, prototypeItem);
            }
            
            // 4. Remove items from player
            removeItemsFromPlayer(player, itemDetails.item, itemDetails.quantity, prototypeItem);
            
            // Send a single-line transaction message
            class_2561 message = class_2561.method_43470("✓ ")
                .method_27692(class_124.field_1078)
                .method_10852(class_2561.method_43470("You sold ").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470(itemDetails.quantity + "").method_27692(class_124.field_1054))
                .method_10852(class_2561.method_43470(" " + itemDetails.itemName + " for ").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470("$" + formattedPrice).method_27695(class_124.field_1054, class_124.field_1067));
            
            if (isAdminShop) {
                // Use a complete new text instance since we can't append to an immutable Text
                message = class_2561.method_43473()
                    .method_10852(message)
                    .method_10852(class_2561.method_43470(" (Admin Shop)").method_27692(class_124.field_1065));
            }
            
            player.method_7353(message, false);
            
            // Extra message if selling to your own shop (for testing)
            if (!isAdminShop && shopData.getOwner().equals(player.method_5667())) {
                player.method_7353(class_2561.method_43470("⚠ This is your own shop")
                        .method_27692(class_124.field_1065), false);
            }
            
            // Record the transaction for notification/summary
            ShopTransactionManager.getInstance().recordTransaction(
                new ShopTransactionManager.TransactionRecord(
                    player.method_5667(),
                    player.method_5477().getString(),
                    shopData.getOwner(),
                    itemDetails.itemName,
                    itemDetails.quantity,
                    price,
                    false, // isBuyShop 
                    System.currentTimeMillis()
                )
            );
            
            LOGGER.info("Transaction completed at {} shop: Player {} sold {}x {} for ${}", 
                isAdminShop ? "admin" : "regular", player.method_5477().getString(), 
                itemDetails.quantity, itemDetails.itemName, formattedPrice);
        }
    }
    
    /**
     * Format a price nicely
     */
    private static String formatPrice(double price) {
        if (price == Math.floor(price)) {
            return String.format("%.0f", price);
        } else {
            return String.format("%.2f", price);
        }
    }
    
    /**
     * Check if two item stacks match, considering enchantments
     */
    private static boolean itemStacksMatch(class_1799 stack1, class_1799 stack2) {
        // Check basic item type
        if (stack1.method_7909() != stack2.method_7909()) {
            return false;
        }
        
        // Check if item is enchanted
        boolean stack1Enchanted = stack1.method_7942() || stack1.method_7909() instanceof class_1772;
        boolean stack2Enchanted = stack2.method_7942() || stack2.method_7909() instanceof class_1772;
        
        // If one is enchanted and the other isn't, they don't match
        if (stack1Enchanted != stack2Enchanted) {
            return false;
        }
        
        // For enchanted items, in MC 1.21.1 we'll use a simplified approach
        // Just consider items of the same type with the same enchantment status as matching
        // This is a compromise due to API changes in 1.21.1
        
        // Basic items match if they're the same type
        return true;
    }
    
    /**
     * Compare enchantments between two enchanted books
     * This is no longer used in MC 1.21.1
     */
    private static boolean compareEnchantedBooks(class_1799 book1, class_1799 book2) {
        // In MC 1.21.1, we use a simpler approach in itemStacksMatch
        return true;
    }
    
    /**
     * Compare enchantments between two regular enchanted items
     * This is no longer used in MC 1.21.1
     */
    private static boolean compareEnchantments(class_1799 item1, class_1799 item2) {
        // In MC 1.21.1, we use a simpler approach in itemStacksMatch
        return true;
    }
    
    /**
     * Checks if an item has any special properties like enchantments
     */
    private static boolean hasSpecialProperties(class_1799 stack) {
        // Check for enchantments
        return stack.method_7942() || stack.method_7909() instanceof class_1772;
    }
    
    // Create a helper method to convert Item to ItemStack for comparison
    private static class_1799 itemToItemStack(class_1792 item) {
        return new class_1799(item);
    }
    
    /**
     * Counts items in a chest, considering enchantments
     * @param chest The chest to check
     * @param prototype The prototype item to match
     * @return The number of matching items found
     */
    private static int countItemsWithEnchants(class_2595 chest, class_1799 prototype) {
        int count = 0;
        for (int i = 0; i < chest.method_5439(); i++) {
            class_1799 stack = chest.method_5438(i);
            if (!stack.method_7960() && itemStacksMatch(stack, prototype)) {
                count += stack.method_7947();
            }
        }
        return count;
    }
    
    /**
     * Count items of a specific type in a player's inventory
     */
    private static int countPlayerItems(class_1657 player, class_1792 item) {
        int count = 0;
        class_1661 inventory = player.method_31548();
        
        // Check main inventory
        for (int i = 0; i < inventory.method_5439(); i++) {
            class_1799 stack = inventory.method_5438(i);
            if (!stack.method_7960() && stack.method_7909() == item) {
                count += stack.method_7947();
            }
        }
        
        return count;
    }
    
    /**
     * Counts items in a player's inventory, considering enchantments
     * @param player The player
     * @param prototype The prototype item to match
     * @return The number of matching items found
     */
    private static int countPlayerItemsWithEnchants(class_1657 player, class_1799 prototype) {
        int count = 0;
        class_1661 inventory = player.method_31548();
        
        // Check main inventory
        for (int i = 0; i < inventory.method_5439(); i++) {
            class_1799 stack = inventory.method_5438(i);
            if (!stack.method_7960() && itemStacksMatch(stack, prototype)) {
                count += stack.method_7947();
            }
        }
        
        return count;
    }
    
    /**
     * Count items in a chest, considering enchantments
     * @param chest The chest to check
     * @param item The item to match
     * @param prototype The prototype item to match
     * @return The number of matching items found
     */
    private static int countItems(class_2595 chest, class_1792 item, class_1799 prototype) {
        // If we have a prototype with NBT data, use specialized counting
        if (prototype != null && hasSpecialProperties(prototype)) {
            return countItemsWithEnchants(chest, prototype);
        }
        
        // Otherwise fall back to simple item type counting
        int count = 0;
        for (int i = 0; i < chest.method_5439(); i++) {
            class_1799 stack = chest.method_5438(i);
            if (!stack.method_7960() && stack.method_7909() == item) {
                count += stack.method_7947();
            }
        }
        return count;
    }
    
    /**
     * Check if a player has enough inventory space for the items
     */
    private static boolean hasInventorySpace(class_1657 player, class_1792 item, int quantity) {
        class_1661 inventory = player.method_31548();
        int remainingQuantity = quantity;
        
        // Check for existing stacks that can be filled
        for (int i = 0; i < inventory.method_5439(); i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7960()) {
                // Empty slot can hold a full stack
                remainingQuantity -= item.method_7882();
                if (remainingQuantity <= 0) return true;
            } else if (stack.method_7909() == item && stack.method_7947() < stack.method_7914()) {
                // Partial stack can be filled
                remainingQuantity -= (stack.method_7914() - stack.method_7947());
                if (remainingQuantity <= 0) return true;
            }
        }
        
        return false;
    }
    
    /**
     * Check if a chest has space for more items
     */
    private static boolean hasChestSpace(class_2595 chest) {
        for (int i = 0; i < chest.method_5439(); i++) {
            if (chest.method_5438(i).method_7960()) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Remove items from a chest
     */
    private static void removeItemsFromChest(class_2595 chest, class_1792 item, int quantity, class_1799 prototype) {
        int remaining = quantity;
        boolean checkSpecialProps = prototype != null && hasSpecialProperties(prototype);
        
        for (int i = 0; i < chest.method_5439() && remaining > 0; i++) {
            class_1799 stack = chest.method_5438(i);
            if (!stack.method_7960() && stack.method_7909() == item) {
                // If we need to check special properties and the items don't match, skip this stack
                if (checkSpecialProps && !itemStacksMatch(stack, prototype)) {
                    continue;
                }
                
                if (stack.method_7947() <= remaining) {
                    // Remove entire stack
                    remaining -= stack.method_7947();
                    chest.method_5447(i, class_1799.field_8037);
                } else {
                    // Remove partial stack
                    stack.method_7934(remaining);
                    remaining = 0;
                }
            }
        }
        
        chest.method_5431();
    }
    
    /**
     * Add items to a chest
     */
    private static void addItemsToChest(class_2595 chest, class_1792 item, int quantity, class_1799 prototype) {
        int remaining = quantity;
        
        // If we have a prototype with NBT, use it
        boolean hasSpecialProps = prototype != null && hasSpecialProperties(prototype);
        
        // First try to fill existing matching stacks if we have special properties
        if (hasSpecialProps) {
            for (int i = 0; i < chest.method_5439() && remaining > 0; i++) {
                class_1799 stack = chest.method_5438(i);
                if (!stack.method_7960() && itemStacksMatch(stack, prototype) && stack.method_7947() < stack.method_7914()) {
                    int canAdd = Math.min(remaining, stack.method_7914() - stack.method_7947());
                    stack.method_7933(canAdd);
                    remaining -= canAdd;
                }
            }
        } else {
            // Standard stacking for items without special properties
            for (int i = 0; i < chest.method_5439() && remaining > 0; i++) {
                class_1799 stack = chest.method_5438(i);
                if (!stack.method_7960() && stack.method_7909() == item && stack.method_7947() < stack.method_7914()) {
                    int canAdd = Math.min(remaining, stack.method_7914() - stack.method_7947());
                    stack.method_7933(canAdd);
                    remaining -= canAdd;
                }
            }
        }
        
        // Then fill empty slots
        for (int i = 0; i < chest.method_5439() && remaining > 0; i++) {
            class_1799 stack = chest.method_5438(i);
            if (stack.method_7960()) {
                int stackSize = Math.min(remaining, item.method_7882());
                
                // Use a copy of the prototype if available
                if (hasSpecialProps) {
                    class_1799 newStack = prototype.method_7972();
                    newStack.method_7939(stackSize);
                    chest.method_5447(i, newStack);
                } else {
                    chest.method_5447(i, new class_1799(item, stackSize));
                }
                
                remaining -= stackSize;
            }
        }
        
        chest.method_5431();
    }
    
    /**
     * Remove items from a player
     */
    private static void removeItemsFromPlayer(class_1657 player, class_1792 item, int quantity, class_1799 prototype) {
        if (prototype != null && hasSpecialProperties(prototype)) {
            // Use a predicate that checks both item type and special properties
            player.method_31548().method_29280(
                stack -> stack.method_7909() == item && itemStacksMatch(stack, prototype), 
                quantity, 
                player.method_31548()
            );
        } else {
            // Fall back to simple item type checking
            player.method_31548().method_29280(
                stack -> stack.method_7909() == item, 
                quantity, 
                player.method_31548()
            );
        }
    }
    
    /**
     * Add items to a player
     */
    private static void addItemsToPlayer(class_1657 player, class_1799 prototype, int quantity) {
        // Create a copy of the prototype item with the requested quantity
        class_1799 itemToAdd = prototype.method_7972();
        itemToAdd.method_7939(quantity);
        
        // Insert the item into the player's inventory
        player.method_31548().method_7394(itemToAdd);
    }
    
    /**
     * Find the chest that a sign is attached to.
     * Returns null for admin shops, which don't need a chest.
     */
    private static class_2338 findAttachedChest(class_1937 world, class_2338 signPos, class_2680 signState) {
        try {
            // Get shop data to check if this is an admin shop
            ShopManager shopManager = ((ShopAccess) world).getShopManager();
            if (shopManager != null) {
                String worldId = ShopManager.getWorldId(world);
                ShopData shopData = shopManager.getShop(worldId, signPos);
                
                // Admin shops don't need a chest
                if (shopData != null && shopData.isAdminShop()) {
                    return signPos; // Return any valid position to avoid chest checks
                }
            }
            
            // Check if this is a wall sign (attached to another block)
            if (signState.method_26204() instanceof class_2551) {
                class_2350 facing = signState.method_11654(class_2551.field_11726);
                class_2338 attachedPos = signPos.method_10093(facing.method_10153());
                
                // Check if the block it's attached to is a chest
                class_2680 attachedBlock = world.method_8320(attachedPos);
                if (attachedBlock.method_26204() instanceof class_2281) {
                    return attachedPos;
                }
            } else {
                // For standing signs, check the block below
                class_2338 belowPos = signPos.method_10074();
                class_2680 belowBlock = world.method_8320(belowPos);
                if (belowBlock.method_26204() instanceof class_2281) {
                    return belowPos;
                }
            }
        } catch (Exception e) {
            LOGGER.error("Error finding attached chest: {}", e.getMessage());
        }
        
        return null; // No chest found
    }
} 