package net.currencymod.shop;

import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2508;
import net.minecraft.class_2551;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Handler for shop sign break events
 * This replaces the functionality previously in the SignBlockMixin
 */
public class ShopSignBreakHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger("CurrencyMod/ShopSignBreak");
    
    /**
     * Register the shop sign break handler
     */
    public static void register() {
        // Register for block break events to handle breaking shop signs
        PlayerBlockBreakEvents.BEFORE.register(ShopSignBreakHandler::onBlockBreak);
        LOGGER.info("Registered shop sign break handler");
    }
    
    /**
     * Handle block break events for shop signs
     */
    private static boolean onBlockBreak(class_1937 world, class_1657 player, class_2338 pos, class_2680 state, class_2586 blockEntity) {
        // Only process on server side
        if (world.method_8608() || !(world instanceof class_3218)) {
            return true; // Allow the break on client
        }
        
        // Check if the block is a sign
        if (!(state.method_26204() instanceof class_2508) && !(state.method_26204() instanceof class_2551)) {
            return true; // Not a sign, allow the break
        }
        
        // Get shop data from the shop manager
        ShopManager shopManager = ((ShopAccess) world).getShopManager();
        if (shopManager == null) {
            return true; // No shop manager, allow the break
        }
        
        String worldId = ShopManager.getWorldId(world);
        ShopData shopData = shopManager.getShop(worldId, pos);
        
        // If this is not a shop sign, allow default behavior
        if (shopData == null) {
            return true; // Not a shop, allow the break
        }
        
        LOGGER.info("Shop sign break at {} by {}", pos, player.method_5477().getString());
        
        // Always allow the break now that we're removing the protection feature
        
        // Remove the shop from the manager
        boolean removed = removeShop(shopManager, worldId, pos);
        if (removed) {
            // Also remove from shop detector tracking
            ShopDetector.untrackShopSign(worldId, pos);
            LOGGER.info("Removed shop at {} due to sign being broken", pos);
            
            // Notify the player that a shop was removed
            String shopType = shopData.isBuyShop() ? "Buy" : "Sell";
            if (shopData.isAdminShop()) {
                shopType = "Admin " + shopType;
            }
            
            player.method_7353(
                net.minecraft.class_2561.method_43470("🛑 ")
                    .method_27692(net.minecraft.class_124.field_1061)
                    .method_10852(net.minecraft.class_2561.method_43470("Shop Removed")
                        .method_27695(net.minecraft.class_124.field_1061, net.minecraft.class_124.field_1067))
                    .method_10852(net.minecraft.class_2561.method_43470(" - " + shopType + " shop has been deleted.")
                        .method_27692(net.minecraft.class_124.field_1054)),
                false
            );
        } else {
            LOGGER.warn("Failed to remove shop at {} despite sign being broken", pos);
        }
        
        return true; // Always allow the break
    }
    
    /**
     * Helper method to remove a shop and verify the removal
     */
    private static boolean removeShop(ShopManager shopManager, String worldId, class_2338 pos) {
        // Remove the shop
        shopManager.removeShop(worldId, pos);
        
        // Verify the shop was actually removed
        return shopManager.getShop(worldId, pos) == null;
    }
} 