package net.currencymod.jobs;

import net.currencymod.CurrencyMod;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Handles marketplace interaction in a simplified way using block interaction.
 */
public class MarketplaceHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger("CurrencyMod/MarketplaceHandler");
    
    // The position of the marketplace chest, if any
    private static class_2338 marketplaceChestPos = null;
    
    /**
     * Register the marketplace handler.
     */
    public static void register() {
        // Instead of packet handling or item NBT, we use block interaction
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (world.method_8608() || hand != class_1268.field_5808) {
                return class_1269.field_5811;
            }
            
            class_2338 pos = hitResult.method_17777();
            class_2680 state = world.method_8320(pos);
            
            // Check if the block is the marketplace chest
            if (state.method_26204() instanceof class_2281 && pos.equals(marketplaceChestPos)) {
                // Open the marketplace GUI instead of the chest
                MarketplaceManager.getInstance().openMarketplace((class_3222) player);
                return class_1269.field_5812;
            }
            
            return class_1269.field_5811;
        });
        
        LOGGER.info("Registered marketplace handler using block interaction events");
    }
    
    /**
     * Set the marketplace chest position.
     * This is used to identify the chest that should open the marketplace.
     *
     * @param pos The position of the marketplace chest
     */
    public static void setMarketplaceChestPos(class_2338 pos) {
        marketplaceChestPos = pos;
        LOGGER.info("Set marketplace chest position to {}", pos);
    }
} 