package net.currencymod.jobs;

import net.currencymod.CurrencyMod;
import net.currencymod.config.ModConfig;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2960;
import net.minecraft.class_5250;
import net.minecraft.class_7923;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;
import java.util.Random;
import java.util.UUID;

/**
 * Represents a job that a player can complete.
 */
public class Job {
    private static final Logger LOGGER = LoggerFactory.getLogger("CurrencyMod/Job");
    private static final Random RANDOM = new Random();
    
    // 2% chance for a job to be a Mega job
    private static final double MEGA_JOB_CHANCE = 0.02;
    
    private final UUID id;
    private final String itemId;
    private final int quantity;
    private final int reward;
    private boolean active;
    // Flag to indicate if this is a Mega job
    private final boolean isMegaJob;
    
    /**
     * Creates a new job.
     *
     * @param id       The unique ID of the job
     * @param itemId   The item ID
     * @param quantity The quantity
     * @param reward   The reward
     * @param isMegaJob Whether this is a Mega job requiring more items for higher reward
     */
    public Job(UUID id, String itemId, int quantity, int reward, boolean isMegaJob) {
        this.id = id;
        this.itemId = itemId;
        this.quantity = quantity;
        this.reward = reward;
        this.active = false;
        this.isMegaJob = isMegaJob;
    }
    
    /**
     * Creates a job from a template.
     *
     * @param template The template
     * @return The job
     */
    public static Job fromTemplate(JobConfig.JobTemplate template) {
        // Determine if this will be a Mega job (2% chance)
        boolean isMegaJob = RANDOM.nextDouble() < MEGA_JOB_CHANCE;
        
        // Apply variations to quantity and reward
        int quantity = applyVariation(template.baseQuantity, template.quantityVariation);
        int reward = applyVariation(template.baseReward, template.rewardVariation);
        
        // Ensure minimum values
        quantity = Math.max(1, quantity);
        reward = Math.max(1, reward);
        
        // For Mega jobs, multiply quantity by 10 and increase reward by 50%
        if (isMegaJob) {
            quantity *= 10;
            reward = (int)(reward * 15);
            LOGGER.info("Created a Mega job requiring {} x {} with reward ${}", 
                       quantity, template.itemId, reward);
        }
        
        // Apply the 0.8 reward reduction
        reward = (int)(reward * 0.8);
        
        // Apply config multipliers (affects all jobs individually)
        ModConfig config = ModConfig.getInstance();
        double quantityMultiplier = config.getJobQuantityMultiplier();
        double payoutMultiplier = config.getJobPayoutMultiplier();
        
        // Apply quantity multiplier
        quantity = Math.max(1, (int)Math.round(quantity * quantityMultiplier));
        
        // Apply payout multiplier: reward scales with quantity multiplier to maintain payout per item,
        // then payout multiplier is applied on top
        // Example: 64 cobblestone for $10, quantity=0.5, payout=1.0 -> 32 cobblestone for $5
        reward = Math.max(1, (int)Math.round(reward * quantityMultiplier * payoutMultiplier));
        
        return new Job(UUID.randomUUID(), template.itemId, quantity, reward, isMegaJob);
    }
    
    /**
     * Applies variation to a base value.
     *
     * @param baseValue The base value
     * @param variation The variation percentage (0-100)
     * @return The value with variation applied
     */
    private static int applyVariation(int baseValue, int variation) {
        if (variation <= 0) {
            return baseValue;
        }
        
        // Calculate the range of variation
        double variationRange = baseValue * (variation / 100.0);
        
        // Generate a random value within the range (-variationRange to +variationRange)
        double randomVariation = (RANDOM.nextDouble() * 2 - 1) * variationRange;
        
        // Apply the variation to the base value and round to the nearest integer
        return (int) Math.round(baseValue + randomVariation);
    }
    
    /**
     * Gets the item for this job.
     *
     * @return The item
     */
    public class_1792 getItem() {
        // Parse the item ID, handling both formats: "minecraft:diamond" and "diamond"
        class_2960 itemIdentifier;
        if (itemId.contains(":")) {
            // Already has namespace, use directly
            itemIdentifier = class_2960.method_60654(itemId);
        } else {
            // Add minecraft namespace
            itemIdentifier = class_2960.method_60655("minecraft", itemId);
        }
        return class_7923.field_41178.method_10223(itemIdentifier);
    }
    
    /**
     * Gets the item ID for this job.
     *
     * @return The item ID
     */
    public String getItemId() {
        return itemId;
    }
    
    /**
     * Gets the quantity for this job.
     *
     * @return The quantity
     */
    public int getQuantity() {
        return quantity;
    }
    
    /**
     * Gets the reward for this job.
     *
     * @return The reward
     */
    public int getReward() {
        return reward;
    }
    
    /**
     * Gets the unique ID of this job.
     *
     * @return The unique ID
     */
    public UUID getId() {
        return id;
    }
    
    /**
     * Checks if this job is active.
     *
     * @return True if active, false otherwise
     */
    public boolean isActive() {
        LOGGER.debug("Checking if job {} is active: {}", id, active);
        return active;
    }
    
    /**
     * Checks if this is a Mega job.
     *
     * @return True if this is a Mega job, false otherwise
     */
    public boolean isMegaJob() {
        return isMegaJob;
    }
    
    /**
     * Sets whether this job is active.
     *
     * @param active True if active, false otherwise
     */
    public void setActive(boolean active) {
        LOGGER.debug("Setting job {} active state to: {}", id, active);
        this.active = active;
    }
    
    /**
     * Gets the display text for this job.
     *
     * @param includeStatus Whether to include the status
     * @return The display text
     */
    public class_2561 getDisplayText(boolean includeStatus) {
        class_1792 item = getItem();
        class_5250 text = class_2561.method_43473();
        
        // Add status if requested
        if (includeStatus) {
            if (isActive()) {
                text = text.method_10852(class_2561.method_43470("【ACTIVE】 ").method_27694(style -> style.method_10977(class_124.field_1060).method_10982(true)));
            } else {
                text = text.method_10852(class_2561.method_43470("【JOB】 ").method_27694(style -> style.method_10977(class_124.field_1075)));
            }
        }
        
        // If this is a mega job, add a special prefix
        if (isMegaJob) {
            text = text.method_10852(class_2561.method_43470("【MEGA】 ").method_27694(style -> style.method_10977(class_124.field_1065).method_10982(true)));
        }
        
        // Format item name correctly with proper capitalization
        String itemName = item.method_7848().getString();
        
        // Add job details with better formatting
        class_5250 jobText = class_2561.method_43470("Collect ")
                .method_10852(class_2561.method_43470(String.valueOf(quantity)).method_27694(style -> style.method_10977(class_124.field_1054).method_10982(true)))
                .method_27693(" ")
                .method_10852(class_2561.method_43470(itemName).method_27694(style -> style.method_10977(class_124.field_1075).method_10982(true)))
                .method_10852(class_2561.method_43470(" • Reward: ").method_27694(style -> style.method_10977(class_124.field_1080)))
                .method_10852(class_2561.method_43470("$" + reward).method_27694(style -> style.method_10977(class_124.field_1060).method_10982(true)));
        
        return text.method_10852(jobText);
    }
    
    /**
     * Create clickable text that activates the job when clicked
     * 
     * @param command Command prefix
     * @return Clickable text
     */
    public class_5250 createClickableText(String command) {
        class_5250 text = class_2561.method_43473();
        
        // Add MEGA prefix if it's a mega job
        if (isMegaJob) {
            text = text.method_10852(class_2561.method_43470("[MEGA] ").method_27695(class_124.field_1065, class_124.field_1067));
        }
        
        text = text.method_10852(getDisplayText(true));
        
        // Make text clickable
        text = text.method_27694(style -> style.method_10958(
            new class_2558(class_2558.class_2559.field_11750, command + id.toString())
        ).method_10949(
            new class_2568(class_2568.class_5247.field_24342, 
                class_2561.method_43470("Click to activate this job\n\n")
                    .method_27692(class_124.field_1054)
                    .method_10852(class_2561.method_43470("- Collect " + quantity + " " + getItem().method_7848().getString() + "\n")
                        .method_27692(class_124.field_1080))
                    .method_10852(class_2561.method_43470("- Earn $" + reward + "\n")
                        .method_27692(class_124.field_1080))
                    .method_10852(class_2561.method_43470("- Abandoning costs 75% of reward")
                        .method_27692(class_124.field_1061))
            )
        ));
        
        return text;
    }
    
    /**
     * Gets a formatted display text for this job with both adjusted quantity and reward.
     *
     * @param includeStatus Whether to include active/job status
     * @param adjustedQuantity The adjusted quantity for the job
     * @param showOriginalQuantity Whether to show the original quantity in parentheses
     * @param adjustedReward The adjusted reward amount (with bonuses)
     * @param showBaseReward Whether to show the base reward in parentheses
     * @return The formatted text
     */
    public class_5250 getDisplayTextWithAdjustments(boolean includeStatus, int adjustedQuantity, boolean showOriginalQuantity, 
                                                  int adjustedReward, boolean showBaseReward) {
        class_5250 text = class_2561.method_43473();
        
        // Add status if requested
        if (includeStatus) {
            if (isActive()) {
                text = text.method_10852(class_2561.method_43470("【ACTIVE】 ").method_27694(style -> style.method_10977(class_124.field_1060).method_10982(true)));
            } else {
                text = text.method_10852(class_2561.method_43470("【JOB】 ").method_27694(style -> style.method_10977(class_124.field_1075)));
            }
        }
        
        // If this is a mega job, add a special prefix
        if (isMegaJob) {
            text = text.method_10852(class_2561.method_43470("【MEGA】 ").method_27694(style -> style.method_10977(class_124.field_1065).method_10982(true)));
        }
        
        // Format item name correctly with proper capitalization
        class_1792 item = getItem();
        String itemName = item.method_7848().getString();
        String displayName = (adjustedQuantity == 1 ? itemName : itemName + "s");
        
        // Add job details with better formatting
        class_5250 jobText = class_2561.method_43470("Collect ")
                .method_10852(class_2561.method_43470(String.valueOf(adjustedQuantity)).method_27694(style -> style.method_10977(class_124.field_1054).method_10982(true)));
        
        // Show original quantity if requested and different
        if (showOriginalQuantity && adjustedQuantity != quantity) {
            jobText.method_10852(class_2561.method_43470(" (-" + (quantity - adjustedQuantity) + ")").method_27694(style -> style.method_10977(class_124.field_1062)));
        }
        
        jobText.method_27693(" ")
               .method_10852(class_2561.method_43470(displayName).method_27694(style -> style.method_10977(class_124.field_1075).method_10982(true)))
               .method_10852(class_2561.method_43470(" • Reward: ").method_27694(style -> style.method_10977(class_124.field_1080)));
        
        // Add the reward
        if (showBaseReward && adjustedReward != reward) {
            jobText = jobText.method_10852(class_2561.method_43470("$" + adjustedReward).method_27694(style -> style.method_10977(class_124.field_1060).method_10982(true)))
                    .method_10852(class_2561.method_43470(" (+$" + (adjustedReward - reward) + ")").method_27694(style -> style.method_10977(class_124.field_1080)));
        } else {
            jobText = jobText.method_10852(class_2561.method_43470("$" + adjustedReward).method_27694(style -> style.method_10977(class_124.field_1060).method_10982(true)));
        }
        
        return text.method_10852(jobText);
    }
    
    /**
     * Creates clickable job text with adjusted quantity and reward.
     *
     * @param commandPrefix The command prefix
     * @param adjustedQuantity The adjusted quantity for the job
     * @param showOriginalQuantity Whether to show the original quantity
     * @param adjustedReward The adjusted reward amount (with bonuses)
     * @param showBaseReward Whether to show the base reward in parentheses
     * @return The clickable text
     */
    public class_2561 createClickableTextWithAdjustments(String commandPrefix, int adjustedQuantity, boolean showOriginalQuantity,
                                                int adjustedReward, boolean showBaseReward) {
        class_5250 text = getDisplayTextWithAdjustments(true, adjustedQuantity, showOriginalQuantity, adjustedReward, showBaseReward);
        
        // Format item name for hover text
        class_1792 item = getItem();
        String itemName = item.method_7848().getString();
        String displayName = (adjustedQuantity == 1 ? itemName : itemName + "s");
        
        // Create hover text
        class_5250 hoverText = class_2561.method_43470("Click to ")
                .method_10852(class_2561.method_43470(isActive() ? "abandon" : "activate").method_27692(isActive() ? class_124.field_1061 : class_124.field_1060))
                .method_10852(class_2561.method_43470(" job:\n").method_27692(class_124.field_1054))
                .method_10852(class_2561.method_43470(adjustedQuantity + " " + displayName + "\n")
                        .method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470("Reward: $" + adjustedReward)
                        .method_27692(class_124.field_1065));
        
        // Add information about abandonment penalty
        if (isActive()) {
            if (isMegaJob) {
                // No penalty for mega jobs
                hoverText.method_10852(class_2561.method_43470("\nMEGA jobs can be abandoned without penalty")
                        .method_27692(class_124.field_1060));
            } else {
                // Regular jobs have a penalty
                hoverText.method_10852(class_2561.method_43470("\nPenalty: $" + (int)(adjustedReward * 0.75))
                        .method_27692(class_124.field_1061));
            }
        }
        
        // Add hover and click events
        return text.method_27694(style -> style
                .method_10949(new class_2568(class_2568.class_5247.field_24342, hoverText))
                .method_10958(new class_2558(
                        class_2558.class_2559.field_11750,
                        String.format("%s%s", 
                            isActive() ? "/jobs abandon" : commandPrefix, 
                            isActive() ? "" : getId())
                ))
        );
    }
    
    /**
     * Gets the display text for this job with an adjusted reward.
     * 
     * @param includeStatus Whether to include the status
     * @param adjustedReward The adjusted reward amount (with level bonus)
     * @param showBaseReward Whether to show the base reward in parentheses
     * @return The display text
     */
    public class_2561 getDisplayTextWithAdjustedReward(boolean includeStatus, int adjustedReward, boolean showBaseReward) {
        // Use the new combined method but with original quantity
        return getDisplayTextWithAdjustments(includeStatus, quantity, false, adjustedReward, showBaseReward);
    }
    
    /**
     * Creates clickable job text with an adjusted reward.
     *
     * @param commandPrefix The command prefix
     * @param adjustedReward The adjusted reward amount (with level bonus)
     * @param showBaseReward Whether to show the base reward in parentheses
     * @return The clickable job text
     */
    public class_2561 createClickableTextWithAdjustedReward(String commandPrefix, int adjustedReward, boolean showBaseReward) {
        // Use the new combined method but with original quantity
        return createClickableTextWithAdjustments(commandPrefix, quantity, false, adjustedReward, showBaseReward);
    }
    
    /**
     * Gets a formatted display text for this job, optionally showing adjusted quantity.
     *
     * @param includeStatus Whether to include active/job status
     * @param adjustedQuantity The adjusted quantity for the job
     * @param showOriginalQuantity Whether to show the original quantity in parentheses
     * @return The formatted text
     */
    public class_5250 getDisplayTextWithAdjustedQuantity(boolean includeStatus, int adjustedQuantity, boolean showOriginalQuantity) {
        // Use the new combined method but with original reward
        return getDisplayTextWithAdjustments(includeStatus, adjustedQuantity, showOriginalQuantity, reward, false);
    }
    
    /**
     * Creates clickable text with adjusted quantity that activates this job when clicked.
     *
     * @param commandPrefix The command prefix ("/jobs take " etc.)
     * @param adjustedQuantity The adjusted quantity for the job
     * @param showOriginalQuantity Whether to show the original quantity
     * @return The clickable text
     */
    public class_2561 createClickableTextWithAdjustedQuantity(String commandPrefix, int adjustedQuantity, boolean showOriginalQuantity) {
        // Use the new combined method but with original reward
        return createClickableTextWithAdjustments(commandPrefix, adjustedQuantity, showOriginalQuantity, reward, false);
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Job job = (Job) o;
        return quantity == job.quantity &&
               reward == job.reward &&
               active == job.active &&
               isMegaJob == job.isMegaJob &&
               Objects.equals(id, job.id) &&
               Objects.equals(itemId, job.itemId);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(id, itemId, quantity, reward, active, isMegaJob);
    }
} 